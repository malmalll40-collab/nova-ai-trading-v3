# NOVA AI Trading Mobile v3.9 — 캔들차트·종목뉴스

기존 **v3.8.1** 개인 연구용 앱에 읽기 전용 **캔들차트**와 **종목뉴스** 탭을 추가했습니다. 실거래 주문, 자동주문, 뉴스 감성 점수, 실제 수익률 보장 기능은 포함하지 않습니다.

## 이번 버전

- 기존 종가 선 그래프 대신 OHLC **상승/하락 캔들차트**를 기본으로 표시합니다.
- 최신 **125개 완료봉의 시가/고가/저가/종가/거래량**, EMA20·EMA50, 참고 손절가·목표가 수평선을 보여줍니다.
- `캔들 / 종가 선` 전환, 확대·축소 버튼, 터치 두 손가락 확대 및 드래그 이동, 봉 선택 시 수치를 표시합니다.
- 하단 **6번째 메뉴 '종목뉴스'**: 한국·미국 종목명 검색 후 뉴스 제목·출처·한국시간(KST)·원문 링크 표시.
- 우선 제공원: **NAVER API HUB 공식 뉴스 검색 API**. 인증키가 설정되지 않았다면 **공개 Google 뉴스 RSS 검색**을 시도합니다. RSS는 비공식 연동으로 언제든 중단될 수 있으며, 실패하면 '네이버 뉴스 검색' 버튼을 사용하세요.
- 신호 산출 엔진·재무필터·성과 추적·로그인·관심종목 감시·OpenDART 기능은 기존 v3.8.1 방식 그대로 유지됩니다. **뉴스는 매수·매도 신호에 반영되지 않습니다.**

## 선택적 NAVER 뉴스 API HUB 인증키

1. 공식 [NAVER API HUB](https://guide.ncloud-docs.com/docs/apihub-application)에서 **뉴스 검색 API**를 사용할 애플리케이션을 등록합니다.
2. Render 서비스의 **Environment**에서 아래 두 값만 추가합니다. GitHub, 채팅 메시지, 프런트엔드 JS에 비밀키를 붙여 넣으면 안 됩니다.

```
NAVER_NEWS_CLIENT_ID=<API HUB Client ID>
NAVER_NEWS_CLIENT_SECRET=<API HUB Client Secret>
```

3. Render에서 환경변수 저장 및 배포 후 종목뉴스 탭에서 종목을 선택하면 서버가 API HUB를 호출합니다.
4. 인증키가 없으면 `Google 뉴스 RSS (공개 피드 · 비공식 연동)`으로 표시합니다. RSS 장애는 실제 뉴스 부재 또는 종목 호재·악재 부재를 의미하지 않습니다.

API HUB 엔드포인트: `https://naverapihub.apigw.ntruss.com/search/v1/news` (GET). 응답을 서버 내 10분 캐시하여 공급원 호출을 최소화합니다. 예전 NAVER Developers Center 키는 API HUB에서 사용할 수 없습니다.

## 기존 Render 서비스 업데이트

1. 기존에 잘 작동 중인 **v3.8.1을 ZIP으로 백업**해 두면 롤백에 유리합니다. 모바일 브라우저의 신호 기록도 과거 검증 → JSON 백업을 권장합니다.
2. GitHub의 `malmalll40-collab/nova-ai-trading-v3` 저장소에서 기존 `NOVA_v3_8_1_update.zip`을 삭제하고 Commit합니다.
3. 새로 받은 `NOVA_v3_9_update.zip` **하나만** 저장소 최상위 경로에 업로드하고 Commit합니다. 기존 Render 빌드 명령은 ZIP 파일이 **정확히 한 개** 있어야 합니다.
4. Render에서 `Deploy latest commit`을 실행하여 최신 커밋의 배포 상태 `Live`를 확인합니다. 기존 `NOVA_ACCESS_TOKEN`, `OPENDART_API_KEY`, `KIS_APP_KEY`, `KIS_APP_SECRET`을 유지합니다.
5. `/healthz`에서 `app_version:"3.9"`, `candlestick_chart:true`, `stock_news:true`를 확인합니다.
6. 갤럭시 Chrome에서 페이지를 새로고침하거나 PWA 앱을 완전히 닫고 다시 실행합니다. 서비스워커 캐시 이름은 `nova3-shell-v39`로 변경했습니다.

**중요:** 수정본 파일은 자동으로 Render 서버에 반영되지 않습니다. 현재 운영 중인 앱은 사용자가 GitHub 업로드를 완료하기 전까지 v3.8.1입니다.

## 로컬 실행 및 테스트

Python 3.10 이상 필요:

```
pip install -r requirements.txt
python server.py
```

주소: http://127.0.0.1:8000

```
PYTHONPATH=. pytest -q tests
node --check static/app.js
node --check static/candles.js
node --check static/news.js
python create_preview.py
```

오프라인 체험판 `NOVA_v3_모바일_체험판.html`은 **가상 데이터만** 표시하며 실제 뉴스와 시세를 불러오지 않습니다.

## 제약 및 위험

- Yahoo Finance 데이터는 실시간 보장하지 않으며 API 요청 제한 또는 부분 누락이 발생할 수 있습니다. 차트도 마지막 **완료봉** 기준입니다.
- KIS REST는 별도의 서버 측 증권사 API 키가 필요합니다.
- 뉴스 검색 결과는 동명이인·유사 기업 기사나 오래된 기사가 포함될 수 있고, 정정 여부와 원문 링크를 직접 확인해야 합니다.
- 공개 Google 뉴스 RSS는 공식 서비스 계약이나 SLA가 아닌 **보조 연결**입니다. URL 형식·응답이 바뀌면 실패로 표시합니다.
- 10분 캐시로 인해 '새로고침' 버튼을 눌러도 10분 이내에는 동일 검색 결과일 수 있습니다. 뉴스 본문은 수집·저장·재배포하지 않습니다.
- 캔들차트의 참고 손절·목표는 실제 거래 주문가가 아닙니다.
- 기존 스윙 신호 1·3·5·10거래일 결과 기록은 브라우저에 저장됩니다. 단타 분봉별 적중률은 아직 미지원입니다.
- Render 무료 서버 사용 중에는 절전, 서버 로컬 기록 비영구성, API 이용약관과 개인정보/기밀키 보안에 유의하세요.

## 검증 범위

- **기존 회귀 테스트 89개 + v3.9 신규 테스트 10개** 통과(가상 시세 및 모의 뉴스 응답).
- 390px 모바일 Chromium에서 6개 하단 탭, 가상 캔들 OHLC 표시, 종목뉴스 화면 이동, JS 오류·가로 넘침 여부 확인.
- 실제 NAVER API HUB 키/Google RSS 외부 수신, 갤럭시 실기기 터치, Render 운영 환경의 최신 배포는 아직 **미검증**입니다.
