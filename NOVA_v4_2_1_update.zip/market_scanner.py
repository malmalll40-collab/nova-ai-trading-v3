"""NOVA v4.2: KRX market-wide EOD screener. Read-only, no trade execution.

All KOSPI/KOSDAQ securities are inspected via a same-day KRX bulk snapshot;
only a small, explicitly reported candidate subset receives expensive NOVA
symbol-by-symbol analysis. A one-day KRX snapshot does NOT support historical
trend inference, and today's intraday prices are NEVER presented as completed EOD.
"""
from __future__ import annotations

import math
import re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from typing import Callable

import requests

KST = ZoneInfo('Asia/Seoul')
URLS = {'kospi': 'https://data-dbg.krx.co.kr/svc/apis/sto/stk_bydd_trd',
        'kosdaq': 'https://data-dbg.krx.co.kr/svc/apis/sto/ksq_bydd_trd'}
MAX_DEEP = 8
MAX_DISPLAY = 10


class MarketScanError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _number(v):
    if v is None or isinstance(v, bool):
        return None
    try:
        n=float(str(v).replace(',', '').strip())
        return n if math.isfinite(n) else None
    except (TypeError, ValueError, OverflowError):
        return None


def _code(value):
    s = str(value or '').strip()
    if re.fullmatch(r'\d{6}', s):
        return s
    # KRX sometimes distributes an ISIN alongside the short code.
    if re.fullmatch(r'KR7\d{6}[0-9A-Z]{3}', s):
        return s[3:9]
    return None


def parse_rows(payload, market: str, date: str):
    """Strict response validation; an authentication error is not an empty market."""
    if not isinstance(payload, dict):
        raise MarketScanError('provider_format', 'KRX 데이터 형식을 확인할 수 없습니다.')
    rows = payload.get('OutBlock_1')
    if isinstance(rows, dict):
        rows = [rows]
    if not isinstance(rows, list):
        raise MarketScanError('provider_auth_or_format', 'KRX 서비스 접근 권한 또는 응답 형식을 확인하세요.')
    result=[]
    for row in rows:
        if not isinstance(row, dict):
            continue
        code = _code(row.get('ISU_CD'))
        name = str(row.get('ISU_NM') or '').strip()
        price, volume = _number(row.get('TDD_CLSPRC')), _number(row.get('ACC_TRDVOL'))
        amount, cap, change = (_number(row.get(k)) for k in ('ACC_TRDVAL','MKTCAP','FLUC_RT'))
        if not code or not name:
            continue
        source_date = str(row.get('BAS_DD') or date).replace('-', '')
        if source_date != date:
            continue
        # KRX provides the six-digit domestic short code, with an explicit suffix.
        result.append({'symbol': code + ('.KS' if market=='kospi' else '.KQ'),
                       'name':name,'market':market,'close':price or 0.,
                       'volume':int(volume or 0),'turnover_krw':int(amount or 0),
                       'market_cap_krw':int(cap or 0),'change_pct':round(change or 0.,3)})
    return result


class KRXClient:
    def __init__(self, api_key: str, session=None):
        if not api_key or len(api_key.strip()) < 12:
            raise MarketScanError('not_configured','Render에 KRX_API_KEY를 등록해 주세요.')
        self.key = api_key.strip()
        self.session = session or requests.Session()

    def fetch_day(self, date: str, market: str):
        if market not in URLS or not re.fullmatch(r'\d{8}',date):
            raise MarketScanError('invalid_input','KRX 시장 또는 조회일이 올바르지 않습니다.')
        try:
            resp=self.session.get(URLS[market],params={'basDd':date},headers={'AUTH_KEY':self.key,
                  'Accept':'application/json'},timeout=(5,14))
            try: payload=resp.json() if callable(getattr(resp,'json',None)) else None
            except (ValueError, TypeError): payload=None
            # KRX may report respCode 401 in a JSON body even when the HTTP
            # envelope is 200. Distinguish these cases without echoing secrets.
            info=classify_krx_response(resp.status_code, payload, market)
            if info['state'] != 'success':
                msg=info['detail']
                code='not_approved' if info['state']=='auth_denied' else info['error_code']
                if info['state']=='no_data':
                    return []
                raise MarketScanError(code, msg)
            return parse_rows(payload, market, date)
        except MarketScanError:
            raise
        except requests.RequestException:
            # Never echo URLs containing credentials or raw response bodies.
            raise MarketScanError('provider_network','KRX 서버 통신에 실패했습니다.') from None


def completed_dates(now: datetime):
    """Only EOD records plausibly published by the exchange."""
    now=now.astimezone(KST)
    date = now.date()
    # Allow time for exchange-side daily data publication after Korean close.
    if (now.hour,now.minute)<(18,30):
        date -= timedelta(days=1)
    for _ in range(10):
        if date.weekday()<5:
            yield date.strftime('%Y%m%d')
        date -= timedelta(days=1)


def screen(rows: list[dict]):
    """Cheap *one-day* liquidity screen, not an EMA-based recommendation."""
    seen=set()
    selected=[]
    excluded={'duplicate':0,'invalid_or_halted':0,'illiquid':0,'price_or_cap':0,'extreme_move':0}
    for item in rows:
        sym=item['symbol']
        if sym in seen:
            excluded['duplicate']+=1
            continue
        seen.add(sym)
        if item['close'] <= 0 or item.get('volume',0) <= 0 or item['market_cap_krw'] <= 0:
            excluded['invalid_or_halted']+=1;continue
        if item['close'] < 1000 or item['market_cap_krw'] < 100_000_000_000:
            excluded['price_or_cap']+=1;continue
        if item['turnover_krw']<3_000_000_000:
            excluded['illiquid']+=1;continue
        if item['change_pct'] < -5 or item['change_pct'] > 12:
            excluded['extreme_move']+=1;continue
        # Ranking is transparent liquidity+moderate price action, not a probability.
        turnover = min(50., max(0., math.log10(max(1,item['turnover_krw'])/1e9)*20))
        moderate = max(0.,20-abs(item['change_pct']-2.0)*3)
        size = min(15., math.log10(max(1,item['market_cap_krw'])/1e11+1)*12)
        item=dict(item,screen_score=round(turnover+moderate+size,1))
        selected.append(item)
    selected.sort(key=lambda r:(r['screen_score'],r['turnover_krw'],r['symbol']), reverse=True)
    return selected,excluded


def evaluate_candidate(snapshot: dict, detail: dict, asof: str):
    """Act only on fully verified existing NOVA final BUY and holdout signal."""
    reasons=[]
    if detail.get('is_demo') or detail.get('is_stale') or detail.get('final_actionable_signal')!='BUY':
        return None, '최종 매수 조건 미충족 또는 시세 지연'
    if detail.get('mode') != '스윙' or detail.get('financial_gate') != 'PASS':
        return None,'재무 위험 통과 확인 불가'
    if detail.get('signal_is_current') is not True:
        return None,'실제 완료봉 기준 확인 실패'
    last = str(detail.get('last_completed_bar') or '')[:10].replace('-','')
    if last!=asof:
        return None,'KRX 기준일과 기술적 완료봉 날짜 불일치'
    quality=detail.get('quality_gate') or {}
    if quality.get('strict_signal')!='BUY' or quality.get('passed_count',0)<4:
        return None,'엄격 기술 조건 미충족'
    stats=detail.get('signal_performance') or {}
    if not (stats.get('selected_validation_positive') and stats.get('selected_active_now')):
        return None,'개별 조건의 최근 독립 검증 부족'
    role=next((x for x in stats.get('roles',[]) if x.get('id')==stats.get('selected_id')),None)
    val=(role or {}).get('validation') or {}
    if val.get('samples',0)<stats.get('min_validation',15) or (val.get('mean_net_pct') or 0)<=0:
        return None,'최근 검증 표본 또는 비용 차감 성과 불충분'
    rr = _number(detail.get('long_risk_reward'))
    stop, target = (_number(detail.get(k)) for k in ('long_stop_reference','long_target_reference'))
    price = _number(detail.get('reference'))
    if rr is None or rr < 1.3 or stop is None or target is None or price is None:
        return None,'참고 손익비 또는 손절·목표가 미확인'
    if not (0<stop<price<target):
        return None,'참고 가격 정합성 확인 실패'
    reasons.append(f'안정형 기술 조건 {quality["passed_count"]}/5 충족')
    reasons.append('OpenDART 재무 위험 필터 통과')
    reasons.append(f'{stats.get("selected_name") or "매수 조건"}: 최근 별도 검증 {val["samples"]}건, 적중 {val.get("hit_pct")}%, 평균 순수익 {val.get("mean_net_pct")}%')
    reasons.append(f'손절·목표 참고 손익비 약 {rr:.1f}:1')
    return ({'symbol':snapshot['symbol'],'name':snapshot['name'],'market':snapshot['market'],
        'asof':asof,'close_krx':snapshot['close'],'change_pct':snapshot['change_pct'],
        'turnover_krw':snapshot['turnover_krw'],'screen_score':snapshot['screen_score'],
        'reference':round(price,3),'stop':round(stop,3),'target':round(target,3),
        'risk_reward':round(rr,2),'selected_condition':stats.get('selected_name'),
        'validation':{'samples':val['samples'],'hit_pct':val.get('hit_pct'),
           'mean_net_pct':val.get('mean_net_pct'),'wilson_lower_pct':val.get('wilson_lower_pct')},
        'reason':reasons,'financial_gate':'PASS','signal':'BUY',
        'last_completed_bar':detail['last_completed_bar'],'provider':detail.get('provider','unknown'),
        'not_probability':True},None)


def run_market_scan(*, market: str, api_key: str, analyze: Callable[[str],dict],
                    progress: Callable[[dict],None]|None=None, now: datetime|None=None,
                    client:KRXClient|None=None):
    """Run complete KRX universe snapshot and explicit limited deep investigation."""
    if market not in ('all','kospi','kosdaq'):
        raise MarketScanError('invalid_input','시장 선택은 전체·코스피·코스닥 중 하나여야 합니다.')
    client=client or KRXClient(api_key)
    markets=['kospi','kosdaq'] if market=='all' else [market]
    moment=now or datetime.now(tz=KST)
    asof,whole=None,None
    last_issue='';calls=0
    for date in completed_dates(moment):
        try:
            per=[client.fetch_day(date,m) for m in markets]
            calls+=len(per)
        except MarketScanError as exc:
            if exc.code in ('not_approved','provider_auth_or_format','provider_format','provider_network','provider_unavailable','provider_rate_limited','provider_rejected','invalid_input','not_configured'):
                raise
            last_issue=str(exc)
            continue
        if all(per):
            asof=date;whole=[x for batch in per for x in batch];break
    if not whole or not asof:
        raise MarketScanError('no_published_data',last_issue or '요청한 시장의 같은 날짜 공식 일별 자료를 찾지 못했습니다.')
    # Do not misrepresent an old past day as today's new recommendations.
    if (moment.astimezone(KST).date() - datetime.strptime(asof,'%Y%m%d').date()).days > 6:
        raise MarketScanError('stale_snapshot','KRX 마지막 공식 일별 자료가 오래됐습니다.')
    selected, exclusions=screen(whole)
    top=selected[:MAX_DEEP]
    result={'status':'complete','data_source':'KRX 일별매매정보 + Yahoo Finance / NOVA / OpenDART',
        'data_date':asof,'market':market,'markets_scanned':markets,
        'total_market_rows':len(whole),'screen_passed':len(selected),'deep_target':len(top),
        'deep_succeeded':0,'deep_failed':0,'recommended_count':0,'recommendations':[],
        'rejected':[],'exclusion_counts':exclusions,'scan_limit':MAX_DEEP,'marketwide':True,
        'realtime':False,'method':'KRX 전체 일별 스냅샷 1차 → 최대 8개 유동성 후보 NOVA 스윙/재무/과거별도검증 심층 선별',
        'risk_note':'매수 후보는 미래 수익 확률이 아니며 투자 주문을 실행하지 않습니다. 1차 선별을 통과한 전체 종목을 심층 분석한 것은 아닙니다.',
        'persistence':'Render 프로세스 메모리에만 저장; 서버 재시작 시 결과 소멸'}
    for i,row in enumerate(top):
        if progress: progress({'phase':'deep','done':i,'total':len(top),
            'message':f'전체 {len(whole)}종목 중 1차 후보 {len(selected)}종목, 심층 분석 {i}/{len(top)}'})
        try:
            detail=analyze(row['symbol'])
            result['deep_succeeded']+=1
            rec,why=evaluate_candidate(row,detail,asof)
            if rec:
                result['recommendations'].append(rec)
            else:
                result['rejected'].append({'symbol':row['symbol'],'name':row['name'],
                                           'reason':why})
        except Exception:
            result['deep_failed']+=1
            result['rejected'].append({'symbol':row['symbol'],'name':row['name'],
                         'reason':'심층 시세·재무 조회에 실패했습니다 (인증·공급원·요청 제한 가능).'})
    result['recommended_count']=len(result['recommendations'])
    result['incomplete']=result['deep_failed']>0
    if progress:progress({'phase':'complete','done':len(top),'total':len(top),
        'message':f'분석 완료: {len(result["recommendations"])}개 매수 후보, 심층 조회 실패 {result["deep_failed"]}개'})
    return result


def classify_krx_response(http_status: int, payload, market: str):
    """Classify the vendor status without returning raw vendor texts or credentials.

    KRX sometimes responds HTTP 200 with {respCode: "401", respMsg: ...}.
    That must never be treated as a successful market snapshot.
    """
    if market not in URLS:
        raise ValueError('unsupported market')
    label = '코스피' if market == 'kospi' else '코스닥'
    api_id = 'stk_bydd_trd' if market == 'kospi' else 'ksq_bydd_trd'
    code_raw = str(payload.get('respCode') or '').strip() if isinstance(payload, dict) else ''
    code = code_raw if re.fullmatch(r'\d{1,4}',code_raw) else None
    msg = str(payload.get('respMsg') or '').lower()[:120] if isinstance(payload,dict) else ''
    rows = payload.get('OutBlock_1') if isinstance(payload,dict) else None
    if isinstance(rows,dict): rows=[rows]
    count = len(rows) if isinstance(rows,list) else None

    # Explicit HTTP and vendor-level failure codes take precedence over rows.
    if http_status == 401 or code == '401' or 'unauthorized api call' in msg or 'unauthorized key' in msg:
        state='auth_denied'
        if 'unauthorized key' in msg:
            err='unauthorized_key'; detail=f'{label}: 인증키 인식 실패 (Unauthorized Key)'
        elif 'unauthorized api call' in msg:
            err='unauthorized_api_call'; detail=f'{label}: API 호출 권한 거부 (Unauthorized API Call)'
        else:
            err='unauthorized'; detail=f'{label}: KRX 인증 거부 (401)'
    elif http_status == 403 or code == '403':
        state='auth_denied'; err='forbidden';detail=f'{label}: 접근 권한 거부 (403)'
    elif http_status == 429 or code == '429':
        state='rate_limited';err='provider_rate_limited';detail=f'{label}: 요청 횟수 제한 (429)'
    elif http_status >= 500:
        state='provider_error';err='provider_unavailable';detail=f'{label}: 서버 오류 (HTTP {http_status})'
    elif http_status != 200:
        state='provider_error';err='provider_unavailable';detail=f'{label}: HTTP 오류 ({http_status})'
    elif code and code not in ('0','00','000','200'):
        state='provider_error';err='provider_rejected';detail=f'{label}: KRX 응답 오류 (코드 {code})'
    elif isinstance(rows,list):
        state='success' if count else 'no_data'
        err='ok' if count else 'no_published_data'
        detail=f'{label}: 실제 종목 자료 {count}건 수신' if count else f'{label}: 해당 기준일 종목 자료 없음'
    else:
        state='provider_error';err='provider_format';detail=f'{label}: JSON 응답의 OutBlock_1 형식 확인 필요'
    return {'market':market,'api_id':api_id,'request_type':'GET',
            'auth_header_sent':True,'http_status':int(http_status),
            'krx_code':code,'state':state,'error_code':err,'detail':detail,
            'record_count':count if state in ('success','no_data') else None}


def diagnose_connection(api_key: str, date: str, markets: list[str], session=None):
    """Probe exact production endpoints with the same header as scanner.

    Deliberately no authentication secret, full response, or URL in result.
    """
    if not api_key or not api_key.strip():
        return {'date':date,'configured':False,'results':[]}
    if not re.fullmatch(r'\d{8}',date):
        raise ValueError('bad date')
    client_session=session or requests.Session()
    results=[]
    for market in markets:
        if market not in URLS: raise ValueError('bad market')
        try:
            response=client_session.get(URLS[market],params={'basDd':date},
                headers={'AUTH_KEY':api_key.strip(),'Accept':'application/json'},timeout=(5,14))
            try: payload=response.json() if callable(getattr(response,'json',None)) else None
            except (ValueError,TypeError): payload=None
            results.append(classify_krx_response(response.status_code,payload,market))
        except requests.RequestException:
            results.append({'market':market,'api_id':'stk_bydd_trd' if market=='kospi' else 'ksq_bydd_trd',
                'request_type':'GET','auth_header_sent':True,'state':'network_error','http_status':None,
                'krx_code':None,'error_code':'network_error',
                'detail':'KRX 통신 실패: DNS, 네트워크 또는 연결 시간 초과',
                'record_count':None})
    return {'date':date,'configured':True,'results':results,
            'notes':'운영 API 직접 호출 결과. 인증키는 반환·기록하지 않습니다. HTTP 200만으로 데이터 성공을 의미하지 않습니다.'}
