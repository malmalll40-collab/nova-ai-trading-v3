"""Generate a stand-alone offline HTML preview using explicitly synthetic data."""
from pathlib import Path
from server import _payload
import json,base64
base=Path(__file__).resolve().parent
html=(base/'static/index.html').read_text(encoding='utf-8')
css=(base/'static/styles.css').read_text(encoding='utf-8')
js=(base/'static/app.js').read_text(encoding='utf-8')
data={m:_payload('DEMO',m,'demo',15) for m in ['1분','5분','스윙']}
html=html.replace('<link rel="manifest" href="/manifest.webmanifest">','')
img=(base/'static/icons/icon-192.png').read_bytes()
html=html.replace('/static/icons/icon-192.png','data:image/png;base64,'+base64.b64encode(img).decode())
html=html.replace('<link rel="stylesheet" href="/static/styles.css">','<style>'+css+'</style>')
html=html.replace('<script src="/static/app.js" defer></script>',
                  '<script>window.NOVA_PREVIEW_DATA='+json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')+';</script>\n<script>'+js+'</script>')
html=html.replace('<title>NOVA | AI Trading Mobile v3.4</title>','<title>NOVA v3.4 | 모바일 데모 (가상 데이터)</title>')
html=html.replace('<body>','<body><div style="padding:8px;text-align:center;color:#f9ddae;background:#42301e;font-size:12px;font-weight:700">오프라인 미리보기 · 모든 수치와 신호는 가상 데이터입니다 · 실제 주식 조회 불가</div>')
p=base/'NOVA_v3_모바일_체험판.html'
p.write_text(html,encoding='utf-8')
print(p,p.stat().st_size)
