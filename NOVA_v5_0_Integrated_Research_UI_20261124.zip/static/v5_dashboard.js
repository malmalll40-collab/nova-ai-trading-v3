/* NOVA v5.0 – isolated observational research and on-demand trade feed.
   No write routes, no trading order, no overrides to the existing decision. */
(()=>{
'use strict';
const byId=id=>document.getElementById(id);
let current=null;
let referenceClose=null;
let inflight=null;
let socket=null;
let wsTarget=null;
let wsConnected=false;
const money=v=>Number.isFinite(Number(v))?Math.round(Number(v)).toLocaleString('ko-KR')+'원':'미확인';
const percent=v=>typeof v==='number'&&Number.isFinite(v)?`${v>0?'+':''}${v.toFixed(2)}%`:'표본 없음';
const errMsg=msg=>String(msg||'조회 실패').slice(0,180);
const el=(tag,className='',text='')=>{const x=document.createElement(tag);if(className)x.className=className;if(text)x.textContent=text;return x;};
function status(text,error=false){const s=byId('v5ResearchStatus');if(!s)return;s.textContent=text;s.classList.toggle('v5-error',error);}
function stopSocket(message){
 if(socket){const old=socket;socket=null;try{old.close(1000,'Stopped by user');}catch{}}
 const value=byId('v5LiveValue');if(value)value.hidden=true;
 wsTarget=null;wsConnected=false;
 const button=byId('v5LiveToggle');if(button)button.textContent='체결 관찰 시작';
 const label=byId('v5LiveState');if(label&&message)label.textContent=message;
}
function setAnalysis(data){
 const key=data?.symbol&&data?.mode==='스윙'&&!data.is_demo?data.symbol:null;
 if(key!==current){if(inflight){inflight.abort();inflight=null;}
   const content=byId('v5ResearchContent');if(content)content.hidden=true;
   status(key?`${key.slice(0,6)} 과거 완료봉 연구 준비 · 버튼을 누르면 조회합니다.`:'스윙 실종목의 완료봉에서만 연구할 수 있습니다.');
   if(socket)stopSocket('종목 또는 분석 주기가 바뀌어 실시간 관찰을 종료했습니다.');
 }
 current=key;
 referenceClose=Number.isFinite(Number(data?.reference))&&Number(data.reference)>0?Number(data.reference):null;
 const button=byId('v5ResearchRun');if(button)button.disabled=!key;
}
function metric(label,value){const row=el('div','v5-metric');row.append(el('span','',label),el('b','',value));return row;}
function methodCard(label,stats,reason=''){
 const c=el('article','v5-method-card');c.appendChild(el('strong','',label));
 if(!stats||stats.status!=='READY'){
   c.appendChild(el('p','v5-note',reason||stats?.reason||'검증 불가 · 자료 미확인'));return c;
 }
 c.append(metric('실제 가상거래',`${stats.completed_trades??0}건`));
 c.append(metric('가상 순수익률',percent(stats.portfolio_return_pct)));
 c.append(metric('최대 낙폭',percent(stats.portfolio_mdd_pct)));
 c.append(metric('거래 승률',percent(stats.win_rate_pct)));
 c.append(metric('진입 조건',`${stats.buy_opportunities??0}회`));
 return c;
}
function render(data){
 const container=byId('v5ResearchContent');const cards=byId('v5MethodCards');
 const roles=byId('v5RoleAblation');const aiBox=byId('v5AIDetails');const limits=byId('v5Limitations');
 if(!container||!cards||!roles||!aiBox||!limits)return;
 cards.replaceChildren();roles.replaceChildren();aiBox.replaceChildren();limits.replaceChildren();container.hidden=true;
 if(data.status!=='READY'){
   status(`연구 보류 · ${data.reason||'자료 부족'}`);return;
 }
 const phase=data.validation||{};
 const ai=phase.ai_model||{};
 const period=byId('v5StudyPeriod');period.textContent=`검증 구간 ${phase.start||'—'} ~ ${phase.end||'—'} · 자료 ${data.source||'미확인'} · 비용 편도 ${phase.baseline?.cost_bps_per_side??15}bp`;
 cards.append(methodCard('기존 13개 역할',phase.baseline));
 cards.append(methodCard('연구 5-Core',phase.five_core));
 cards.append(methodCard('AI 연구 신호',ai.research_strategy,ai.reason||'학습/검증 표본 부족'));
 const reference=el('article','v5-method-card');reference.append(el('strong','','AI 모델 검증 상태'));
 reference.append(metric('학습 완료 표본',`${ai.train_samples??0}건`));
 reference.append(metric('검증 완료 표본',`${ai.validation_samples??0}건`));
 reference.append(metric('Brier 점수',typeof ai.brier_score==='number'?String(ai.brier_score):'검증 전'));
 reference.append(metric('단순 기준 Brier',typeof ai.naive_train_rate_brier==='number'?String(ai.naive_train_rate_brier):'검증 전'));
 cards.append(reference);
 let best=null;
 for(const item of data.role_ablations||[]){
   const r=el('div','v5-role-row');
   const diff=item.return_difference_pp;
   r.append(el('span','',item.role),el('b','',diff===null?'계산 불가':`${diff>0?'+':''}${diff.toFixed(3)}%p`));
   roles.append(r);
   if(typeof diff==='number'&&(best===null||diff>best))best=diff;
 }
 aiBox.textContent=ai.status==='READY'?`AI 연구 표본: 학습 ${ai.train_samples}건 / 검증 ${ai.validation_samples}건. 점수 범위 ${ai.score_range?.join('~')||'—'} · 보정된 상승 확률 아님. 실전 신호 반영 없음.`:`AI 연구 보류: ${ai.reason||'평가 자료 부족'}. 현재 매매 판단에는 영향이 없습니다.`;
 if(best!==null){aiBox.appendChild(el('p','v5-note','역할을 제거했을 때의 수익률 차이는 인과적 기여도나 전략 채택 근거가 아닙니다. 표본과 시장 상황에 따라 결과가 달라집니다.'));}
 for(const warning of data.bias_warnings||[]){const p=el('p','',`• ${warning}`);limits.append(p);}
 limits.append(el('p','',data.assumptions||''));
 container.hidden=false;
 status(`검증 구간 분석 완료 · 연구 결과는 실제 매매 신호·주문·추천 순위를 변경하지 않습니다.${data.source_fallback_reason?' · '+data.source_fallback_reason:''}`);
}
async function fetchResearch(){
 if(!current){status('스윙 종목 분석을 먼저 실행해 주세요.');return;}
 if(inflight){status('이미 연구를 조회 중입니다.');return;}
 const target=current;
 const controller=new AbortController();inflight=controller;
 const button=byId('v5ResearchRun');button.disabled=true;button.textContent='과거 성과 계산 중…';
 status('KIS 완료 일봉·시장지수 확인 및 시간순 연구 계산 중…');
 try{
   const source=window.NOVAConnect?.source?.()||'auto';
   const safeSource=['kis','auto','yahoo'].includes(source)?source:'auto';
   const cost=window.NOVAConnect?.cost?.()??15;
   const resp=await fetch(`/api/research/v5?symbol=${encodeURIComponent(target)}&source=${encodeURIComponent(safeSource)}&cost_bps=${Math.max(0,Math.min(100,Math.round(Number(cost)||15)))}`,
                          {credentials:'same-origin',cache:'no-store',signal:controller.signal});
   const result=await resp.json().catch(()=>({}));
   if(target!==current)return;
   if(!resp.ok)throw new Error(typeof result.detail==='string'?result.detail:`HTTP ${resp.status}`);
   render(result);
 }catch(e){if(e.name!=='AbortError'&&target===current)status(`연구 조회 실패 · ${errMsg(e.message)}. 기존 매매 결과는 유지됩니다.`,true);
 }finally{if(inflight===controller)inflight=null;button.disabled=!current;button.textContent='현재 종목 정밀 연구 실행';}
}
async function liveButton(){
 const btn=byId('v5LiveToggle'),label=byId('v5LiveState');
 if(socket){stopSocket('수동으로 실시간 관찰을 중단했습니다. 기존 REST 조회는 계속됩니다.');return;}
 if(!current){label.textContent='먼저 국내 종목의 스윙 분석을 해 주세요.';return;}
 btn.disabled=true;label.textContent='KIS 실시간 기능 활성화 상태 확인 중…';
 try{
   const r=await fetch('/api/realtime/kis/status',{credentials:'same-origin',cache:'no-store'});
   const body=await r.json().catch(()=>({}));
   if(!r.ok)throw new Error('접근 권한 확인 필요');
   if(!body.enabled){label.textContent='기본값은 비활성화입니다. Render에 NOVA_KIS_WS_ENABLED=1을 설정하고 KIS 권한을 확인해야 이용할 수 있습니다.';btn.textContent='연결 가능 여부 확인';return;}
   if(!('WebSocket' in window))throw new Error('이 브라우저는 WebSocket을 지원하지 않습니다.');
   const symbol=current,code=symbol.slice(0,6);
   const url=`${location.protocol==='https:'?'wss':'ws'}://${location.host}/api/realtime/kis/stream?symbol=${encodeURIComponent(symbol)}`;
   socket=new WebSocket(url);wsTarget=symbol;wsConnected=false;
   btn.textContent='관찰 중단';label.textContent='KIS 체결 채널 연결 시도 중…';
   socket.onmessage=event=>{
     if(wsTarget!==current){stopSocket('종목이 변경되어 관찰을 종료했습니다.');return;}
     let d;try{d=JSON.parse(event.data);}catch{return;}
     if(d.type==='trade'&&d.symbol===code){
       wsConnected=true;byId('v5LiveValue').hidden=false;
       byId('v5LivePrice').textContent=money(d.price);
       byId('v5LiveTime').textContent=`체결 ${d.trade_time_kst||'—'} · ${d.trade_volume??0}주`;
       const gap=referenceClose==null?null:100*(Number(d.price)/referenceClose-1);
       const flag=gap==null?'완료봉 비교 미확인':`${gap>=0?'+':''}${gap.toFixed(2)}% · ${Math.abs(gap)>=5?'큰 변동 관찰':Math.abs(gap)>=3?'변동 확대 관찰':'참고 범위'}`;
       label.textContent=`KIS 체결 틱 수신 · ${d.observed_at_kst||'—'} · 완료봉 대비 ${flag} · 기존 신호 미변경`;
     }else if(d.type==='error'){label.textContent=errMsg(d.message);stopSocket(label.textContent);}
     else if(d.message)label.textContent=errMsg(d.message);
   };
   socket.onclose=()=>{
     if(wsTarget===symbol){socket=null;wsTarget=null;btn.textContent='체결 관찰 시작';
       if(!wsConnected)label.textContent+=' · 체결 데이터 수신 전 종료';}
   };
   socket.onerror=()=>{label.textContent='실시간 체결 연결 오류 · REST 시세는 계속 사용합니다.';};
 }catch(e){label.textContent=errMsg(e.message);}
 finally{btn.disabled=false;}
}
function onViewChange(view){
 const menu=byId('v5MoreMenu'),more=byId('v5MoreNav');
 if(menu)menu.hidden=true;if(more){more.setAttribute('aria-expanded','false');more.classList.toggle('active',['finance','news','guide'].includes(view));}
 if(view!=='analyze'&&socket)stopSocket('종목 분석 화면을 벗어나 실시간 관찰을 종료했습니다.');
}
function init(){
 const button=byId('v5ResearchRun');if(button)button.addEventListener('click',fetchResearch);
 const live=byId('v5LiveToggle');if(live)live.addEventListener('click',liveButton);
 const menu=byId('v5MoreMenu'),more=byId('v5MoreNav');
 if(more&&menu){more.addEventListener('click',()=>{
   const opening=menu.hidden;menu.hidden=!opening;more.setAttribute('aria-expanded',String(opening));
 });}
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&socket)stopSocket('화면이 숨겨져 체결 관찰을 종료했습니다.');});
 window.addEventListener('pagehide',()=>{if(socket)stopSocket();});
}
window.NOVAV5={setAnalysis,onViewChange,stopSocket};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
