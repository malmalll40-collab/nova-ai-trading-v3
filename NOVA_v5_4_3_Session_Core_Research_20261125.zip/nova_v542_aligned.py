"""Replay fixed 5-Core rules on exactly the same evaluation and outcome dates.
No retuning, no stock-specific selection, no portfolio aggregation.
"""
import numpy as np
import pandas as pd
from nova_v541_core import STRATEGIES, FACTORS, REGIMES, CANDIDATES
from nova_v5_research import HORIZON,simulate_long_only
from nova_v54_accuracy import opportunity_metrics

def aligned_summary(rows):
    base={'status':'UNAVAILABLE','requested_stocks':len(rows),'strategy_adoption':'HOLD','research_only':True}
    reps=[r.get('v54_accuracy',{}).get('core_focus',{}) for r in rows]
    if len(rows)<2 or any(x.get('status')!='READY' or not x.get('_replay') for x in reps):return {**base,'reason':'전체 요청 종목의 공통 검증 자료 필요'}
    if len({x['cost_bps'] for x in reps})!=1:return {**base,'reason':'비용 불일치'}
    common=sorted(set.intersection(*(set(x['_replay']['points']) for x in reps)))
    if len(common)<40:return {**base,'reason':'공통 평가 40시점 미만'}
    # Do not silently bridge internal missing dates, or use different future horizons.
    frames=[]
    for x in reps:
        r=x['_replay']; dates=r['dates']; lo=dates.index(common[0]); hi=dates.index(common[-1]); span=dates[lo:hi+HORIZON+1]
        if dates[lo:hi+1]!=common or len(span)!=len(common)+HORIZON:return {**base,'reason':'공통 구간 내부 누락 또는 청산일 부족'}
        frames.append((span,pd.DataFrame({'Open':r['open'][lo:hi+HORIZON+1],'Close':r['close'][lo:hi+HORIZON+1]},index=pd.to_datetime(span)),[r['points'][d] for d in common]))
    if any(a[0]!=frames[0][0] for a in frames):return {**base,'reason':'거래일 또는 청산일 불일치'}
    cost=reps[0]['cost_bps'];ids=list(range(len(common)))
    def aggregate(items):
        active=[p for p,o,stress in items if p.get('completed_trades',0)>0]
        if any(p['status']!='READY' or stress['status']!='READY' for p,o,stress in items):return {'status':'UNAVAILABLE'}
        good=sum(o['positive_signals'] for p,o,stress in items); n=sum(o['buy_signals'] for p,o,stress in items)
        return {'status':'READY','stocks_with_trades':len(active),'positive_stocks':sum(p['portfolio_return_pct']>0 for p in active),'trades':sum(p['completed_trades'] for p in active),'mean_pct':round(float(np.mean([p['portfolio_return_pct'] for p,o,stress in items])),3),'mean_mdd_pct':round(float(np.mean([p['portfolio_mdd_pct'] for p,o,stress in items])),3),'stress_mean_pct':round(float(np.mean([stress['portfolio_return_pct'] for p,o,stress in items])),3),'buy_signals':n,'precision_pct':round(100*good/n,2) if n else None,'missed_positive':sum(o['missed_positive_opportunities'] for p,o,stress in items)}
    def evaluate(key,kind='signals',regime=None):
        items=[]; per=[]
        for row,(_,f,pts) in zip(rows,frames):
            subset=[i for i in ids if regime is None or pts[i]['regime']==regime or pts[i]['subregime']==regime]
            sig={i:('BUY' if pts[i]['grade']==key else 'HOLD') if kind=='grades' else pts[i][kind][key] for i in subset};labels={i:(None,pts[i]['label'],pts[i]['net']) for i in ids}
            p=simulate_long_only(f,sig,0,len(f),cost);stress=simulate_long_only(f,sig,0,len(f),cost*2)
            o=opportunity_metrics(labels,ids,sig) if regime is None else (opportunity_metrics(labels,subset,sig) if subset else {'buy_signals':0,'positive_signals':0,'missed_positive_opportunities':0})
            items.append((p,o,stress));per.append({'symbol':row['symbol'],'return_pct':p.get('portfolio_return_pct'),'mdd_pct':p.get('portfolio_mdd_pct'),'trades':p.get('completed_trades'),'precision_pct':o.get('precision_pct')})
        return {**aggregate(items),'per_stock':per}
    return {**base,'status':'READY','start':common[0],'end':common[-1],'outcome_end':frames[0][0][-1],'samples_per_stock':len(common),'cost_bps':cost,'strategies':{k:evaluate(k) for k in STRATEGIES},'ablations':{k:evaluate(k,'ablations') for k in FACTORS},'candidates':{k:evaluate(k,'candidates') for k in CANDIDATES} if all('candidates' in p for _,_,pts in frames for p in pts) else {},'grades':{k:evaluate(k,'grades') for k in ('A','B')},'regimes':{r:{k:evaluate(k,regime=r) for k in STRATEGIES} for r in (*REGIMES,'sideways','up_transition')},'limitations':'종목별 독립 가상자산 평균(무거래 현금 포함), 포트폴리오 수익률 아님. 동일 날짜의 중첩 신호, 과거 정규장 범위 미검증, 사후 설계 연구.'}
