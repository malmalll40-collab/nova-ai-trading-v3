"""Opt-in immutable observations, not a substitute for live provider data."""
import os,hashlib,json,math
from evidence_store import connection,backend
from datetime import datetime,timezone

def archive_verified(symbol,bars,report):
    if os.environ.get('NOVA_KIS_ARCHIVE_ENABLED','').lower() not in ('1','true','yes') or backend()=='disabled':return False
    if not report or not report.get('verified') or report.get('verification_basis')!='KIS_REGULAR_MINUTE' or bars.empty:return False
    day=str(bars.index[-1].date())
    if day!=report.get('latest_date'):return False
    row={k:float(bars.iloc[-1][k]) for k in ('Open','High','Low','Close','Volume')}
    if not all(math.isfinite(v) for v in row.values()):return False
    raw=json.dumps({'symbol':symbol,'day':day,'basis':'KIS_J_ADJ_0_REGULAR_MINUTE_CHECK','ohlcv':row},sort_keys=True)
    digest=hashlib.sha256(raw.encode()).hexdigest()
    with connection() as (db,kind):
        cur=db.cursor();cur.execute('CREATE TABLE IF NOT EXISTS nova_kis_daily_observations (id TEXT PRIMARY KEY, symbol TEXT NOT NULL, trading_day TEXT NOT NULL, observed_at TEXT NOT NULL, payload TEXT NOT NULL)')
        sql='INSERT INTO nova_kis_daily_observations(id,symbol,trading_day,observed_at,payload) VALUES(?,?,?,?,?) ON CONFLICT(id) DO NOTHING'
        if kind=='postgresql':sql=sql.replace('?','%s')
        cur.execute(sql,(digest,symbol,day,datetime.now(timezone.utc).isoformat(),raw));ok=cur.rowcount>0;db.commit();return ok
