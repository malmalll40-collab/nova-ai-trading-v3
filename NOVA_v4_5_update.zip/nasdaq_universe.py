"""Nasdaq Trader listing search and a BOUNDED technical research watchlist scan.

Not a full-US-market screener, not an SEC fundamental screen, not actionable BUY.
No screen result is claimed to predict returns or to have been out-of-sample validated.
"""
from __future__ import annotations

import csv
import io
import math
import re
import threading
import time
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import Callable

import requests

DIR_URL = 'https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqlisted.txt'
NY = ZoneInfo('America/New_York')
WATCHLIST = {
    'AAPL':'Apple','MSFT':'Microsoft','NVDA':'NVIDIA','AMZN':'Amazon',
    'GOOGL':'Alphabet Class A','GOOG':'Alphabet Class C','META':'Meta Platforms',
    'TSLA':'Tesla','AVGO':'Broadcom','COST':'Costco','NFLX':'Netflix',
    'AMD':'Advanced Micro Devices','AMAT':'Applied Materials','MU':'Micron Technology',
    'LRCX':'Lam Research','ASML':'ASML Holding','QCOM':'Qualcomm','ADBE':'Adobe',
    'BKNG':'Booking Holdings','INTU':'Intuit','ISRG':'Intuitive Surgical',
    'PANW':'Palo Alto Networks','CRWD':'CrowdStrike','PLTR':'Palantir',
    'MELI':'MercadoLibre','PDD':'PDD Holdings','ARM':'Arm Holdings',
    'CSCO':'Cisco','TXN':'Texas Instruments','ADI':'Analog Devices',
}
MAX_US_DEEP = 16  # Yahoo rate limits; transparent bounded coverage.
_DIRECTORY_CACHE: tuple[float,list[dict]]|None = None
_DIRECTORY_LOCK = threading.RLock()

class NasdaqDataError(Exception):
    def __init__(self,code,message):
        self.code=code
        super().__init__(message)


def parse_directory(content: str) -> list[dict]:
    """Validate real Nasdaq Trader pipe-delimited file, filtering test/ETF/nonstandard paper."""
    if not isinstance(content,str) or len(content)>4_000_000:
        raise NasdaqDataError('directory_invalid','나스닥 상장 목록 응답 형식이 올바르지 않습니다.')
    items=[]; seen=set()
    reader=csv.DictReader(io.StringIO(content),delimiter='|')
    fields=set(reader.fieldnames or [])
    if not {'Symbol','Security Name','Test Issue','Financial Status','ETF'}.issubset(fields):
        raise NasdaqDataError('directory_invalid','나스닥 상장 목록 필수 항목이 없습니다.')
    for line in reader:
        symbol=str(line.get('Symbol') or '').strip().upper()
        if symbol.startswith('FILE CREATION TIME'): continue
        name=str(line.get('Security Name') or '').strip()
        if (not re.fullmatch(r'[A-Z]{1,5}',symbol) or symbol in seen or not name
                or line.get('Test Issue')!='N' or line.get('ETF')!='N'
                or line.get('Financial Status')!='N'):
            continue
        lower=name.lower()
        if any(term in lower for term in (' - warrant',' - unit',' - right',' preferred',' - depositary shares',
                                        ' - notes due',' -  warrant',' etf','exchange traded')):
            continue
        seen.add(symbol)
        items.append({'symbol':symbol,'code':symbol,'name':name[:120],
                      'market':'나스닥','verified':False,'listing_source':'Nasdaq Trader directory'})
    if not items:
        raise NasdaqDataError('directory_empty','나스닥 공식 상장목록에 유효한 주식이 없습니다.')
    return items


def fetch_directory(*,session=None,now:float|None=None) -> tuple[list[dict],bool]:
    global _DIRECTORY_CACHE
    t=time.time() if now is None else now
    with _DIRECTORY_LOCK:
        if _DIRECTORY_CACHE and t-_DIRECTORY_CACHE[0]<6*3600:
            return [dict(x) for x in _DIRECTORY_CACHE[1]],True
    http=session or requests
    try:
        resp=http.get(DIR_URL,headers={'User-Agent':'NOVAReadOnly/4.5','Accept':'text/plain'},timeout=(4,8))
        resp.raise_for_status()
        listing=parse_directory(resp.text)
    except (requests.RequestException, UnicodeError, NasdaqDataError, AttributeError):
        return [],False
    with _DIRECTORY_LOCK:
        _DIRECTORY_CACHE=(t,listing)
    return [dict(x) for x in listing],True


def search_nasdaq(query: str,limit:int=12,*,directory=None) -> dict:
    q=str(query or '').strip()
    if not re.fullmatch(r'[A-Za-z0-9\s.&()\-+]{1,40}',q):
        raise ValueError('영문 회사명 또는 티커를 1~40자로 입력하세요.')
    n=max(1,min(int(limit),12))
    official = directory is not None
    if directory is None:
        listing,official=fetch_directory()
    else:
        listing=directory
    if not official:
        listing=[{'symbol':k,'code':k,'name':v,'market':'나스닥',
                  'verified':False,'listing_source':'내장 미국 주요 종목 (제한적)'}
                 for k,v in WATCHLIST.items()]
    needle=q.casefold().replace(' ','')
    results=[row for row in listing if needle in row['name'].casefold().replace(' ','') or needle in row['symbol'].casefold()]
    results.sort(key=lambda x:(x['symbol'].casefold()!=q.casefold(),
                               not x['symbol'].casefold().startswith(q.casefold()),
                               not x['name'].casefold().startswith(q.casefold()),x['symbol']))
    return {'query':q,'market':'nasdaq','source':'Nasdaq Trader 상장목록 (공개)' if official else '내장 30종목 제한 목록',
            'limited':not official,'total_listing_rows':len(listing) if official else None,
            'results':results[:n], 'warning':('상장목록은 실시간 체결 시세가 아니며 거래소 상태 변경과 차이가 있을 수 있습니다.'
                                         if official else '공식 상장목록을 받지 못해 주요 30종목에서만 검색했습니다. 전체 검색이 아닙니다.')}


def _numeric(value):
    try:
        v=float(value)
        return v if math.isfinite(v) else None
    except (ValueError,TypeError):
        return None


def _us_interest(symbol:str, name:str, detail:dict) -> dict|None:
    if detail.get('is_demo') or detail.get('is_stale') or detail.get('mode')!='스윙':
        return None
    quality=detail.get('quality_gate') or {}
    checks=quality.get('checks') or []
    met={x.get('key'):x.get('passed') is True for x in checks if isinstance(x,dict)}
    if not (met.get('trend') and met.get('viable') and quality.get('passed_count',0)>=3):
        return None
    price=_numeric(detail.get('reference'))
    if not price or price<=0:return None
    return {'symbol':symbol,'name':name,'market':'nasdaq','asof':str(detail.get('last_completed_bar') or '')[:10],
            'reference':round(price,3),'currency':'USD','passed_count':quality.get('passed_count',0),
            'checks':checks,'risk_reward':_numeric(detail.get('long_risk_reward')),
            'reason':'기술 조건 관찰 대상 · SEC 재무·공시·시장 전체 비교 미검증',
            'classification':'INTEREST_ONLY','not_actionable':True,'not_probability':True,
            'financial_gate':'NOT_VERIFIED_US','disclaimer':'미국주식 연구 관심 후보. 투자 추천이나 실거래 신호가 아닙니다.'}


def run_nasdaq_focus_scan(*,analyze:Callable[[str],dict],progress=None,directory=None):
    listing,online=fetch_directory() if directory is None else (directory,True)
    # Even with the full official listing, only transparent curated watchlist is scanned.
    official={x['symbol']:x for x in listing}
    selected=[(symbol,official[symbol]['name'] if symbol in official else name)
              for symbol,name in WATCHLIST.items() if not online or symbol in official][:MAX_US_DEEP]
    if not selected:
        raise NasdaqDataError('watchlist_unavailable','나스닥 관심 종목 목록을 확보하지 못했습니다.')
    date=datetime.now(NY).strftime('%Y-%m-%d')
    result={'status':'complete','market':'nasdaq','markets_scanned':['nasdaq'],'marketwide':False,
        'coverage_scope':f'주요 미국주식 {len(selected)}종목만 조회 (나스닥 전체 검색 아님)',
        'total_market_rows':len(listing) if online else None,
        'screen_passed':len(selected),'deep_target':len(selected),'deep_succeeded':0,'deep_failed':0,
        'recommended_count':0,'recommendations':[],'interest_candidates':[],'interest_count':0,
        'rejected':[],'rejection_summary':{},'data_date':date,'data_source':'Nasdaq Trader 종목목록 + Yahoo Finance'
          if online else '내장 주요 종목 목록 (제한적) + Yahoo Finance',
        'data_source_id':'nasdaq_listed' if online else 'nasdaq_limited',
        'data_lag':'미국시장 마지막 완료봉 기준, 가격 조회 지연 가능',
        'scan_limit':MAX_US_DEEP,'realtime':False,'method':'미국 관심종목 한정·미국 재무 위험 미검증·실거래 매수 후보 미선정',
        'risk_note':'공식 나스닥 전체 시장을 선별한 것이 아닙니다. SEC 재무 검증 부재로 확정 BUY는 출력하지 않습니다.',
        'persistence':'Render 메모리에서만 저장; 재시작 시 결과 소멸',
        'us_fundamentals_verified':False,'interest_only':True,'universe_source_reachable':online}
    for i,(symbol,name) in enumerate(selected):
        if progress:progress({'phase':'deep','done':i,'total':len(selected),
                              'message':f'미국 주식 제한 목록 {i}/{len(selected)} 검토 (전체 나스닥이 아님)'})
        try:
            detail=analyze(symbol)
            result['deep_succeeded']+=1
            item=_us_interest(symbol,name,detail)
            if item:result['interest_candidates'].append(item)
            else:result['rejected'].append({'symbol':symbol,'name':name,'reason':'추세·변동성 등 관심 조건 미충족 또는 시세 지연'})
        except Exception:
            result['deep_failed']+=1
            result['rejected'].append({'symbol':symbol,'name':name,'reason':'미국 시세 조회 실패·공급원 제한 가능'})
    result['interest_candidates'].sort(key=lambda x:(x['passed_count'],x['risk_reward'] or 0),reverse=True)
    result['interest_count']=len(result['interest_candidates'])
    result['incomplete']=result['deep_failed']>0
    for item in result['rejected']:
        reason=item['reason'];result['rejection_summary'][reason]=result['rejection_summary'].get(reason,0)+1
    if progress:progress({'phase':'complete','done':len(selected),'total':len(selected),
                          'message':f'미국 주식 {len(selected)}개 조사 · 연구 관심 후보 {result["interest_count"]}개 · 미검증 BUY 없음'})
    return result
