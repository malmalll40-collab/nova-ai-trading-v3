"""Public Naver investor flows. Read-only, bounded fetch; unofficial source.

This module intentionally fails closed on unknown fields, missing dates and units.
No user cookie, account data, request bypass or repeated scraping is performed.
"""
from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo
import re

import requests
from investor_flow import stock_code, summarize

KST = ZoneInfo('Asia/Seoul')
NAVER_NEW = 'https://stock.naver.com'
NAVER_LEGACY_MOBILE = 'https://m.stock.naver.com'
HEADERS = {
    'User-Agent': 'NOVA-InvestorFlow/1.0 (read-only, low-frequency; contact via site operator)',
    'Accept': 'application/json',
}
# All are explicitly *quantity* fields (shares); monetary amounts are not accepted.
COLUMNS = {
    'foreign': ('foreignerPureBuyQuant', 'foreignPureBuyQuant', 'foreignNetBuyQuant'),
    'institution': ('organPureBuyQuant', 'organizationPureBuyQuant', 'organNetBuyQuant'),
    'individual': ('individualPureBuyQuant', 'personalPureBuyQuant', 'individualNetBuyQuant'),
}
DATES = ('bizdate', 'businessDate', 'localDate', 'date', 'tradeDate', 'tradingDate')


class NaverFlowError(RuntimeError):
    """Safe, non-sensitive and actionable retrieval error."""


class NaverEndpointMissing(NaverFlowError):
    """Only a missing public endpoint allows trying the other documented endpoint."""


def _safe_number(value):
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if abs(value) <= 10**15 else None
    if isinstance(value, float):
        return int(value) if value.is_integer() and abs(value) <= 10**15 else None
    if not isinstance(value, str):
        return None
    v = value.strip().replace(',', '').replace(' ', '').replace('−','-')
    if not re.fullmatch(r'[+-]?\d+', v):
        return None
    n = int(v)
    return n if abs(n) <= 10**15 else None


def _date(value):
    if value is None:
        return None
    text = str(value).strip().replace('-', '').replace('.', '')
    if not re.fullmatch(r'\d{8}', text):
        return None
    try:
        datetime.strptime(text, '%Y%m%d')
    except ValueError:
        return None
    return text


def _rows(payload: object) -> list[dict]:
    """Recognize only explicitly documented public stock investor rows."""
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if not isinstance(payload, dict):
        return []
    for key in ('dealTrendInfos', 'content', 'items', 'list', 'trends'):
        val = payload.get(key)
        if isinstance(val, list):
            return [x for x in val if isinstance(x, dict)]
    for key in ('result', 'data', 'sections'):
        val = payload.get(key)
        if isinstance(val, (dict, list)):
            nested = _rows(val)
            if nested:
                return nested
    return []


def parse_naver(payload: object, code: str, *, now: datetime | None = None,
                endpoint: str = 'Naver public investor trend') -> dict:
    code = stock_code(code)
    now = now or datetime.now(KST)
    entries = _rows(payload)
    if not entries:
        raise NaverFlowError('네이버 수급 응답에 일별 자료가 없습니다.')
    unique: dict[str, dict] = {}
    unknown = 0
    for item in entries[:120]:
        date = next((d for key in DATES if (d := _date(item.get(key)))), None)
        if date is None:
            unknown += 1
            continue
        values = {}
        for investor, options in COLUMNS.items():
            values[investor] = next((_safe_number(item.get(k)) for k in options
                                    if _safe_number(item.get(k)) is not None), None)
        if not any(v is not None for v in values.values()):
            unknown += 1
            continue
        rec = {'stck_bsop_date':date, 'frgn_ntby_qty':values['foreign'],
               'orgn_ntby_qty':values['institution'], 'prsn_ntby_qty':values['individual']}
        if date in unique and unique[date] != rec:
            raise NaverFlowError('네이버 수급 동일 날짜에 서로 다른 수량이 있어 비교할 수 없습니다.')
        unique[date] = rec
    if not unique:
        raise NaverFlowError('네이버 수급의 날짜·주식 수량 단위를 확인할 수 없습니다.')
    result = summarize(list(unique.values()), code, now)
    if not result['has_data']:
        raise NaverFlowError('네이버 수급에서 확정 전 일자만 확인됩니다. 완료 거래일 자료가 없습니다.')
    result.update({
        'source': 'NAVER 증권 공개 종목별 투자자 동향 (비공식)',
        'source_detail': endpoint,
        'provider': 'naver',
        'independent_source_verified': False,
        'realtime_confirmed': False,
        'rows_unrecognized': unknown,
        'note': ('네이버 공개 화면의 투자자별 순매수 수량(주). 비공식 조회로 지연·변경·차단될 수 있습니다. '
                 '당일 미확정 자료 제외; 누락·표본 부족 시 누적 수급은 미확인. 다른 제공원과 교차검증되지 않았습니다.'),
    })
    return result


def _fetch_json(session, url: str):
    try:
        resp = session.get(url, headers=HEADERS, timeout=(3, 8), allow_redirects=False)
    except requests.RequestException as exc:
        raise NaverFlowError('네이버 조회 연결이 실패했습니다. 서버 네트워크를 확인하세요.') from exc
    if resp.status_code in (401, 403, 429):
        raise NaverFlowError(f'네이버 접근이 제한됐습니다 (HTTP {resp.status_code}). 재시도·우회하지 않습니다.')
    if resp.status_code in (301,302,303,307,308):
        raise NaverFlowError('네이버 수급 조회가 다른 페이지로 이동했습니다. 자료 형식을 확인하세요.')
    if resp.status_code == 404:
        raise NaverEndpointMissing('네이버 공개 API 경로가 변경되었습니다 (HTTP 404).')
    if resp.status_code != 200:
        raise NaverFlowError(f'네이버 수급 조회 실패 (HTTP {resp.status_code})')
    raw = resp.content
    if len(raw) > 2_000_000:
        raise NaverFlowError('네이버 응답 용량이 허용 범위를 넘었습니다.')
    if 'json' not in resp.headers.get('Content-Type', '').lower():
        raise NaverFlowError('네이버가 JSON이 아닌 응답을 보냈습니다.')
    try:
        return resp.json()
    except ValueError as exc:
        raise NaverFlowError('네이버 JSON 응답을 해석할 수 없습니다.') from exc


def _flow_coverage(flow: dict) -> tuple[int, int]:
    """Prefer complete comparable windows over row count alone."""
    periods = [r['period'] for r in flow.get('aggregate', []) if r.get('complete')]
    return (max(periods, default=0), len(flow.get('daily', [])))


def _overlap_conflicts(first: dict, second: dict) -> bool:
    """Compare overlapping completed-day shares; do not trust contradictory series."""
    latest = {row['date']: row for row in first.get('daily', [])}
    for row in second.get('daily', []):
        base = latest.get(row.get('date'))
        if base is None:
            continue
        for name in ('foreign', 'institution', 'individual'):
            if base.get(name) is not None and row.get(name) is not None and base[name] != row[name]:
                return True
    return False


def get_naver_flows(code: str, now: datetime | None = None, session=None) -> dict:
    """Return up to 20 completed daily rows, when the public source provides them.

    The integration snapshot normally contains only 5 rows. If fewer than 20
    completed sessions are available, make ONE read-only attempt against the
    stock-specific trend endpoint (bounded page size 25). Never synthesize
    missing quantity data, retry after blocks, or mix two sources' daily rows.
    """
    code = stock_code(code)
    now = now or datetime.now(KST)
    session = session or requests.Session()
    mobile_url = f'{NAVER_LEGACY_MOBILE}/api/stock/{code}/integration'
    mobile_result = None
    try:
        mobile_data = _fetch_json(session, mobile_url)
        mobile_result = parse_naver(mobile_data, code, now=now,
                                    endpoint='m.stock.naver.com 종목 통합 정보')
        if _flow_coverage(mobile_result)[0] >= 20:
            mobile_result['history_expansion_status'] = '20거래일 확보'
            return mobile_result
    except NaverEndpointMissing:
        pass
    except NaverFlowError as exc:
        # A blocked, rate-limited or unreachable mobile service must not
        # trigger an alternate request to bypass that restriction.
        if not str(exc).startswith(('네이버 수급 응답', '네이버 수급의', '네이버 수급에서 확정')):
            raise

    # Additional public trend history: 25 allows for a provisional current-day
    # row and non-trading holidays while remaining a strictly bounded request.
    modern_url = (f'{NAVER_NEW}/api/domestic/detail/{code}/trend'
                  '?tradeType=KRX&startIdx=0&pageSize=25')
    try:
        modern_data = _fetch_json(session, modern_url)
        expanded = parse_naver(modern_data, code, now=now,
                               endpoint='stock.naver.com 종목 투자자 동향')
    except NaverFlowError as exc:
        if mobile_result is None:
            raise
        mobile_result['history_expansion_status'] = (
            '추가 일별 자료 조회 실패 또는 응답 형식 불일치; 기존 기간만 제공')
        mobile_result['history_rows_available'] = len(mobile_result['daily'])
        return mobile_result

    if mobile_result is not None and _overlap_conflicts(mobile_result, expanded):
        mobile_result['history_rows_available'] = len(mobile_result['daily'])
        mobile_result['history_expansion_status'] = (
            '두 네이버 조회 경로의 같은 날짜 수급이 불일치하여 기간 확대 보류')
        return mobile_result

    if mobile_result is None or (
        expanded.get('as_of', '') >= mobile_result.get('as_of', '')
        and _flow_coverage(expanded) > _flow_coverage(mobile_result)
    ):
        chosen = expanded
    else:
        chosen = mobile_result
    days = len(chosen.get('daily', []))
    chosen['history_rows_available'] = days
    chosen['history_expansion_status'] = (
        '20거래일 확보' if _flow_coverage(chosen)[0] >= 20
        else f'완료 거래일 {days}일 확보; 10/20일 부족분은 미확인')
    return chosen
