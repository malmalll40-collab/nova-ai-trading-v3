/* Cache only immutable static shell, never cache prices or API responses. */
const CACHE_NAME='nova3-shell-v45-naver-fallback-20261112';
const FILES=['/','/static/styles.css','/static/app.js','/static/candles.js','/static/news.js','/static/recommendations.js','/static/recommendation_history.js','/static/investor_flow.js','/static/journal.js','/static/monitor.js','/manifest.webmanifest','/static/icons/icon-192.png','/static/icons/icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET')return;
 const url=new URL(e.request.url);
 if(url.origin!==self.location.origin)return;
 if(url.pathname.startsWith('/api/')||url.pathname==='/healthz')return; // network-only, no stale trading data
 if(e.request.mode==='navigate'){
   e.respondWith(fetch(e.request).catch(()=>caches.match('/')));return;
 }
 if(FILES.includes(url.pathname))e.respondWith(caches.match(e.request).then(x=>x||fetch(e.request)));
});
