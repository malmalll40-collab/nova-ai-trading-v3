# NOVA v4.5 + high-precision research observer (2026-11-12)

- V4.5 investor flows & quote API/UX are retained.
- Only read-only field `high_precision_research` and analysis screen panel added.
- 13-role voting, strict signal, final actionable BUY/SELL, scanner and trade/order policies are unchanged.
- Missing or unverified historical flow, sector or benchmark data results in `DATA_INCOMPLETE`; no auto-promotion to BUY.
- Performance benefit is UNVERIFIED. No order execution approved.
- To roll back: restore previous deployment ZIP from main's preceding Git commit or `/mnt/data/files/NOVA_v4_5_update.zip`.
