"""NOVA v3 mobile PWA API: read-only, no trading endpoints and no broker order capability.
Start locally with `python server.py`; see README for LAN/public access.
"""
from __future__ import annotations

import hmac
import hashlib
import secrets
import math
import os
from pathlib import Path
import threading
import time
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from zoneinfo import ZoneInfo

import pandas as pd
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from engine import Config, feature_frame, decide
from backtest import run_backtest
from data_sources import demo_data, yahoo_data, kis_data, ticker_format, market_zone
from stock_lookup import search_stocks
from dart_financial import DARTError, get_client
from finance_gate import assess_financial
from signal_policy import resolve_final_signal
from signal_journal import evaluate_batch
from news_sources import fetch_news, NewsUnavailable
from signal_quality import quality_gate
from quality_validation import quality_comparison
from signal_stats import signal_performance
from higher_timeframes import PERIODS, chart_data, fetch_long_daily
from market_scanner import run_market_scan, MarketScanError, diagnose_connection, completed_dates
from public_market_data import FSCStockClient
from recommendation_backtest import run_screen_history
from investor_flow import stock_code, get_flows, get_quote, get_intraday

BASE = Path(__file__).resolve().parent
ASSETS = BASE / 'static'
app = FastAPI(title='NOVA AI Trading Mobile', docs_url=None, redoc_url=None, openapi_url=None)
app.mount('/static', StaticFiles(directory=ASSETS), name='static')
CACHE_LOCK = threading.Lock()
CACHE = {}
RATE = {}
CACHE_TTL = 52
FIN_CACHE_TTL = 6 * 3600
JOURNAL_CACHE_LOCK = threading.Lock()
JOURNAL_FRAMES = {}
JOURNAL_CACHE_TTL = 12 * 60
WATCH_CACHE_TTL = 90
MAX_CACHE = 72
KST = ZoneInfo('Asia/Seoul')
SCAN_LOCK = threading.RLock()
SCAN_STATE = {'status':'idle','progress':{},'result':None,'error':None,'started_monotonic':None,'market':'all'}
SCAN_JOB = None
BACKTEST_LOCK = threading.RLock()
BACKTEST_STATE = {'status':'idle','result':None,'error':None,'progress':{},'market':'all','weeks':4}
BACKTEST_JOB = None
LABEL = {'BUY':'매수 후보', 'SELL':'매도·보유분 축소 검토', 'HOLD':'관망'}
MODES = {'1분','5분','스윙'}
SOURCES = {'yahoo','kis','demo'}
AUTH_COOKIE = 'nova3_auth'
REMEMBER_SECONDS = 30 * 24 * 3600
SESSION_SECONDS = 12 * 3600

if os.environ.get('NOVA_PUBLIC_DEPLOY') == '1' and len(os.environ.get('NOVA_ACCESS_TOKEN','')) < 16:
    raise RuntimeError('공개 서버 배포시 NOVA_ACCESS_TOKEN을 16자 이상으로 설정하세요.')


def _cookie_key(token: str) -> bytes:
    # Server-only key. Changing NOVA_ACCESS_TOKEN invalidates all remembered devices.
    return hashlib.sha256(('nova3-cookie:v1:' + token).encode('utf-8')).digest()


def _cookie_valid(value: str, token: str) -> bool:
    if not value or not token:
        return False
    try:
        version, expiry, nonce, signature = value.split('.')
        if version != 'v1' or not expiry.isdecimal() or len(nonce) != 32 or len(signature) != 64:
            return False
        if not all(ch in '0123456789abcdef' for ch in nonce + signature):
            return False
        exp = int(expiry)
        now = int(time.time())
        if not now < exp <= now + REMEMBER_SECONDS:
            return False
        message = f'{version}.{expiry}.{nonce}'
        expected = hmac.new(_cookie_key(token), message.encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature)
    except (ValueError, TypeError):
        return False


def _is_authenticated(request: Request) -> bool:
    token = os.environ.get('NOVA_ACCESS_TOKEN', '')
    if not token:
        return True
    supplied = request.headers.get('Authorization', '')
    if supplied and hmac.compare_digest(supplied, 'Bearer ' + token):
        return True
    return _cookie_valid(request.cookies.get(AUTH_COOKIE, ''), token)


def _authorize(request: Request):
    if not _is_authenticated(request):
        raise HTTPException(401, '인증이 만료됐습니다. 설정에서 서버 접근 토큰을 입력하세요.')


def _secure_cookie(request: Request) -> bool:
    # Render sets NOVA_PUBLIC_DEPLOY=1. Local HTTP development continues to work.
    return os.environ.get('NOVA_PUBLIC_DEPLOY') == '1' or request.url.scheme == 'https'


@app.get('/api/auth/status')
def auth_status(request: Request):
    return JSONResponse({'authenticated': _is_authenticated(request),
                         'token_required': bool(os.environ.get('NOVA_ACCESS_TOKEN'))},
                        headers={'Cache-Control': 'no-store'})


@app.post('/api/auth/login')
def auth_login(request: Request, body: dict):
    _limit(request)
    expected = os.environ.get('NOVA_ACCESS_TOKEN', '')
    supplied = body.get('token', '')
    remember = body.get('remember') is True
    if not isinstance(supplied, str) or len(supplied) > 1024:
        raise HTTPException(400, '올바르지 않은 토큰 형식입니다.')
    if expected and not hmac.compare_digest(supplied, expected):
        raise HTTPException(401, '서버 접근 토큰이 일치하지 않습니다.')
    response = JSONResponse({'authenticated': True, 'remembered': remember, 'days': 30 if remember else 0},
                            headers={'Cache-Control': 'no-store'})
    if expected:
        duration = REMEMBER_SECONDS if remember else SESSION_SECONDS
        expiry = str(int(time.time()) + duration)
        message = f'v1.{expiry}.{secrets.token_hex(16)}'
        signature = hmac.new(_cookie_key(expected), message.encode(), hashlib.sha256).hexdigest()
        response.set_cookie(AUTH_COOKIE, message + '.' + signature,
                            max_age=duration if remember else None,
                            httponly=True, secure=_secure_cookie(request),
                            samesite='lax', path='/')
    return response


@app.post('/api/auth/logout')
def auth_logout(request: Request):
    response = JSONResponse({'authenticated': False}, headers={'Cache-Control':'no-store'})
    response.delete_cookie(AUTH_COOKIE, path='/', secure=_secure_cookie(request), httponly=True, samesite='lax')
    return response


def _limit(request: Request):
    ip = request.client.host if request.client else 'unknown'
    now = time.monotonic()
    with CACHE_LOCK:
        ts = [x for x in RATE.get(ip,[]) if now-x < 60]
        if len(ts) >= 24:
            raise HTTPException(429, '요청이 너무 많습니다. 잠시 뒤 다시 조회하세요.')
        ts.append(now)
        RATE[ip] = ts
        if len(RATE)>500:
            RATE.clear()


def _cached(key, make, ttl=CACHE_TTL):
    now = time.monotonic()
    with CACHE_LOCK:
        entry = CACHE.get(key)
        if entry and now-entry[0] <= ttl:
            return dict(entry[1], cached=True, cache_age_seconds=round(now-entry[0]))
    result = make()
    with CACHE_LOCK:
        if len(CACHE)>=MAX_CACHE:
            CACHE.clear()
        CACHE[key]=(time.monotonic(),result)
    return dict(result,cached=False,cache_age_seconds=0)


def _safe_float(n):
    try:
        v=float(n)
        return round(v,6) if math.isfinite(v) else None
    except (ValueError,TypeError):return None


def _last_age_minutes(bar:pd.Timestamp, ticker:str, mode:str)->float|None:
    try:
        stamp = pd.Timestamp(bar)
        if stamp.tzinfo is None:
            stamp=stamp.tz_localize(market_zone(ticker))
        if mode=='1분':stamp+=pd.Timedelta(minutes=1)
        elif mode=='5분':stamp+=pd.Timedelta(minutes=5)
        else:stamp+=pd.Timedelta(hours=16 if market_zone(ticker).key=='America/New_York' else 15,minutes=30 if market_zone(ticker).key=='Asia/Seoul' else 0)
        return max(0,round((pd.Timestamp.now(tz='UTC')-stamp.tz_convert('UTC')).total_seconds()/60,1))
    except Exception: return None



def _get_financial_state(symbol: str, mode: str) -> tuple[str, str, int | None]:
    """Consistent DART assessment for both individual and watchlist signals.

    DART is a best-effort overlay. A missing/failed response MUST never
    promote a domestic swing BUY. We do not leak credentials or provider URLs.
    """
    if mode != '스윙':
        return 'NOT_APPLIED', '단타는 재무 필터를 적용하지 않습니다.', None
    if not symbol.endswith(('.KS', '.KQ')):
        return 'NOT_SUPPORTED', 'OpenDART 미지원 해외 종목입니다.', None
    try:
        client = get_client()
        fp = hashlib.sha256(client.key.encode()).hexdigest()[:12]
        overview = _cached(('dart', fp, symbol, 3),
                           lambda: client.overview(symbol, years=3), ttl=FIN_CACHE_TTL)
        gate = assess_financial(overview)
        return gate['gate'], gate['reason'], gate['as_of_annual_year']
    except Exception:
        # Never expose provider details, API key or auth headers in a response.
        return 'UNKNOWN', 'OpenDART 재무정보 미확인: 검증할 수 없습니다.', None



def _payload(symbol:str,mode:str,source:str,cost_bps:int)->dict:
    cfg = Config.for_mode(mode, cost_bps)
    if source=='demo':
        market=demo_data(mode)
    elif source=='yahoo':
        market=yahoo_data(symbol,mode)
    else:
        key=os.environ.get('KIS_APP_KEY','')
        secret=os.environ.get('KIS_APP_SECRET','')
        if not key or not secret:
            raise ValueError('KIS 연결을 위해 서버 환경변수 KIS_APP_KEY 및 KIS_APP_SECRET이 필요합니다.')
        market=kis_data(symbol,mode,key,secret)
    f=feature_frame(market.bars,mode)
    d=decide(f,cfg)
    bt=run_backtest(market.bars,cfg)
    q=quality_gate(f,cfg,raw_signal=d.signal)
    compared=quality_comparison(f,cfg)
    signal_stats=signal_performance(f,cfg)
    age=_last_age_minutes(f.index[-1],market.symbol if not market.synthetic else '005930.KS',mode)
    fresh_limit=8 if mode=='1분' else 25 if mode=='5분' else 3*24*60
    stale = False if market.synthetic else age is None or age > fresh_limit
    fgate, fnote, fyear = _get_financial_state(market.symbol, mode) if not market.synthetic else ('NOT_APPLIED', '가상 데이터', None)
    policy = resolve_final_signal(q['strict_signal'], mode=mode, symbol=market.symbol,
                                  financial_gate=fgate, finance_reason=fnote,
                                  stale=stale, is_demo=market.synthetic)
    chart=f.iloc[-125:][['Open','High','Low','Close','Volume','ema20','ema50']]
    times=[x.isoformat() for x in chart.index]
    # Note: role #13 is a risk veto; it is NOT one of the 12 counted directional votes.
    return {
        'symbol': market.symbol,
        'mode':mode,'source':source,'provider':market.provider,
        'is_demo':market.synthetic, 'is_stale':stale,
        'price_age_minutes':age, 'fetched_at':market.retrieved_at,
        'quote_time':market.quote_time,'last_completed_bar':d.time,
        'freshness':market.freshness,'provider_note':market.note,
        'currency':market.currency,
        'quote':_safe_float(market.quote),'reference':_safe_float(d.reference),
        'signal':policy['final_signal'],
        'signal_label':('관망 · 지난 완료봉' if stale else LABEL[policy['final_signal']]),
        'strict_signal':q['strict_signal'],
        'raw_signal':d.signal,'quality_gate':q,'quality_comparison':compared,
        'signal_performance':signal_stats,
        'signal_is_current':policy['signal_is_current'],
        'final_actionable_signal':policy['final_actionable_signal'],
        'historical_signal':policy['historical_signal'],
        'final_reason':policy['final_reason'],
        'financial_gate':fgate, 'finance_note':fnote,
        'financial_asof_year':fyear,
        'rsi':_safe_float(d.rsi),
        'atr':_safe_float(d.atr),
        'buy_votes':d.buy_votes,'sell_votes':d.sell_votes,'hold_votes':d.hold_votes,
        'risk_veto':d.risk_veto,'risk_message':d.risk_message,
        'long_stop_reference':_safe_float(d.stop),
        'long_target_reference':_safe_float(d.target),
        'long_risk_reward':_safe_float(d.risk_reward),
        'cost_bps_one_side':cost_bps,
        'max_hold_bars':cfg.max_hold_bars,
        'backtest_exit_policy':'종료봉 종가에서 전략과 매수보유 모두 가상청산(편도 수수료 적용)',
        'votes':[{'role':x.role,'direction':x.direction,'label':x.label,'reason':x.reason,'category':x.category} for x in d.votes],
        'chart':{'dates':times,
                 'open':[_safe_float(x) for x in chart['Open']],
                 'high':[_safe_float(x) for x in chart['High']],
                 'low':[_safe_float(x) for x in chart['Low']],
                 'volume':[_safe_float(x) for x in chart['Volume']],
                 'close':[_safe_float(x) for x in chart['Close']],
                 'ema20':[_safe_float(x) for x in chart['ema20']],
                 'ema50':[_safe_float(x) for x in chart['ema50']]},
        'backtest':{
            'total_return_pct':_safe_float(bt.total_return*100),
            'benchmark_return_pct':_safe_float(bt.benchmark_return*100),
            'max_drawdown_pct':_safe_float(bt.max_drawdown*100),
            'closed_trades':bt.closed_trades,
            'win_rate_pct':_safe_float(bt.win_rate*100 if bt.win_rate is not None else None),
            'directional_hit_rate_pct':_safe_float(bt.directional_hit_rate*100 if bt.directional_hit_rate is not None else None),
            'directional_samples':bt.directional_samples,
            'last_20pct_rate_pct':_safe_float(bt.latest_20pct_hit_rate*100 if bt.latest_20pct_hit_rate is not None else None),
            'last_20pct_samples':bt.latest_20pct_samples,
            'buy_signals':bt.buy_signals,'sell_signals':bt.sell_signals,
            'curve':{'dates':[str(i) for i in bt.curve.index[::max(1,len(bt.curve)//90)]],
                      'strategy':[_safe_float(v) for v in bt.curve['전략 자산'].iloc[::max(1,len(bt.curve)//90)]],
                      'benchmark':[_safe_float(v) for v in bt.curve['비교 매수보유'].iloc[::max(1,len(bt.curve)//90)]]},
            'recent_trades':[
                {'entry':str(x['진입시점']),'exit':str(x['청산시점']),
                 'pnl_pct':_safe_float(x['수익률']*100),'reason':str(x['청산사유'])}
                for x in bt.trades.tail(8).iloc[::-1].to_dict('records')],
        },
        'disclaimer':'규칙 기반 분석이며 미래 수익률을 예측·보장하지 않습니다. 마지막 완료봉에 근거하며 매도는 보유분 축소 의견입니다.',
    }


@app.get('/')
def index():
    return FileResponse(ASSETS/'index.html',headers={'Cache-Control':'no-cache'})

@app.get('/favicon.ico')
def favicon():
    # Some browsers request the legacy path even when a PNG icon link exists.
    return FileResponse(ASSETS/'icons/icon-192.png',media_type='image/png',headers={'Cache-Control':'public, max-age=86400'})

@app.get('/manifest.webmanifest')
def manifest():
    return FileResponse(ASSETS/'manifest.webmanifest',media_type='application/manifest+json')

@app.get('/sw.js')
def service_worker():
    return FileResponse(ASSETS/'sw.js',media_type='application/javascript',headers={'Cache-Control':'no-store','Service-Worker-Allowed':'/'})

@app.get('/healthz')
def healthz():
    return {'status':'ok','orders_enabled':False,'app_version':'4.5','stock_name_search':True,'dart_feature':True,'financial_risk_filter':True,'historical_fundamental_backtest':False,'forward_signal_journal':True,'persistent_server_journal':False,'watchlist_visible_tab_only':True,'push_notifications':False,'strict_signal_quality':True,'quality_hit_rate_verified':False,'final_signal_policy':'financial-then-notification','intraday_journal_verified':False,'candlestick_chart':True,'stock_news':True,'news_affects_signal':False,'signal_role_statistics':True,'calibrated_buy_probability':False,'higher_timeframe_charts':True,'higher_timeframes_affect_signal':False,'market_recommendations':True,'market_scan_requires_krx_api':False,'market_scan_fsc_tplus1':True,'realtime_market_scan':False,'server_persistent_scan_results':False,'historical_market_screen_backtest':True,'full_recommendation_strategy_backtested':False,'investor_flows_daily':True,'quote_rest_polling':True,'realtime_quote_websocket':False}

@app.get('/api/status')
def status(request:Request):
    _authorize(request)
    return {'kis_configured':bool(os.environ.get('KIS_APP_KEY') and os.environ.get('KIS_APP_SECRET')),
            'dart_configured':len(os.environ.get('OPENDART_API_KEY','').strip())==40,
            'news_provider_configured':bool(os.environ.get('NAVER_NEWS_CLIENT_ID') and os.environ.get('NAVER_NEWS_CLIENT_SECRET')),
            'news_provider_fallback':'google_news_rss',
            'krx_configured':bool(os.environ.get('KRX_API_KEY','').strip()),
            'fsc_configured':bool(os.environ.get('FSC_STOCK_API_KEY','').strip()),
            'marketwide_scanner':'금융위원회 주식시세 T+1 우선, KRX 선택 지원',
            'server_time_utc':datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'yahoo_realtime_guaranteed':False,'streaming':False,'real_orders':False,'investor_flow_enabled':True,'quote_snapshot_refresh_seconds':20,
            'lan_without_auth':os.environ.get('NOVA_BIND_HOST')=='0.0.0.0' and not bool(os.environ.get('NOVA_ACCESS_TOKEN'))}

# v4.5: read-only KIS investor flows and near-live REST quotation snapshots.
# They are not blended into the 1st-stage selection or historical backtest.
def _kis_creds():
    key, secret = os.environ.get('KIS_APP_KEY', '').strip(), os.environ.get('KIS_APP_SECRET', '').strip()
    if not key or not secret:
        raise HTTPException(503, 'KIS 앱 키가 미설정입니다. Render에 KIS_APP_KEY와 KIS_APP_SECRET을 설정하세요.')
    return key, secret

@app.get('/api/market/flows')
def market_flows(request: Request, symbol: str = '005930'):
    _authorize(request)
    _limit(request)
    try: code = stock_code(symbol)
    except ValueError as exc: raise HTTPException(422, str(exc)) from None
    key, secret = _kis_creds()
    try:
        result = _cached(('v45_flows', code), lambda: get_flows(key, secret, code), ttl=300)
    except Exception:
        raise HTTPException(502, 'KIS 투자자별 매매동향 수신 실패. API 사용 승인·응답 범위·데이터 시점을 확인하세요.') from None
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})

@app.get('/api/market/intraday')
def market_intraday(request: Request, symbol: str = '005930'):
    _authorize(request)
    _limit(request)
    try: code = stock_code(symbol)
    except ValueError as exc: raise HTTPException(422, str(exc)) from None
    key, secret = _kis_creds()
    try:
        result = _cached(('v45_intraday', code, datetime.now(KST).date().isoformat()),
                         lambda: get_intraday(key, secret, code), ttl=75)
    except Exception:
        raise HTTPException(502, 'KIS 당일 분봉 수신 실패. 서버 API 및 장중 데이터 제공 여부를 확인하세요.') from None
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})

@app.get('/api/market/quote')
def market_quote(request: Request, symbol: str = '005930'):
    _authorize(request)
    _limit(request)
    try: code = stock_code(symbol)
    except ValueError as exc: raise HTTPException(422, str(exc)) from None
    key, secret = _kis_creds()
    try:
        result = _cached(('v45_quote', code), lambda: get_quote(key, secret, code), ttl=10)
    except Exception:
        raise HTTPException(502, 'KIS 현재가 수신 실패. API 사용 승인·시장 시간·네트워크를 확인하세요.') from None
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})

@app.get('/api/news')
def news_search(request: Request, symbol: str = '', name: str = ''):
    """Read-only stock news, explicitly not used by the trade signal engine."""
    _authorize(request)
    _limit(request)
    try:
        if not symbol and not name:
            raise ValueError('종목명 또는 종목코드를 입력하세요.')
        # TTL avoids provider overuse and prevents accidental real-time claims.
        query_key=(symbol.strip().upper(),name.strip())
        result=_cached(('v39_news',query_key),
                       lambda:fetch_news(*query_key),ttl=600)
        return JSONResponse(result,headers={'Cache-Control':'no-store'})
    except ValueError as exc:
        raise HTTPException(422,str(exc)) from None
    except NewsUnavailable as exc:
        raise HTTPException(503,str(exc)) from None
    except Exception:
        raise HTTPException(502,'뉴스 수신 실패. 원문 검색 링크를 이용해 주세요.') from None


@app.get('/api/chart/history')
def long_chart(request: Request, symbol: str = '005930.KS', source: str = 'yahoo', timeframe: str = '1w'):
    """Dedicated chart-only aggregation; DOES NOT change NOVA's trading signals."""
    _authorize(request)
    _limit(request)
    if source not in SOURCES:raise HTTPException(422,'시세 공급원은 yahoo/kis/demo 중 선택하세요.')
    if timeframe not in PERIODS:raise HTTPException(422,'차트 주기는 일봉·주봉·월봉·연봉만 지원합니다.')
    if source=='demo':symbol='DEMO'
    else:
        try:symbol=ticker_format(symbol)
        except ValueError as exc:raise HTTPException(422,str(exc)) from None
    if source=='kis' and not symbol.endswith(('.KS','.KQ')):
        raise HTTPException(422,'KIS는 국내 종목에만 적용할 수 있습니다.')
    try:
        # Expensive max-history download shared across W/M/Y chart selections.
        hist=_cached(('v41-daily-history',source,symbol),lambda:{'bars':fetch_long_daily(symbol,source)},ttl=1800)['bars']
        result=chart_data(hist,timeframe,symbol,source,synthetic=(source=='demo'))
        return JSONResponse(result,headers={'Cache-Control':'no-store'})
    except ValueError as exc:raise HTTPException(422,str(exc)) from None
    except Exception as exc:
        # Never return provider request headers, tokens or tracebacks.
        raise HTTPException(502,f'장기 차트 자료 조회 실패 ({type(exc).__name__}). 공급원·종목·네트워크를 확인하세요.') from None


@app.get('/api/search')
def stock_search(request: Request, q: str = ''):
    _authorize(request)
    _limit(request)
    if not 1 <= len(q.strip()) <= 40:
        raise HTTPException(422, '검색어를 1~40자로 입력하세요.')
    try:
        result = _cached(('stock_search', q.strip().casefold()), lambda: search_stocks(q))
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})




@app.get('/api/fundamentals')
def fundamentals(request: Request, symbol: str, years: int = 3):
    """Read-only official OpenDART; no historical trading-signal look-ahead."""
    _authorize(request)
    _limit(request)
    try:
        symbol=ticker_format(symbol)
        client=get_client()
        # Cache key includes a fingerprint of the configured key, not the key itself.
        key_fingerprint=hashlib.sha256(client.key.encode()).hexdigest()[:12]
        result=_cached(('dart',key_fingerprint,symbol,years),
                       lambda:client.overview(symbol,years=years),ttl=FIN_CACHE_TTL)
        # Pure current-time overlay. Deliberately not inserted into historical OHLC backtests.
        body=dict(result)
        body['financial_gate']=assess_financial(body)
        return JSONResponse(body,headers={'Cache-Control':'no-store'})
    except DARTError as exc:
        code=exc.code
        status=503 if code in ('no_key','network','registry_network','020','012','800') else 422
        raise HTTPException(status, {'code':code,'message':str(exc)}) from None
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    except Exception:
        # Do not accidentally leak key via requests exception's URL in response.
        raise HTTPException(502, 'DART 재무정보 처리 실패. 서버 로그를 확인하세요.') from None



def _journal_daily_bars(symbol: str, source: str) -> pd.DataFrame:
    """Use finished daily candles; never cache an unfinished in-session bar."""
    key = (symbol, source)
    now = time.monotonic()
    with JOURNAL_CACHE_LOCK:
        cached = JOURNAL_FRAMES.get(key)
        if cached is not None and now - cached[0] <= JOURNAL_CACHE_TTL:
            return cached[1].copy()
    if source == 'yahoo':
        d = yahoo_data(symbol, '스윙').bars
    elif source == 'kis':
        key_id = os.environ.get('KIS_APP_KEY', '')
        secret = os.environ.get('KIS_APP_SECRET', '')
        if not key_id or not secret:
            raise ValueError('KIS API 키가 서버에 설정되지 않았습니다.')
        d = kis_data(symbol, '스윙', key_id, secret).bars
    else:
        raise ValueError('지원되지 않는 시세 공급원입니다.')
    with JOURNAL_CACHE_LOCK:
        if len(JOURNAL_FRAMES) >= 15:
            JOURNAL_FRAMES.clear()
        JOURNAL_FRAMES[key] = (time.monotonic(), d.copy())
    return d


@app.post('/api/journal/evaluate')
def journal_evaluate(request: Request, body: dict):
    """Evaluate browser-held snapshots, with no server-side journal persistence."""
    _authorize(request)
    _limit(request)
    try:
        return JSONResponse(evaluate_batch(body.get('records'), _journal_daily_bars),
                            headers={'Cache-Control': 'no-store'})
    except (TypeError, ValueError) as exc:
        raise HTTPException(422, str(exc)) from None



# v3.6: bounded foreground watchlist scan. Does not register cron jobs or trade orders.
# A scan generates CURRENT rule-based signals; its output is NOT a backtested probability.
def _watch_item(symbol: str, mode: str, source: str, cost_bps: int) -> dict:
    key = ('v381-watch-item', source, symbol, mode, cost_bps)

    def calculate() -> dict:
        if source == 'yahoo':
            market = yahoo_data(symbol, mode)
        else:
            app_key, secret = os.environ.get('KIS_APP_KEY', ''), os.environ.get('KIS_APP_SECRET', '')
            if not (app_key and secret):
                raise ValueError('KIS 연동 키가 설정되지 않았습니다.')
            market = kis_data(symbol, mode, app_key, secret)
        features = feature_frame(market.bars, mode)
        cfg=Config.for_mode(mode, cost_bps)
        decision = decide(features, cfg)
        q=quality_gate(features,cfg,raw_signal=decision.signal)
        age = _last_age_minutes(features.index[-1], market.symbol, mode)
        stale_limit = 8 if mode == '1분' else 25 if mode == '5분' else 3 * 24 * 60
        is_stale = age is None or age > stale_limit
        result = {
            'symbol': market.symbol, 'mode': mode, 'source': source,
            'status': 'ok', 'technical': decision.signal,
            'combined': q['strict_signal'], 'financial_gate': 'NOT_APPLIED',
            'quality_gate': q,
            'finance_note': '단타에는 현재 재무 위험 필터를 적용하지 않습니다.',
            'reference': _safe_float(decision.reference), 'currency': market.currency,
            'stop': _safe_float(decision.stop), 'target': _safe_float(decision.target),
            'risk_reward': _safe_float(decision.risk_reward),
            'bar_time': decision.time, 'provider': market.provider,
            'fetched_at': market.retrieved_at,
            'price_age_minutes': age, 'is_stale': is_stale or bool(market.synthetic), 'is_demo': bool(market.synthetic),
            'freshness': market.freshness, 'provider_note': market.note,
            'risk_veto': decision.risk_veto,
            'note': '완료봉 기반 규칙형 신호. 실시간 시세 보장 및 주문 실행 없음.'
        }
        financial_gate, finance_note, financial_year = _get_financial_state(symbol, mode)
        policy = resolve_final_signal(q['strict_signal'], mode=mode, symbol=symbol,
                                      financial_gate=financial_gate,
                                      finance_reason=finance_note, stale=is_stale,
                                      is_demo=bool(market.synthetic))
        result['combined'] = policy['final_signal']
        result['historical_signal'] = policy['historical_signal']
        result['final_actionable_signal'] = policy['final_actionable_signal']
        result['signal_is_current'] = policy['signal_is_current']
        result['final_reason'] = policy['final_reason']
        result['financial_gate'] = financial_gate
        result['finance_note'] = finance_note
        result['financial_asof_year'] = financial_year
        return result

    return _cached(key, calculate, ttl=WATCH_CACHE_TTL)


@app.post('/api/watch/scan')
def watch_scan(request: Request, body: dict):
    """Read-only bounded batch, no disk persistence, no orders, no background task."""
    _authorize(request)
    _limit(request)
    symbols = body.get('symbols')
    modes = body.get('modes', ['5분', '스윙'])
    source = body.get('source', 'yahoo')
    cost_bps = body.get('cost_bps', 15)
    if not isinstance(symbols, list) or not 1 <= len(symbols) <= 5 or not all(isinstance(x, str) for x in symbols):
        raise HTTPException(422, '한 번에 1~5개 종목만 감시할 수 있습니다.')
    if not isinstance(modes, list) or not 1 <= len(modes) <= 2 or not all(isinstance(x,str) for x in modes) or len(set(modes)) != len(modes) or any(x not in MODES for x in modes):
        raise HTTPException(422, '분석 주기는 1분·5분·스윙 중 중복 없이 최대 2개를 선택하세요.')
    if source not in ('yahoo', 'kis'):
        raise HTTPException(422, '관심종목 감시는 Yahoo 또는 KIS 시세만 지원합니다.')
    if type(cost_bps) is not int or not 0 <= cost_bps <= 100:
        raise HTTPException(422, '거래비용은 편도 0~100bp로 지정하세요.')
    try:
        normalized = [ticker_format(x) for x in symbols]
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    if len(set(normalized)) != len(normalized):
        raise HTTPException(422, '중복 종목을 제거해 주세요.')
    if source == 'kis' and any(not s.endswith(('.KS', '.KQ')) for s in normalized):
        raise HTTPException(422, 'KIS 감시는 국내 상장 종목코드만 지원합니다.')
    tasks = [(symbol, mode) for symbol in normalized for mode in modes]
    rows = {}
    # Max 3 concurrent remote data calls for the small free Render instance.
    with ThreadPoolExecutor(max_workers=min(3, len(tasks))) as pool:
        futures = {pool.submit(_watch_item, s, m, source, cost_bps): (s, m) for s, m in tasks}
        for future in as_completed(futures):
            s, m = futures[future]
            try:
                rows[(s, m)] = future.result()
            except Exception as exc:
                # No provider URL or API credentials are included in client-facing errors.
                rows[(s, m)] = {'symbol': s, 'mode': m, 'source': source, 'status': 'error',
                                'error': f'시세 또는 재무자료 조회 실패 ({type(exc).__name__}).',
                                'is_stale': True, 'combined': None}
    results = [rows[key] for key in tasks]
    return JSONResponse({'status': 'ok', 'version': '3.8.1',
                         'scanned_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
                         'requested': len(tasks), 'successful': sum(x['status'] == 'ok' for x in results),
                         'results': results, 'polling': 'visible-tab-only', 'real_orders': False},
                        headers={'Cache-Control': 'no-store'})


@app.get('/api/analysis')
def analysis(request:Request,symbol:str='AAPL',mode:str='스윙',source:str='yahoo',cost_bps:int=15):
    _authorize(request)
    _limit(request)
    if mode not in MODES:raise HTTPException(422,'분석 주기는 1분, 5분, 스윙 중에서 선택하세요.')
    if source not in SOURCES:raise HTTPException(422,'올바르지 않은 공급원입니다.')
    if not 0<=cost_bps<=100:raise HTTPException(422,'거래비용은 편도 0~100bp로 입력하세요.')
    if source=='demo':symbol='DEMO'
    else:
        try: symbol=ticker_format(symbol)
        except ValueError as exc: raise HTTPException(422,str(exc)) from exc
    if source=='kis' and not (symbol.endswith('.KS') or symbol.endswith('.KQ')):
        raise HTTPException(422,'KIS는 국내 6자리 종목코드만 지원합니다.')
    try:
        value=_cached((source,symbol,mode,cost_bps),lambda:_payload(symbol,mode,source,cost_bps))
    except ValueError as exc:
        raise HTTPException(422,str(exc)) from exc
    except Exception as exc:
        raise HTTPException(502, f'시세 조회/분석 실패 ({type(exc).__name__}). 종목·데이터 기간·공급원/네트워크를 확인하세요.') from exc
    return JSONResponse(value,headers={'Cache-Control':'no-store'})

if __name__=='__main__':
    import uvicorn
    uvicorn.run(app,host=os.environ.get('NOVA_BIND_HOST','127.0.0.1'),port=int(os.environ.get('PORT','8000')))


# v4.2 — Market-wide EOD recommendation screener. No automated orders.
def _scan_snapshot():
    with SCAN_LOCK:
        state=dict(SCAN_STATE)
    state.pop('started_monotonic', None)
    state['krx_configured']=bool(os.environ.get('KRX_API_KEY','').strip())
    state['fsc_configured']=bool(os.environ.get('FSC_STOCK_API_KEY','').strip())
    state['available_sources']=['fsc','krx']
    state['storage']='server_memory_only'
    return state


def _scan_worker(market: str, job_id: str, provider: str, api_key: str):
    def progress(p):
        with SCAN_LOCK:
            if SCAN_STATE.get('job_id')==job_id:
                SCAN_STATE['progress']=p
    try:
        client = FSCStockClient(api_key) if provider == 'fsc' else None
        result=run_market_scan(market=market,api_key=api_key,client=client,
              analyze=lambda sym:_payload(sym,'스윙','yahoo',15),progress=progress)
        with SCAN_LOCK:
            if SCAN_STATE.get('job_id')==job_id:
                SCAN_STATE.update(status='complete',result=result,error=None,
                   completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'),
                   completed_monotonic=time.monotonic())
    except MarketScanError as err:
        with SCAN_LOCK:
            if SCAN_STATE.get('job_id')==job_id:
                SCAN_STATE.update(status='failed',result=None,
                  error={'code':err.code,'message':str(err)},
                  completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))
    except Exception:
        with SCAN_LOCK:
            if SCAN_STATE.get('job_id')==job_id:
                SCAN_STATE.update(status='failed',result=None,
                  error={'code':'internal','message':'시장 검색에 실패했습니다. 서버 로그와 시세 공급원을 확인하세요.'},
                  completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))


@app.get('/api/recommendations/status')
def recommendations_status(request: Request):
    _authorize(request)
    _limit(request)
    return JSONResponse(_scan_snapshot(),headers={'Cache-Control':'no-store'})


@app.post('/api/recommendations/run')
def recommendations_run(request: Request, body: dict):
    _authorize(request)
    _limit(request)
    market=body.get('market','all')
    if market not in ('all','kospi','kosdaq'):
        raise HTTPException(422,'시장 구분은 all, kospi, kosdaq 중 하나여야 합니다.')
    provider=body.get('source','auto')
    if provider not in ('auto','fsc','krx'):
        raise HTTPException(422, '데이터 공급원은 auto, fsc, krx 중 하나여야 합니다.')
    if provider=='auto':
        provider='fsc' if os.environ.get('FSC_STOCK_API_KEY','').strip() else 'krx'
    keyname='FSC_STOCK_API_KEY' if provider=='fsc' else 'KRX_API_KEY'
    key=os.environ.get(keyname,'').strip()
    if not key:
        if provider=='fsc':
            raise HTTPException(503, {'code':'fsc_not_configured',
                'message':'공공데이터포털 금융위원회_주식시세정보를 활용 신청하고 Render의 FSC_STOCK_API_KEY를 설정하세요.'})
        raise HTTPException(503, {'code':'krx_not_configured',
            'message':'FSC_STOCK_API_KEY 또는 KRX_API_KEY가 없습니다. 금융위원회 주식시세 API 활용신청을 권장합니다.'})
    with BACKTEST_LOCK:
        if BACKTEST_STATE.get('status') == 'running':
            raise HTTPException(409,'과거 검증이 진행 중입니다. 종료 후 전체 시장 검색을 실행하세요.')
    global SCAN_JOB
    with SCAN_LOCK:
        current=SCAN_STATE.get('status')
        if current=='running':
            return JSONResponse(dict(_scan_snapshot(),notice='이미 시장 검색이 진행 중입니다.'),
                                headers={'Cache-Control':'no-store'})
        if (current=='complete' and SCAN_STATE.get('market')==market and SCAN_STATE.get('source')==provider and
            SCAN_STATE.get('completed_monotonic') and
            time.monotonic()-SCAN_STATE['completed_monotonic']<20*60):
            return JSONResponse(dict(_scan_snapshot(),notice='20분 이내 완료한 검색 결과를 재사용합니다.'),
                                headers={'Cache-Control':'no-store'})
        job_id=secrets.token_hex(8)
        SCAN_STATE.clear()
        label='금융위원회 T+1' if provider=='fsc' else 'KRX 장 마감'
        SCAN_STATE.update(status='running',market=market,source=provider,job_id=job_id,
            progress={'phase':'provider','done':0,'total':None,'message':f'{label} 일별 시장자료 확인 중'},
            result=None,error=None,started_at=datetime.now(timezone.utc).isoformat(timespec='seconds'),
            started_monotonic=time.monotonic())
        SCAN_JOB=threading.Thread(target=_scan_worker,args=(market,job_id,provider,key),daemon=True,
                                   name='nova-market-eod-scan')
        SCAN_JOB.start()
    return JSONResponse(_scan_snapshot(),headers={'Cache-Control':'no-store'})


@app.post('/api/recommendations/diagnose')
def recommendations_diagnose(request: Request):
    """Auth-protected, user-triggered KRX production connection check.

    No raw keys, headers, provider response, or arbitrary URLs disclosed.
    """
    _authorize(request)
    _limit(request)
    key=os.environ.get('KRX_API_KEY','').strip()
    if not key:
        return JSONResponse({'configured':False,'date':None,'results':[],
            'notes':'Render 환경변수 KRX_API_KEY가 설정되지 않았습니다.'},
            headers={'Cache-Control':'no-store'})
    date=next(completed_dates(datetime.now(KST)))
    details=diagnose_connection(key,date,['kospi','kosdaq'])
    return JSONResponse(details,headers={'Cache-Control':'no-store'})


# v4.4 historical baseline: authenticate, run a bounded weekly FSC screen
# on past snapshots, evaluate only after publication, and never call this
# "final NOVA recommendation" performance.
def _history_snapshot():
    with BACKTEST_LOCK:
        data = dict(BACKTEST_STATE)
    data.pop('started_monotonic', None)
    data['fsc_configured'] = bool(os.environ.get('FSC_STOCK_API_KEY','').strip())
    data['scope'] = 'first_stage_only'
    return data


def _history_worker(job_id: str, market: str, weeks: int, cost_bps: int, key: str):
    def on_progress(info):
        with BACKTEST_LOCK:
            if BACKTEST_STATE.get('job_id') == job_id:
                BACKTEST_STATE['progress'] = info
    try:
        result = run_screen_history(market=market, api_key=key, weeks=weeks,
                                    cost_bps=cost_bps, progress=on_progress)
        with BACKTEST_LOCK:
            if BACKTEST_STATE.get('job_id') == job_id:
                BACKTEST_STATE.update(status='complete',result=result,error=None,
                    completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'),
                    completed_monotonic=time.monotonic())
    except MarketScanError as exc:
        with BACKTEST_LOCK:
            if BACKTEST_STATE.get('job_id') == job_id:
                BACKTEST_STATE.update(status='failed',result=None,
                    error={'code':exc.code,'message':str(exc)},
                    completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))
    except Exception:
        # Never expose provider URLs: FSC serviceKey can be embedded in exception.
        with BACKTEST_LOCK:
            if BACKTEST_STATE.get('job_id') == job_id:
                BACKTEST_STATE.update(status='failed',result=None,
                    error={'code':'history_failed',
                           'message':'과거 시세를 검증할 수 없습니다. 공급원 상태와 서버 로그를 확인하세요.'},
                    completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))


@app.get('/api/recommendations/backtest/status')
def recommendation_backtest_status(request: Request):
    _authorize(request)
    _limit(request)
    return JSONResponse(_history_snapshot(),headers={'Cache-Control':'no-store'})


@app.post('/api/recommendations/backtest/run')
def recommendation_backtest_run(request: Request, body: dict):
    _authorize(request)
    _limit(request)
    market = body.get('market','all')
    weeks = body.get('weeks',4)
    cost = body.get('cost_bps',15)
    if market not in ('all','kospi','kosdaq') or type(weeks) is not int or weeks not in (4,8) or type(cost) is not int or not 0<=cost<=100:
        raise HTTPException(422,'허용 범위: 시장 all/kospi/kosdaq, 과거 4/8주, 편도 비용 0~100bp')
    key = os.environ.get('FSC_STOCK_API_KEY','').strip()
    if not key:
        raise HTTPException(503, {'code':'fsc_not_configured',
              'message':'Render에 FSC_STOCK_API_KEY를 먼저 설정하세요.'})
    with SCAN_LOCK:
        if SCAN_STATE.get('status') == 'running':
            raise HTTPException(409,'현재 종목추천 검색 중입니다. 검색이 종료된 후 백테스트를 실행하세요.')
    global BACKTEST_JOB
    with BACKTEST_LOCK:
        if BACKTEST_STATE.get('status') == 'running':
            return JSONResponse(dict(_history_snapshot(),notice='과거 검증이 이미 진행 중입니다.'),headers={'Cache-Control':'no-store'})
        if (BACKTEST_STATE.get('status') == 'complete' and
            BACKTEST_STATE.get('market') == market and
            BACKTEST_STATE.get('weeks') == weeks and
            BACKTEST_STATE.get('cost_bps') == cost and
            BACKTEST_STATE.get('completed_monotonic') and
            time.monotonic()-BACKTEST_STATE['completed_monotonic'] < 20*60):
            return JSONResponse(dict(_history_snapshot(),notice='20분 이내 완료된 과거 검증을 재사용합니다.'),headers={'Cache-Control':'no-store'})
        job_id=secrets.token_hex(8)
        BACKTEST_STATE.clear()
        BACKTEST_STATE.update(status='running',market=market,weeks=weeks,cost_bps=cost,
              job_id=job_id,result=None,error=None,started_at=datetime.now(timezone.utc).isoformat(timespec='seconds'),
              started_monotonic=time.monotonic(),
              progress={'phase':'starting','done':0,'total':weeks,'message':'과거 일별 전체시장 스냅샷 조회 시작'})
        BACKTEST_JOB=threading.Thread(target=_history_worker,args=(job_id,market,weeks,cost,key),daemon=True,name='nova-market-history')
        BACKTEST_JOB.start()
    return JSONResponse(_history_snapshot(),headers={'Cache-Control':'no-store'})
