"""NOVA v5.3.2: conservative completed-KRX-session price integrity gate.

Read-only. Never infer prices from adjustments, stitch KIS/Yahoo candles, or
call an order endpoint. The caller's KIS daily frame is quarantined on doubt.
Comparison checks *the same date* and OHLC (not quote/time-of-day ticks).
"""
from __future__ import annotations
from datetime import datetime, time as clock_time, timedelta
from zoneinfo import ZoneInfo
import math
import threading
import time
import pandas as pd

KST=ZoneInfo('Asia/Seoul')
THRESHOLD_PCT=0.5
SETTLEMENT_AFTER=clock_time(18,0)
_PROVIDER_CACHE={}
_CACHE_LOCK=threading.RLock()
_CACHE_TTL=300
_FIELDS=('Open','High','Low','Close')


def _value_at(frame, day):
    if frame is None or frame.empty:
        return None
    try:
        dates=pd.DatetimeIndex(frame.index).date
        matched=frame.loc[dates == day]
        if matched.empty: return None
        row=matched.iloc[-1]
        values={field:float(row[field]) for field in _FIELDS}
        if any(not math.isfinite(x) or x<=0 for x in values.values()): return None
        if values['High'] < max(values['Open'],values['Close'],values['Low']): return None
        if values['Low'] > min(values['Open'],values['Close']): return None
        return values
    except (KeyError,TypeError,ValueError,IndexError):
        return None


def _match(a, b, tolerance=THRESHOLD_PCT):
    return a is not None and b is not None and all(
        abs(a[field]-b[field])/max(a[field],b[field])*100 <= tolerance
        for field in _FIELDS)


def _safe_summary(row):
    return {k:round(v,3) for k,v in row.items()} if row else None


def yahoo_recent_raw(symbol: str):
    """Independent short-window basic OHLC, not adjusted Yahoo research bars."""
    import yfinance as yf
    raw=yf.Ticker(symbol).history(period='1mo',interval='1d',auto_adjust=False,
                                   prepost=False,raise_errors=True,timeout=10)
    if raw is None or raw.empty:raise RuntimeError('YAHOO_NO_DAILY')
    return raw


def independent_quotes(api, code, symbol, date, *, yahoo_loader=None):
    """Bounded cached KIS secondary daily-price + Yahoo basic read-only calls."""
    key=(code,symbol,date.isoformat())
    with _CACHE_LOCK:
        rec=_PROVIDER_CACHE.get(key)
        if rec and time.monotonic()-rec[0] < _CACHE_TTL:
            return rec[1]
    broker=yahoo=None
    errors=[]
    try:
        broker=_value_at(api.daily_price(code),date)
        if broker is None:errors.append('KIS_SECONDARY_DATE_UNAVAILABLE')
    except Exception:
        errors.append('KIS_SECONDARY_QUERY_FAILED')
    try:
        yahoo=_value_at((yahoo_loader or yahoo_recent_raw)(symbol),date)
        if yahoo is None:errors.append('YAHOO_DATE_UNAVAILABLE')
    except Exception:
        errors.append('YAHOO_QUERY_FAILED')
    result=(broker,yahoo,errors)
    with _CACHE_LOCK:
        # Never cache credentials, HTTP payloads or access tokens.
        if len(_PROVIDER_CACHE)>256:_PROVIDER_CACHE.clear()
        _PROVIDER_CACHE[key]=(time.monotonic(),result)
    return result


def verify_latest_kis_daily(bars, *, api, code, symbol, now=None,
                            yahoo_loader=None, get_requery=None):
    """Return (safe_bars, public diagnostic).

    Positive verification only for the most recent nearby KIS session and
    matching KIS secondary *and* Yahoo basic OHLC for the same date. On a
    mismatch a bounded KIS chart re-read is attempted once; the replacement
    bar can only come from that same KIS chart endpoint, never from Yahoo.
    """
    moment=(now or datetime.now(KST)).astimezone(KST)
    series=bars.copy()
    base={'state':'NOT_CHECKED','verified':False,'auto_recovered':False,
          'signal_hold':False,'rejected_date':None,'latest_date':None,
          'checked_at':moment.isoformat(timespec='seconds'),
          'threshold_pct':THRESHOLD_PCT,'broker_chart':'KIS_FHKST03010100',
          'broker_reference':'KIS_FHKST01010400',
          'independent_reference':'YAHOO_BASIC_UNADJUSTED',
          'reason':'검증 대상 확정봉이 없습니다.'}
    if series is None or series.empty:return series,base
    latest=pd.Timestamp(series.index[-1]).date()
    base['latest_date']=latest.isoformat()
    if latest>moment.date():
        return series.iloc[:-1].copy(),{**base,'state':'FUTURE_DATE','signal_hold':True,
            'rejected_date':latest.isoformat(),'reason':'미래 거래일 봉을 제외했습니다.'}
    if (moment.date()-latest).days>10:
        return series,{**base,'state':'OLD_DATA','reason':'마지막 일봉이 오래되어 KRX 거래일 검증으로 별도 보류합니다.'}
    if latest==moment.date() and moment.time()<SETTLEMENT_AFTER:
        return series.iloc[:-1].copy(),{**base,'state':'SETTLEMENT_PENDING','signal_hold':True,
            'rejected_date':latest.isoformat(),
            'reason':'오늘 일봉은 18:00 KST 이후 교차 검증 전까지 확정 취급하지 않습니다.'}
    # For an earlier recent session, require same-date references as well. No
    # last-price/quote comparison: post-market ticks need not equal KRX close.
    broker,yahoo,errors=independent_quotes(api,code,symbol,latest,yahoo_loader=yahoo_loader)
    base.update(broker_reference_ohlc=_safe_summary(broker),
                independent_reference_ohlc=_safe_summary(yahoo),
                errors=errors)
    primary=_value_at(series,latest)
    if broker is not None and yahoo is not None and _match(broker,yahoo):
        if _match(primary,broker) and _match(primary,yahoo):
            return series,{**base,'state':'VERIFIED','verified':True,
                'reason':'동일 거래일 KIS 차트·KIS 일별 시세·Yahoo 기본 OHLC가 허용 차이 이내입니다.'}
        # A discrepancy can resolve after KIS chart is re-fetched. Do not let
        # either secondary feed replace KIS history by itself.
        refreshed=None
        try:
            refreshed=(get_requery or (lambda: api.period_bars(code,'1d',now=moment,recent_only=True)))()
        except Exception:
            errors.append('KIS_CHART_REQUERY_FAILED')
        new_bar=_value_at(refreshed,latest)
        if _match(new_bar,broker) and _match(new_bar,yahoo):
            # Only substitute a KIS bar with the same KIS CHART endpoint's
            # explicitly re-read row. Other KIS dates remain unchanged.
            fixed=series.copy()
            for f in _FIELDS:fixed.at[series.index[-1],f]=float(new_bar[f])
            if refreshed is not None and 'Volume' in refreshed.columns:
                repl=refreshed.loc[pd.DatetimeIndex(refreshed.index).date==latest]
                if not repl.empty:fixed.at[series.index[-1],'Volume']=float(repl['Volume'].iloc[-1])
            return fixed,{**base,'state':'REQUERY_RECOVERED','verified':True,
                'auto_recovered':True,'reason':'KIS 차트 재조회 봉이 KIS 일별 시세 및 Yahoo 기본 OHLC와 교차 일치하여 KIS 봉으로 복구했습니다.'}
    else:
        errors.append('REFERENCE_CONFLICT' if broker and yahoo else 'REFERENCE_INCOMPLETE')
    # Never use the inconsistent/latest candle for a completed-day decision.
    return series.iloc[:-1].copy(),{**base,'state':'PRICE_CONFLICT' if broker and yahoo else 'UNVERIFIED',
        'rejected_date':latest.isoformat(),'signal_hold':True,
        'reason':'최신 KIS 일봉의 종가/가격 기준을 교차 확인할 수 없어 해당 날짜 봉을 격리하고 신규 신호를 보류합니다.'}
