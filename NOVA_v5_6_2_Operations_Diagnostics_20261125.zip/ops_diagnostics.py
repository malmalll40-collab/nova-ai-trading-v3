"""NOVA 5.6.2 bounded, read-only operations diagnostics.
Log ONLY explicit allowlisted fields. Never emit provider payloads, keys, URLs,
account IDs, raw exceptions, or request headers. No order or adoption paths.
"""
import json
import logging
import math
import os
import re
from datetime import datetime, timezone
from pathlib import Path

VERSION = '5.6.2'
LOG = logging.getLogger('uvicorn.error')
STATES = {'DATA_MISSING','RISK_OR_DATA_VETO','NO_BUY_CANDIDATE','INSUFFICIENT_POOL','NONPOSITIVE_EV','RESEARCH_ESTIMATE'}
CAL_CODES = {'XKRX_IMPORT_UNAVAILABLE','XKRX_LOAD_FAILED','XKRX_DATE_OUT_OF_RANGE','XKRX_SESSION_CHECK_FAILED','XKRX_PREVIOUS_SESSION_FAILED'}
PORTFOLIOS = ('core','adaptive','rs_required','transition_soft','rs_hybrid','risk_chase','unified','unified_sized','unified_holdout')


def emit(event, summary):
    # All callers construct summaries with fixed fields below; do not log exceptions.
    LOG.info('NOVA_OPS %s', json.dumps({'app_version':VERSION,'event':event,**summary}, ensure_ascii=True, allow_nan=False, separators=(',',':')))


def configured():
    return {'kis_configured':bool(os.getenv('KIS_APP_KEY','').strip() and os.getenv('KIS_APP_SECRET','').strip()),
            'db_configured':bool(os.getenv('DATABASE_URL','').strip() or os.getenv('NOVA_EVIDENCE_SQLITE_PATH','').strip()),
            'evidence_enabled':os.getenv('NOVA_CORE541_EVIDENCE_ENABLED','').lower() in ('1','true','yes'),
            'collector_enabled':os.getenv('NOVA_CORE560_AUTO_ENABLED')=='1' and os.getenv('NOVA_AUTOTRACK_ENABLED')=='1' and len(os.getenv('NOVA_AUTOTRACK_TOKEN',''))>=24,
            'startup_full_enabled':os.getenv('NOVA_OPS_DIAGNOSTICS_ON_START')=='1','orders_enabled':False}


def num(x):
    return x if type(x) in (int,float) and math.isfinite(x) else None


def day(x):
    try:
        s=str(x)[:10]
        return datetime.strptime(s,'%Y-%m-%d').date().isoformat() if re.fullmatch(r'\d{4}-\d{2}-\d{2}',s) else None
    except (ValueError,TypeError):return None


def calendar_summary(s):
    return {'day':day(s.get('day')),'verified':s.get('calendar_verified') is True,'open':s.get('is_open') is True,
            'session_exists':bool(s.get('open_kst') and s.get('close_kst')),
            'error_code':s.get('calendar_error_code') if s.get('calendar_error_code') in CAL_CODES else None}


def valid_bar(bar):
    try:
        o,h,l,c,v=(num(bar.get(k)) for k in ('open','high','low','close','volume'))
        return all(x is not None for x in (o,h,l,c,v)) and min(o,h,l,c,v)>0 and h>=max(o,c) and l<=min(o,c)
    except (AttributeError,TypeError):return False


def chart_summary(result, today, expected, analysis=False):
    if analysis:
        rows=result.get('rows') or []
        r=rows[-1] if rows else {}; date=day(r.get('date')); bar=r.get('bar')
    else:
        date=day(result.get('trading_date') or result.get('date'));bar=result.get('bar')
    available=result.get('available') is True and valid_bar(bar) and date==today
    return {'status':'PASS' if available else ('NOT_AVAILABLE' if expected else 'OUTSIDE_WINDOW'),
            'expected_today':expected,'last_date':date,'today_valid_ohlcv':available,
            'display_only':True}


def database_probe():
    """Actual read-only connection and record count; do not create tables."""
    from evidence_store import backend
    kind=backend(); result={'backend':kind,'status':'NOT_CONFIGURED','observation_table_exists':None,'observations':None}
    if kind=='disabled':return result
    try:
        if kind=='postgresql':
            import psycopg
            with psycopg.connect(os.environ['DATABASE_URL'].strip(),connect_timeout=5,options='-c statement_timeout=5000') as db:
                with db.cursor() as cur:
                    cur.execute('SET TRANSACTION READ ONLY');cur.execute('SELECT 1');cur.fetchone()
                    cur.execute("SELECT to_regclass('nova_core561_observations') IS NOT NULL");exists=bool(cur.fetchone()[0]);count=None
                    if exists:cur.execute('SELECT COUNT(*) FROM nova_core561_observations');count=int(cur.fetchone()[0])
        else:
            import sqlite3
            p=Path(os.environ['NOVA_EVIDENCE_SQLITE_PATH']).expanduser().resolve()
            if not p.is_file():return {**result,'status':'FILE_NOT_CREATED'}
            with sqlite3.connect(p.as_uri()+'?mode=ro',uri=True,timeout=5) as db:
                cur=db.cursor();cur.execute('SELECT 1');cur.fetchone();cur.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='nova_core561_observations'");exists=cur.fetchone() is not None;count=None
                if exists:cur.execute('SELECT COUNT(*) FROM nova_core561_observations');count=int(cur.fetchone()[0])
        return {**result,'status':'READ_OK','observation_table_exists':exists,'observations':count}
    except Exception:return {**result,'status':'READ_FAILED'}


def batch_summary(state):
    rows=state.get('rows') or [];aligned=state.get('core542_aligned') or {};u=aligned.get('v561_unified') or {}
    portfolio=u.get('portfolio') or {}; groups=u.get('by_group') or {}
    def perf(p):return {k:num(p.get(k)) for k in ('return_pct','mdd_pct','trades','stress_return_pct')}
    def group(g):return {k:{'stocks':num(v.get('stocks')),'mean_pct':num(v.get('mean_pct'))} for k,v in g.items() if k in PORTFOLIOS and isinstance(v,dict)}
    return {'requested':len(state.get('symbols') or []),'ready':sum(r.get('status')=='READY' for r in rows),
            'kis_ready':sum(r.get('status')=='READY' and r.get('source')=='kis' for r in rows),
            'aligned_status':'READY' if aligned.get('status')=='READY' else 'UNAVAILABLE',
            'start':day(aligned.get('start')),'end':day(aligned.get('end')),'samples':num(u.get('samples')),
            'scored':num(u.get('scored')),'buy_signals':num(u.get('buy_signals')),'brier':num(u.get('brier')),
            'naive_brier':num(u.get('naive_brier')),'expected_return_mae_pct':num(u.get('expected_return_mae_pct')),
            'holdout_scored':num(u.get('holdout_scored')),'diagnostics':{k:num(v) for k,v in (u.get('diagnostics') or {}).items() if k in STATES},
            'portfolio':{k:perf(v) for k,v in portfolio.items() if k in PORTFOLIOS and isinstance(v,dict)},
            'semiconductor_registered_excluded':group(groups.get('반도체 ETF 등록 종목 제외') or {}),
            'semiconductor_research_excluded':group(groups.get('연구 분류 반도체 제외') or {}),
            'nonoverlap_candidate_value':{k:{f:num(v.get(f)) for f in ('added_count','blocked_count','delta_pct_sum')} for k,v in (u.get('nonoverlap_candidate_value') or {}).items() if k in ('rs_required','entry_wider','risk_chase','transition_soft','rs_hybrid','regime_router','early_turn','range_guard','regime_switch') and isinstance(v,dict)},
            'historical_only':True,'strategy_adoption':'HOLD'}
