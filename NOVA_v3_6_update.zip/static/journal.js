/* NOVA v3.5: forward-only, device-local signal journal; no unattended server jobs. */
'use strict';
(function () {
 const STORAGE_KEY='nova-v35-journal-v1';
 const LEGACY_KEY='nova-v34-prospective-v1';
 const MAX_LOCAL_RECORDS=800;
 const HORIZONS=[1,3,5,10];
 const $=id=>document.getElementById(id);
 const esc=text=>String(text??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
 const pct=n=>Number.isFinite(Number(n))?(Number(n)>=0?'+':'')+Number(n).toFixed(2)+'%':'—';
 const safeGet=(key,fallback)=>{try{const x=JSON.parse(localStorage.getItem(key)||'null');return x??fallback;}catch{return fallback;}};
 const safeSet=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value));return true;}catch{return false;}};
 let journal=[];
 let busy=false;
 let lastRefresh=new Map();

 function validRecord(r){
   return r && typeof r==='object' && typeof r.id==='string' && r.id.length<161 &&
     /^\d{6}\.(KS|KQ)$|^[A-Z][A-Z0-9^.=\-]{0,23}$/.test(r.symbol||'') &&
     ['1분','5분','스윙'].includes(r.mode) && ['yahoo','kis'].includes(r.source) &&
     ['BUY','SELL'].includes(r.technical) && ['BUY','SELL','HOLD'].includes(r.filtered) &&
     /^\d{4}-\d{2}-\d{2}$/.test(r.bar_day||'') &&
     Number.isFinite(Number(r.reference)) && Number(r.reference)>0;
 }
 function normalize(r){
   return {...r, cost_bps:Math.min(100,Math.max(0,Number(r.cost_bps)||0)),
     reference:Number(r.reference),gate:['PASS','CAUTION','BLOCK','UNKNOWN'].includes(r.gate)?r.gate:'UNKNOWN',
     outcomes:r.outcomes && typeof r.outcomes==='object'?r.outcomes:{}};
 }
 function load(){
   journal=(Array.isArray(safeGet(STORAGE_KEY,[]))?safeGet(STORAGE_KEY,[]):[]).filter(validRecord).map(normalize).slice(-MAX_LOCAL_RECORDS);
   // Upgrade v3.4 once. Never overwrite or invent outcomes from earlier 5d record.
   const previous=safeGet(LEGACY_KEY,[]);
   if(!safeGet('nova-v35-migrated',false) && Array.isArray(previous)){
     for(const old of previous){
       if(!old || !old.symbol || !old.bar_day || !['BUY','SELL'].includes(old.technical))continue;
       const candidate={id:`legacy|${old.symbol}|스윙|${old.bar_day}`,symbol:old.symbol,
         source:'yahoo',mode:'스윙',bar_day:old.bar_day,bar_time:old.bar_day,
         observed_at:old.observed_at||'',reference:old.reference,technical:old.technical,
         filtered:old.filtered||old.technical,gate:old.gate||'UNKNOWN',cost_bps:15,outcomes:{}};
       if(validRecord(candidate)&&!journal.some(x=>x.id===candidate.id))journal.push(normalize(candidate));
     }
     journal=journal.slice(-MAX_LOCAL_RECORDS);
     save();safeSet('nova-v35-migrated',true);
   }
 }
 function save(){return safeSet(STORAGE_KEY,journal);}
 function signalId(d){
   const date=String(d.last_completed_bar||'').slice(0,10);
   // One objective observation per source / ticker / mode / trading day.
   return `${d.source}|${d.symbol}|${d.mode}|${date}`;
 }
 function record(d){
   if(!d || d.is_demo || d.is_stale || !d.signal_is_current || !['BUY','SELL'].includes(d.signal))return;
   if(!d.reference || !d.last_completed_bar || !['kis','yahoo'].includes(d.source))return;
   const id=signalId(d),bar_day=String(d.last_completed_bar).slice(0,10);
   if(!/^\d{4}-\d{2}-\d{2}$/.test(bar_day) || journal.some(x=>x.id===id))return;
   if(journal.length>=MAX_LOCAL_RECORDS){setStatus('기록 상한 800건에 도달했습니다. JSON 백업 후 기존 기록을 정리하세요.');return;}
   const row={id,source:d.source,symbol:d.symbol,mode:d.mode,bar_day,
     bar_time:d.last_completed_bar,observed_at:new Date().toISOString(),reference:Number(d.reference),
     technical:d.signal,filtered:d.signal,gate:'UNKNOWN',cost_bps:Number(d.cost_bps_one_side??15),outcomes:{}};
   if(validRecord(row)){journal.push(row);if(!save())setStatus('저장 공간 부족으로 추적 기록을 저장하지 못했습니다.');render();}
 }
 function updateFinance(d, final, gate){
   if(!d || d.mode!=='스윙')return;
   const id=signalId(d),r=journal.find(x=>x.id===id);
   if(!r)return;
   if(['PASS','CAUTION','BLOCK'].includes(gate) && ['BUY','SELL','HOLD'].includes(final)){
     r.filtered=final;r.gate=gate;save();render();
   }
 }
 function setStatus(s){if($('journalStatus'))$('journalStatus').textContent=s;}
 const rate=(rows,key='direction_hit')=>rows.length?Number((rows.filter(x=>x[key]).length/rows.length*100).toFixed(1)):null;
 const mean=(rows,key)=>{const vals=rows.map(x=>x[key]).filter(x=>typeof x==='number'&&Number.isFinite(x));return vals.length?Number((vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(2)):null;};
 function eligible(){
   const mode=$('journalModeFilter')?.value||'all';
   return journal.filter(x=>mode==='all'||x.mode===mode);
 }
 function render(){
   if(!$('journalMetrics'))return;
   const records=eligible();
   const grid=$('journalMetrics');grid.replaceChildren();
   for(const h of HORIZONS){
     const complete=records.map(r=>({...r,ev:r.outcomes?.[String(h)]}))
       .filter(x=>x.ev?.status==='complete');
     const wins=complete.filter(x=>x.ev.direction_hit).length;
     const hit=complete.length?wins/complete.length*100:null;
     const signed=complete.map(x=>Number(x.ev.directional_score_pct)).filter(Number.isFinite);
     const average=signed.length?signed.reduce((a,b)=>a+b,0)/signed.length:null;
     const buy=complete.filter(x=>x.technical==='BUY'&&typeof x.ev.buy_net_pct==='number');
     const buyAvg=mean(buy.map(x=>x.ev),'buy_net_pct');
     const c=document.createElement('div');c.className='journal-metric';
     c.innerHTML=`<span>${h}거래일 후</span><strong>${hit==null?'미확인':hit.toFixed(1)+'%'}</strong>
        <small>방향 적중 ${wins}/${complete.length}건</small>
        <small>평균 방향 변화 ${average==null?'—':pct(average)}</small>
        <small>매수 신호 순변화 ${buyAvg==null?'—':pct(buyAvg)}</small>`;
     grid.appendChild(c);
   }
   const outcome5=records.map(r=>({...r,event:r.outcomes?.['5']})).filter(x=>x.event?.status==='complete');
   const buyOnly=outcome5.filter(x=>x.technical==='BUY');
   const verified=buyOnly.filter(x=>['PASS','CAUTION','BLOCK'].includes(x.gate));
   const hold=verified.filter(x=>x.filtered==='HOLD');
   const a=verified.map(x=>Number(x.event.buy_net_pct)).filter(Number.isFinite);
   const b=verified.map(x=>x.filtered==='BUY'?Number(x.event.buy_net_pct):0).filter(Number.isFinite);
   const ma=a.length?a.reduce((x,y)=>x+y,0)/a.length:null;
   const mb=b.length?b.reduce((x,y)=>x+y,0)/b.length:null;
   const adverse=buyOnly.map(x=>x.event.close_path_drawdown_pct).filter(v=>typeof v==='number');
   const worst=adverse.length?Math.min(...adverse):null;
   $('journalAB').textContent=`5거래일 재무 필터 A/B · 동일한 검증 대상 매수 신호 ${verified.length}건 · 차단 ${hold.length}건\n`
     +`기술적 매수 평균 순변화 ${ma==null?'—':pct(ma)} / 재무 필터 적용(관망은 0%) ${mb==null?'—':pct(mb)}\n`
     +`매수 신호 종가 경로 최악 낙폭 ${worst==null?'—':pct(worst)} (포트폴리오 MDD가 아님)`;
   const list=$('journalList');list.replaceChildren();
   for(const row of records.slice().reverse().slice(0,45)){
     const d=document.createElement('div');d.className='journal-item';
     const h=row.outcomes?.['5'];
     const details=HORIZONS.map(n=>{
       const r=row.outcomes?.[String(n)];
       return `${n}일 ${r?.status==='complete'?pct(r.asset_change_pct):r?.status==='unavailable'?'미확인':'대기'}`;
     }).join(' · ');
     const title=document.createElement('strong');title.textContent=`${row.symbol} · ${row.mode} · ${row.bar_day} · ${row.technical==='BUY'?'매수':'보유축소'}`;
     const sub=document.createElement('small');sub.textContent=`${details} | 재무 ${row.gate||'UNKNOWN'}`;
     d.append(title,sub);list.appendChild(d);
   }
   if(!records.length)list.textContent='관찰 기록이 없습니다. 새로운 실시간 시세의 매수·매도 신호가 발생하면 자동 기록됩니다.';
   const complete10=records.filter(r=>r.outcomes?.['10']?.status==='complete').length;
   setStatus(`이 기기 기록 ${journal.length}건 · 선택 모드 ${records.length}건 · 10거래일 평가 완료 ${complete10}건 · 브라우저 저장소에만 보관`);
 }
 async function refresh({onlySymbol=null,manual=false}={}){
   if(window.NOVA_PREVIEW_DATA){setStatus('오프라인 체험판에서는 실제 시세 평가를 지원하지 않습니다.');return;}
   if(busy)return;
   const candidates=journal.filter(x=>!onlySymbol||x.symbol===onlySymbol);
   if(!candidates.length){render();return;}
   if(!manual && onlySymbol && Date.now()-(lastRefresh.get(onlySymbol)||0)<10*60*1000)return;
   busy=true;
   const button=$('journalRefresh');if(button)button.disabled=true;
   let evaluated=0,failures=0;
   try{
     // Render free-tier and data-provider limits: 4 symbols per request, max 60 records.
     const batches=[];
     const groups=new Map();
     for(const r of candidates){
       const key=r.symbol+'|'+r.source;
       if(!groups.has(key))groups.set(key,[]);
       groups.get(key).push(r);
     }
     let current=[],count=0;
     for(const group of groups.values()){
       for(let i=0;i<group.length;i+=60){
         const piece=group.slice(i,i+60);
         if(current.length && (count>=4 || current.length+piece.length>60)){
           batches.push(current);current=[];count=0;
         }
         current.push(...piece);count++;
       }
     }
     if(current.length)batches.push(current);
     for(const rows of batches){
       setStatus(`미래 종가 확인 중 · ${evaluated}건 처리 · 조회 중...`);
       const token=(()=>{try{return sessionStorage.getItem('nova3-token')||'';}catch{return '';}})();
       const response=await fetch('/api/journal/evaluate',{method:'POST',credentials:'same-origin',cache:'no-store',
         headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},
         body:JSON.stringify({records:rows.map(x=>({id:x.id,symbol:x.symbol,source:x.source,mode:x.mode,
           bar_day:x.bar_day,reference:x.reference,technical:x.technical,filtered:x.filtered,gate:x.gate,cost_bps:x.cost_bps}))})});
       if(!response.ok){const body=await response.json().catch(()=>({}));throw new Error(typeof body.detail==='string'?body.detail:`HTTP ${response.status}`);}
       const body=await response.json();
       for(const result of body.results||[]){
         const rec=journal.find(x=>x.id===result.id);
         if(!rec)continue;
         // Closed horizons remain visible if the provider has a temporary outage.
         for(const [h,value] of Object.entries(result.horizons||{})){
           if(value.status==='complete' || !rec.outcomes[h] || rec.outcomes[h].status!=='complete')rec.outcomes[h]=value;
         }
         rec.last_checked_at=new Date().toISOString();evaluated++;
         if(result.error)failures++;
       }
       if(!save())throw new Error('휴대폰 저장 공간이 부족합니다. 먼저 JSON 백업을 다운로드하세요.');
       render();
     }
     if(onlySymbol)lastRefresh.set(onlySymbol,Date.now());
     setStatus(`평가 확인 ${evaluated}건 · 데이터 조회 실패 ${failures}건 · 앱 실행 중에만 갱신됩니다.`);
   }catch(e){setStatus(`미래 종가 조회 실패: ${e.message}. 기기에 저장된 이전 평가 결과는 유지됩니다.`);}
   finally{busy=false;if(button)button.disabled=false;}
 }
 function csvCell(t){return '"'+String(t??'').replace(/"/g,'""')+'"';}
 function download(name,content,type){
   const blob=new Blob([content],{type});const a=document.createElement('a');const url=URL.createObjectURL(blob);
   a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);
 }
 function exportCsv(){
   const rows=[['signal_date','symbol','mode','source','technical','filtered','gate','reference','cost_bps','horizon_days','status','settlement_date','settlement_close','asset_change_pct','directional_hit','directional_score_pct','hypothetical_buy_net_pct','buy_close_path_drawdown_pct']];
   for(const r of journal)for(const h of HORIZONS){const x=r.outcomes?.[String(h)]||{};
     rows.push([r.bar_day,r.symbol,r.mode,r.source,r.technical,r.filtered,r.gate,r.reference,r.cost_bps,h,x.status||'pending',x.settlement_day,x.settlement_close,x.asset_change_pct,x.direction_hit,x.directional_score_pct,x.buy_net_pct,r.technical==='BUY'?x.close_path_drawdown_pct:'']);
   }
   download('NOVA_v35_signal_results.csv','\ufeff'+rows.map(r=>r.map(csvCell).join(',')).join('\n'),'text/csv;charset=utf-8');
 }
 function exportJson(){
   download('NOVA_v35_journal_backup.json',JSON.stringify({version:'3.5',exported_at:new Date().toISOString(),records:journal},null,2),'application/json;charset=utf-8');
 }
 async function importJson(file){
   if(!file)return;
   if(file.size>2_000_000){setStatus('백업 파일이 2MB를 초과합니다.');return;}
   try{
     const obj=JSON.parse(await file.text());
     if(obj?.version!=='3.5'||!Array.isArray(obj.records)||obj.records.length>MAX_LOCAL_RECORDS)throw new Error('올바른 NOVA v3.5 백업 파일이 아닙니다.');
     const rows=obj.records.filter(validRecord).map(normalize);
     const ids=new Map(journal.map(x=>[x.id,x]));
     for(const row of rows)ids.set(row.id,row);
     if(ids.size>MAX_LOCAL_RECORDS)throw new Error('기록이 800건을 넘습니다. 먼저 기록을 정리하세요.');
     if(!window.confirm(`유효한 기록 ${rows.length}건을 이 기기의 기존 기록과 합칠까요?`))return;
     journal=[...ids.values()];if(!save())throw new Error('저장공간이 부족합니다.');render();
   }catch(e){setStatus('백업 불러오기 실패: '+e.message);}
 }
 function init(){
   load();render();
   $('journalModeFilter')?.addEventListener('change',render);
   $('journalRefresh')?.addEventListener('click',()=>refresh({manual:true}));
   $('journalExportCsv')?.addEventListener('click',exportCsv);
   $('journalBackup')?.addEventListener('click',exportJson);
   $('journalRestore')?.addEventListener('change',e=>{importJson(e.target.files?.[0]);e.target.value='';});
   $('journalClear')?.addEventListener('click',()=>{if(window.confirm('이 휴대폰에 저장된 모든 NOVA 신호 기록을 삭제할까요? 복원은 JSON 백업만 가능합니다.')){journal=[];save();render();}});
   // Reconcile on return; NO server cron or push and no recording of missing past signals.
   document.addEventListener('visibilitychange',()=>{if(!document.hidden && journal.length)refresh({manual:false});});
 }
 window.NOVAJournal={init,record,updateFinance,refresh,render};
})();
