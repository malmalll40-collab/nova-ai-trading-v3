"""NOVA v3 mobile PWA API: read-only, no trading endpoints and no broker order capability.
Start locally with `python server.py`; see README for LAN/public access.
"""
from __future__ import annotations

import hmac
import hashlib
import secrets
import math
import os
from pathlib import Path
import threading
import time
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from zoneinfo import ZoneInfo

import pandas as pd
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from engine import Config, feature_frame, decide
from backtest import run_backtest
from data_sources import demo_data, yahoo_data, kis_data, ticker_format, market_zone
from stock_lookup import search_stocks
from dart_financial import DARTError, get_client
from finance_gate import assess_financial, combine_signal
from signal_journal import evaluate_batch

BASE = Path(__file__).resolve().parent
ASSETS = BASE / 'static'
app = FastAPI(title='NOVA AI Trading Mobile', docs_url=None, redoc_url=None, openapi_url=None)
app.mount('/static', StaticFiles(directory=ASSETS), name='static')
CACHE_LOCK = threading.Lock()
CACHE = {}
RATE = {}
CACHE_TTL = 52
FIN_CACHE_TTL = 6 * 3600
JOURNAL_CACHE_LOCK = threading.Lock()
JOURNAL_FRAMES = {}
JOURNAL_CACHE_TTL = 12 * 60
WATCH_CACHE_TTL = 90
MAX_CACHE = 72
KST = ZoneInfo('Asia/Seoul')
LABEL = {'BUY':'매수 후보', 'SELL':'매도·보유분 축소 검토', 'HOLD':'관망'}
MODES = {'1분','5분','스윙'}
SOURCES = {'yahoo','kis','demo'}
AUTH_COOKIE = 'nova3_auth'
REMEMBER_SECONDS = 30 * 24 * 3600
SESSION_SECONDS = 12 * 3600

if os.environ.get('NOVA_PUBLIC_DEPLOY') == '1' and len(os.environ.get('NOVA_ACCESS_TOKEN','')) < 16:
    raise RuntimeError('공개 서버 배포시 NOVA_ACCESS_TOKEN을 16자 이상으로 설정하세요.')


def _cookie_key(token: str) -> bytes:
    # Server-only key. Changing NOVA_ACCESS_TOKEN invalidates all remembered devices.
    return hashlib.sha256(('nova3-cookie:v1:' + token).encode('utf-8')).digest()


def _cookie_valid(value: str, token: str) -> bool:
    if not value or not token:
        return False
    try:
        version, expiry, nonce, signature = value.split('.')
        if version != 'v1' or not expiry.isdecimal() or len(nonce) != 32 or len(signature) != 64:
            return False
        if not all(ch in '0123456789abcdef' for ch in nonce + signature):
            return False
        exp = int(expiry)
        now = int(time.time())
        if not now < exp <= now + REMEMBER_SECONDS:
            return False
        message = f'{version}.{expiry}.{nonce}'
        expected = hmac.new(_cookie_key(token), message.encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature)
    except (ValueError, TypeError):
        return False


def _is_authenticated(request: Request) -> bool:
    token = os.environ.get('NOVA_ACCESS_TOKEN', '')
    if not token:
        return True
    supplied = request.headers.get('Authorization', '')
    if supplied and hmac.compare_digest(supplied, 'Bearer ' + token):
        return True
    return _cookie_valid(request.cookies.get(AUTH_COOKIE, ''), token)


def _authorize(request: Request):
    if not _is_authenticated(request):
        raise HTTPException(401, '인증이 만료됐습니다. 설정에서 서버 접근 토큰을 입력하세요.')


def _secure_cookie(request: Request) -> bool:
    # Render sets NOVA_PUBLIC_DEPLOY=1. Local HTTP development continues to work.
    return os.environ.get('NOVA_PUBLIC_DEPLOY') == '1' or request.url.scheme == 'https'


@app.get('/api/auth/status')
def auth_status(request: Request):
    return JSONResponse({'authenticated': _is_authenticated(request),
                         'token_required': bool(os.environ.get('NOVA_ACCESS_TOKEN'))},
                        headers={'Cache-Control': 'no-store'})


@app.post('/api/auth/login')
def auth_login(request: Request, body: dict):
    _limit(request)
    expected = os.environ.get('NOVA_ACCESS_TOKEN', '')
    supplied = body.get('token', '')
    remember = body.get('remember') is True
    if not isinstance(supplied, str) or len(supplied) > 1024:
        raise HTTPException(400, '올바르지 않은 토큰 형식입니다.')
    if expected and not hmac.compare_digest(supplied, expected):
        raise HTTPException(401, '서버 접근 토큰이 일치하지 않습니다.')
    response = JSONResponse({'authenticated': True, 'remembered': remember, 'days': 30 if remember else 0},
                            headers={'Cache-Control': 'no-store'})
    if expected:
        duration = REMEMBER_SECONDS if remember else SESSION_SECONDS
        expiry = str(int(time.time()) + duration)
        message = f'v1.{expiry}.{secrets.token_hex(16)}'
        signature = hmac.new(_cookie_key(expected), message.encode(), hashlib.sha256).hexdigest()
        response.set_cookie(AUTH_COOKIE, message + '.' + signature,
                            max_age=duration if remember else None,
                            httponly=True, secure=_secure_cookie(request),
                            samesite='lax', path='/')
    return response


@app.post('/api/auth/logout')
def auth_logout(request: Request):
    response = JSONResponse({'authenticated': False}, headers={'Cache-Control':'no-store'})
    response.delete_cookie(AUTH_COOKIE, path='/', secure=_secure_cookie(request), httponly=True, samesite='lax')
    return response


def _limit(request: Request):
    ip = request.client.host if request.client else 'unknown'
    now = time.monotonic()
    with CACHE_LOCK:
        ts = [x for x in RATE.get(ip,[]) if now-x < 60]
        if len(ts) >= 24:
            raise HTTPException(429, '요청이 너무 많습니다. 잠시 뒤 다시 조회하세요.')
        ts.append(now)
        RATE[ip] = ts
        if len(RATE)>500:
            RATE.clear()


def _cached(key, make, ttl=CACHE_TTL):
    now = time.monotonic()
    with CACHE_LOCK:
        entry = CACHE.get(key)
        if entry and now-entry[0] <= ttl:
            return dict(entry[1], cached=True, cache_age_seconds=round(now-entry[0]))
    result = make()
    with CACHE_LOCK:
        if len(CACHE)>=MAX_CACHE:
            CACHE.clear()
        CACHE[key]=(time.monotonic(),result)
    return dict(result,cached=False,cache_age_seconds=0)


def _safe_float(n):
    try:
        v=float(n)
        return round(v,6) if math.isfinite(v) else None
    except (ValueError,TypeError):return None


def _last_age_minutes(bar:pd.Timestamp, ticker:str, mode:str)->float|None:
    try:
        stamp = pd.Timestamp(bar)
        if stamp.tzinfo is None:
            stamp=stamp.tz_localize(market_zone(ticker))
        if mode=='1분':stamp+=pd.Timedelta(minutes=1)
        elif mode=='5분':stamp+=pd.Timedelta(minutes=5)
        else:stamp+=pd.Timedelta(hours=16 if market_zone(ticker).key=='America/New_York' else 15,minutes=30 if market_zone(ticker).key=='Asia/Seoul' else 0)
        return max(0,round((pd.Timestamp.now(tz='UTC')-stamp.tz_convert('UTC')).total_seconds()/60,1))
    except Exception: return None


def _payload(symbol:str,mode:str,source:str,cost_bps:int)->dict:
    cfg = Config.for_mode(mode, cost_bps)
    if source=='demo':
        market=demo_data(mode)
    elif source=='yahoo':
        market=yahoo_data(symbol,mode)
    else:
        key=os.environ.get('KIS_APP_KEY','')
        secret=os.environ.get('KIS_APP_SECRET','')
        if not key or not secret:
            raise ValueError('KIS 연결을 위해 서버 환경변수 KIS_APP_KEY 및 KIS_APP_SECRET이 필요합니다.')
        market=kis_data(symbol,mode,key,secret)
    f=feature_frame(market.bars,mode)
    d=decide(f,cfg)
    bt=run_backtest(market.bars,cfg)
    age=_last_age_minutes(f.index[-1],market.symbol if not market.synthetic else '005930.KS',mode)
    fresh_limit=8 if mode=='1분' else 25 if mode=='5분' else 3*24*60
    stale = False if market.synthetic else age is None or age > fresh_limit
    chart=f.iloc[-125:][['Close','ema20','ema50']]
    times=[x.isoformat() for x in chart.index]
    # Note: role #13 is a risk veto; it is NOT one of the 12 counted directional votes.
    return {
        'symbol': market.symbol,
        'mode':mode,'source':source,'provider':market.provider,
        'is_demo':market.synthetic, 'is_stale':stale,
        'price_age_minutes':age, 'fetched_at':market.retrieved_at,
        'quote_time':market.quote_time,'last_completed_bar':d.time,
        'freshness':market.freshness,'provider_note':market.note,
        'currency':market.currency,
        'quote':_safe_float(market.quote),'reference':_safe_float(d.reference),
        'signal':d.signal,'signal_label':LABEL[d.signal],
        'signal_is_current':not market.synthetic and not stale,
        'rsi':_safe_float(d.rsi),
        'atr':_safe_float(d.atr),
        'buy_votes':d.buy_votes,'sell_votes':d.sell_votes,'hold_votes':d.hold_votes,
        'risk_veto':d.risk_veto,'risk_message':d.risk_message,
        'long_stop_reference':_safe_float(d.stop),
        'long_target_reference':_safe_float(d.target),
        'long_risk_reward':_safe_float(d.risk_reward),
        'cost_bps_one_side':cost_bps,
        'max_hold_bars':cfg.max_hold_bars,
        'votes':[{'role':x.role,'direction':x.direction,'label':x.label,'reason':x.reason,'category':x.category} for x in d.votes],
        'chart':{'dates':times,'close':[_safe_float(x) for x in chart['Close']],
                 'ema20':[_safe_float(x) for x in chart['ema20']],
                 'ema50':[_safe_float(x) for x in chart['ema50']]},
        'backtest':{
            'total_return_pct':_safe_float(bt.total_return*100),
            'benchmark_return_pct':_safe_float(bt.benchmark_return*100),
            'max_drawdown_pct':_safe_float(bt.max_drawdown*100),
            'closed_trades':bt.closed_trades,
            'win_rate_pct':_safe_float(bt.win_rate*100 if bt.win_rate is not None else None),
            'directional_hit_rate_pct':_safe_float(bt.directional_hit_rate*100 if bt.directional_hit_rate is not None else None),
            'directional_samples':bt.directional_samples,
            'last_20pct_rate_pct':_safe_float(bt.latest_20pct_hit_rate*100 if bt.latest_20pct_hit_rate is not None else None),
            'last_20pct_samples':bt.latest_20pct_samples,
            'buy_signals':bt.buy_signals,'sell_signals':bt.sell_signals,
            'curve':{'dates':[str(i) for i in bt.curve.index[::max(1,len(bt.curve)//90)]],
                      'strategy':[_safe_float(v) for v in bt.curve['전략 자산'].iloc[::max(1,len(bt.curve)//90)]],
                      'benchmark':[_safe_float(v) for v in bt.curve['비교 매수보유'].iloc[::max(1,len(bt.curve)//90)]]},
            'recent_trades':[
                {'entry':str(x['진입시점']),'exit':str(x['청산시점']),
                 'pnl_pct':_safe_float(x['수익률']*100),'reason':str(x['청산사유'])}
                for x in bt.trades.tail(8).iloc[::-1].to_dict('records')],
        },
        'disclaimer':'규칙 기반 분석이며 미래 수익률을 예측·보장하지 않습니다. 마지막 완료봉에 근거하며 매도는 보유분 축소 의견입니다.',
    }


@app.get('/')
def index():
    return FileResponse(ASSETS/'index.html',headers={'Cache-Control':'no-cache'})

@app.get('/manifest.webmanifest')
def manifest():
    return FileResponse(ASSETS/'manifest.webmanifest',media_type='application/manifest+json')

@app.get('/sw.js')
def service_worker():
    return FileResponse(ASSETS/'sw.js',media_type='application/javascript',headers={'Cache-Control':'no-store','Service-Worker-Allowed':'/'})

@app.get('/healthz')
def healthz():
    return {'status':'ok','orders_enabled':False,'app_version':'3.6','stock_name_search':True,'dart_feature':True,'financial_risk_filter':True,'historical_fundamental_backtest':False,'forward_signal_journal':True,'persistent_server_journal':False,'watchlist_visible_tab_only':True,'push_notifications':False}

@app.get('/api/status')
def status(request:Request):
    _authorize(request)
    return {'kis_configured':bool(os.environ.get('KIS_APP_KEY') and os.environ.get('KIS_APP_SECRET')),
            'dart_configured':len(os.environ.get('OPENDART_API_KEY','').strip())==40,
            'server_time_utc':datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'yahoo_realtime_guaranteed':False,'streaming':False,'real_orders':False,
            'lan_without_auth':os.environ.get('NOVA_BIND_HOST')=='0.0.0.0' and not bool(os.environ.get('NOVA_ACCESS_TOKEN'))}

@app.get('/api/search')
def stock_search(request: Request, q: str = ''):
    _authorize(request)
    _limit(request)
    if not 1 <= len(q.strip()) <= 40:
        raise HTTPException(422, '검색어를 1~40자로 입력하세요.')
    try:
        result = _cached(('stock_search', q.strip().casefold()), lambda: search_stocks(q))
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})




@app.get('/api/fundamentals')
def fundamentals(request: Request, symbol: str, years: int = 3):
    """Read-only official OpenDART; no historical trading-signal look-ahead."""
    _authorize(request)
    _limit(request)
    try:
        symbol=ticker_format(symbol)
        client=get_client()
        # Cache key includes a fingerprint of the configured key, not the key itself.
        key_fingerprint=hashlib.sha256(client.key.encode()).hexdigest()[:12]
        result=_cached(('dart',key_fingerprint,symbol,years),
                       lambda:client.overview(symbol,years=years),ttl=FIN_CACHE_TTL)
        # Pure current-time overlay. Deliberately not inserted into historical OHLC backtests.
        body=dict(result)
        body['financial_gate']=assess_financial(body)
        return JSONResponse(body,headers={'Cache-Control':'no-store'})
    except DARTError as exc:
        code=exc.code
        status=503 if code in ('no_key','network','registry_network','020','012','800') else 422
        raise HTTPException(status, {'code':code,'message':str(exc)}) from None
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    except Exception:
        # Do not accidentally leak key via requests exception's URL in response.
        raise HTTPException(502, 'DART 재무정보 처리 실패. 서버 로그를 확인하세요.') from None



def _journal_daily_bars(symbol: str, source: str) -> pd.DataFrame:
    """Use finished daily candles; never cache an unfinished in-session bar."""
    key = (symbol, source)
    now = time.monotonic()
    with JOURNAL_CACHE_LOCK:
        cached = JOURNAL_FRAMES.get(key)
        if cached is not None and now - cached[0] <= JOURNAL_CACHE_TTL:
            return cached[1].copy()
    if source == 'yahoo':
        d = yahoo_data(symbol, '스윙').bars
    elif source == 'kis':
        key_id = os.environ.get('KIS_APP_KEY', '')
        secret = os.environ.get('KIS_APP_SECRET', '')
        if not key_id or not secret:
            raise ValueError('KIS API 키가 서버에 설정되지 않았습니다.')
        d = kis_data(symbol, '스윙', key_id, secret).bars
    else:
        raise ValueError('지원되지 않는 시세 공급원입니다.')
    with JOURNAL_CACHE_LOCK:
        if len(JOURNAL_FRAMES) >= 15:
            JOURNAL_FRAMES.clear()
        JOURNAL_FRAMES[key] = (time.monotonic(), d.copy())
    return d


@app.post('/api/journal/evaluate')
def journal_evaluate(request: Request, body: dict):
    """Evaluate browser-held snapshots, with no server-side journal persistence."""
    _authorize(request)
    _limit(request)
    try:
        return JSONResponse(evaluate_batch(body.get('records'), _journal_daily_bars),
                            headers={'Cache-Control': 'no-store'})
    except (TypeError, ValueError) as exc:
        raise HTTPException(422, str(exc)) from None



# v3.6: bounded foreground watchlist scan. Does not register cron jobs or trade orders.
# A scan generates CURRENT rule-based signals; its output is NOT a backtested probability.
def _watch_item(symbol: str, mode: str, source: str, cost_bps: int) -> dict:
    key = ('v36-watch-item', source, symbol, mode, cost_bps)

    def calculate() -> dict:
        if source == 'yahoo':
            market = yahoo_data(symbol, mode)
        else:
            app_key, secret = os.environ.get('KIS_APP_KEY', ''), os.environ.get('KIS_APP_SECRET', '')
            if not (app_key and secret):
                raise ValueError('KIS 연동 키가 설정되지 않았습니다.')
            market = kis_data(symbol, mode, app_key, secret)
        features = feature_frame(market.bars, mode)
        decision = decide(features, Config.for_mode(mode, cost_bps))
        age = _last_age_minutes(features.index[-1], market.symbol, mode)
        stale_limit = 8 if mode == '1분' else 25 if mode == '5분' else 3 * 24 * 60
        is_stale = age is None or age > stale_limit
        result = {
            'symbol': market.symbol, 'mode': mode, 'source': source,
            'status': 'ok', 'technical': decision.signal,
            'combined': decision.signal, 'financial_gate': 'NOT_APPLIED',
            'finance_note': '단타에는 현재 재무 위험 필터를 적용하지 않습니다.',
            'reference': _safe_float(decision.reference), 'currency': market.currency,
            'stop': _safe_float(decision.stop), 'target': _safe_float(decision.target),
            'risk_reward': _safe_float(decision.risk_reward),
            'bar_time': decision.time, 'provider': market.provider,
            'fetched_at': market.retrieved_at,
            'price_age_minutes': age, 'is_stale': is_stale or bool(market.synthetic), 'is_demo': bool(market.synthetic),
            'freshness': market.freshness, 'provider_note': market.note,
            'risk_veto': decision.risk_veto,
            'note': '완료봉 기반 규칙형 신호. 실시간 시세 보장 및 주문 실행 없음.'
        }
        if mode == '스윙':
            if symbol.endswith(('.KS', '.KQ')):
                try:
                    client = get_client()
                    fingerprint = hashlib.sha256(client.key.encode()).hexdigest()[:12]
                    overview = _cached(('dart', fingerprint, symbol, 3),
                                       lambda: client.overview(symbol, years=3), ttl=FIN_CACHE_TTL)
                    gate = assess_financial(overview)
                    fused = combine_signal(decision.signal, gate)
                    result['financial_gate'] = gate['gate']
                    result['finance_note'] = fused['reason']
                    result['combined'] = fused['combined']
                    result['financial_asof_year'] = gate['as_of_annual_year']
                except Exception:
                    # DART supplement may fail; keep the technical-only signal, explicitly unverified.
                    result['financial_gate'] = 'UNKNOWN'
                    result['finance_note'] = 'OpenDART 재무자료 미확인: 기술적 신호만 제시. 재무 검증을 통과한 것이 아닙니다.'
            else:
                result['financial_gate'] = 'NOT_SUPPORTED'
                result['finance_note'] = '미국주식 OpenDART 미지원: 기술적 신호만 표시.'
        return result

    return _cached(key, calculate, ttl=WATCH_CACHE_TTL)


@app.post('/api/watch/scan')
def watch_scan(request: Request, body: dict):
    """Read-only bounded batch, no disk persistence, no orders, no background task."""
    _authorize(request)
    _limit(request)
    symbols = body.get('symbols')
    modes = body.get('modes', ['5분', '스윙'])
    source = body.get('source', 'yahoo')
    cost_bps = body.get('cost_bps', 15)
    if not isinstance(symbols, list) or not 1 <= len(symbols) <= 5 or not all(isinstance(x, str) for x in symbols):
        raise HTTPException(422, '한 번에 1~5개 종목만 감시할 수 있습니다.')
    if not isinstance(modes, list) or not 1 <= len(modes) <= 2 or not all(isinstance(x,str) for x in modes) or len(set(modes)) != len(modes) or any(x not in MODES for x in modes):
        raise HTTPException(422, '분석 주기는 1분·5분·스윙 중 중복 없이 최대 2개를 선택하세요.')
    if source not in ('yahoo', 'kis'):
        raise HTTPException(422, '관심종목 감시는 Yahoo 또는 KIS 시세만 지원합니다.')
    if type(cost_bps) is not int or not 0 <= cost_bps <= 100:
        raise HTTPException(422, '거래비용은 편도 0~100bp로 지정하세요.')
    try:
        normalized = [ticker_format(x) for x in symbols]
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    if len(set(normalized)) != len(normalized):
        raise HTTPException(422, '중복 종목을 제거해 주세요.')
    if source == 'kis' and any(not s.endswith(('.KS', '.KQ')) for s in normalized):
        raise HTTPException(422, 'KIS 감시는 국내 상장 종목코드만 지원합니다.')
    tasks = [(symbol, mode) for symbol in normalized for mode in modes]
    rows = {}
    # Max 3 concurrent remote data calls for the small free Render instance.
    with ThreadPoolExecutor(max_workers=min(3, len(tasks))) as pool:
        futures = {pool.submit(_watch_item, s, m, source, cost_bps): (s, m) for s, m in tasks}
        for future in as_completed(futures):
            s, m = futures[future]
            try:
                rows[(s, m)] = future.result()
            except Exception as exc:
                # No provider URL or API credentials are included in client-facing errors.
                rows[(s, m)] = {'symbol': s, 'mode': m, 'source': source, 'status': 'error',
                                'error': f'시세 또는 재무자료 조회 실패 ({type(exc).__name__}).',
                                'is_stale': True, 'combined': None}
    results = [rows[key] for key in tasks]
    return JSONResponse({'status': 'ok', 'version': '3.6',
                         'scanned_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
                         'requested': len(tasks), 'successful': sum(x['status'] == 'ok' for x in results),
                         'results': results, 'polling': 'visible-tab-only', 'real_orders': False},
                        headers={'Cache-Control': 'no-store'})


@app.get('/api/analysis')
def analysis(request:Request,symbol:str='AAPL',mode:str='스윙',source:str='yahoo',cost_bps:int=15):
    _authorize(request)
    _limit(request)
    if mode not in MODES:raise HTTPException(422,'분석 주기는 1분, 5분, 스윙 중에서 선택하세요.')
    if source not in SOURCES:raise HTTPException(422,'올바르지 않은 공급원입니다.')
    if not 0<=cost_bps<=100:raise HTTPException(422,'거래비용은 편도 0~100bp로 입력하세요.')
    if source=='demo':symbol='DEMO'
    else:
        try: symbol=ticker_format(symbol)
        except ValueError as exc: raise HTTPException(422,str(exc)) from exc
    if source=='kis' and not (symbol.endswith('.KS') or symbol.endswith('.KQ')):
        raise HTTPException(422,'KIS는 국내 6자리 종목코드만 지원합니다.')
    try:
        value=_cached((source,symbol,mode,cost_bps),lambda:_payload(symbol,mode,source,cost_bps))
    except ValueError as exc:
        raise HTTPException(422,str(exc)) from exc
    except Exception as exc:
        raise HTTPException(502, f'시세 조회/분석 실패 ({type(exc).__name__}). 종목·데이터 기간·공급원/네트워크를 확인하세요.') from exc
    return JSONResponse(value,headers={'Cache-Control':'no-store'})

if __name__=='__main__':
    import uvicorn
    uvicorn.run(app,host=os.environ.get('NOVA_BIND_HOST','127.0.0.1'),port=int(os.environ.get('PORT','8000')))
