/* NOVA v3.9. Self-contained canvas candlestick chart (no CDN or analytics tracking).
 * Price data are already-finalized OHLC bars from the analysis response.
 * Wheel/pinch zoom, drag pan, tap a candle for OHLC and volume.
 */
'use strict';
(()=>{
 let current=null, mode='candles', visible=65, offset=0, hovered=null, dragging=null, pinch=null, bound=false;
 const byId=id=>document.getElementById(id);
 const clamp=(x,min,max)=>Math.max(min,Math.min(max,x));
 const fmt=n=>Number(n).toLocaleString('ko-KR',{maximumFractionDigits:Math.abs(n)<100?2:0});
 function valid(data){
   if(!data?.chart)return false;
   const x=data.chart,n=x.dates?.length||0;
   return n>=2 && ['open','high','low','close','volume'].every(k=>Array.isArray(x[k])&&x[k].length===n)
       && x.close.every((v,i)=>Number.isFinite(v)&&v>0&&Number.isFinite(x.open[i])&&Number.isFinite(x.high[i])&&Number.isFinite(x.low[i])&&x.low[i]<=Math.min(v,x.open[i])&&x.high[i]>=Math.max(v,x.open[i]));
 }
 function install(){
   const canvas=byId('candleCanvas');if(!canvas||bound)return;
   bound=true;
   byId('candleMode').addEventListener('change',e=>{mode=e.target.value;render();});
   byId('candleZoomIn').onclick=()=>{visible=clamp(Math.round(visible*.72),15,125);offset=clamp(offset,0,Math.max(0,(current?.chart?.dates.length||0)-visible));render();};
   byId('candleZoomOut').onclick=()=>{visible=clamp(Math.round(visible*1.4),15,125);offset=0;render();};
   byId('candleReset').onclick=()=>{visible=65;offset=0;hovered=null;render();};
   canvas.addEventListener('wheel',e=>{e.preventDefault();visible=clamp(Math.round(visible*(e.deltaY>0?1.16:.86)),15,125);offset=clamp(offset,0,Math.max(0,(current?.chart?.dates.length||0)-visible));render();},{passive:false});
   const point=e=>e.touches?.length?e.touches[0].clientX:e.clientX;
   canvas.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')return;dragging={x:point(e),base:offset,moved:false};canvas.setPointerCapture?.(e.pointerId);});
   canvas.addEventListener('pointermove',e=>{
     if(!dragging||!current||e.pointerType==='touch')return;
     const dist=e.clientX-dragging.x;if(Math.abs(dist)>6)dragging.moved=true;
     offset=clamp(Math.round(dragging.base-dist*visible/(canvas.clientWidth||300)),0,Math.max(0,current.chart.dates.length-visible));render();
   });
   canvas.addEventListener('pointerup',e=>{if(dragging&&!dragging.moved)selectCandle(e.offsetX);dragging=null;});
   canvas.addEventListener('touchstart',e=>{
     if(e.touches.length===2){pinch={distance:Math.abs(e.touches[1].clientX-e.touches[0].clientX),base:visible};dragging=null;}
     else if(e.touches.length===1){dragging={x:e.touches[0].clientX,base:offset,moved:false};pinch=null;}
   },{passive:true});
   canvas.addEventListener('touchmove',e=>{
     if(!current)return;
     if(e.touches.length===2&&pinch){e.preventDefault();let d=Math.abs(e.touches[1].clientX-e.touches[0].clientX);visible=clamp(Math.round(pinch.base*pinch.distance/Math.max(10,d)),15,125);offset=clamp(offset,0,Math.max(0,current.chart.dates.length-visible));render();}
     else if(e.touches.length===1&&dragging){e.preventDefault();const dist=e.touches[0].clientX-dragging.x;if(Math.abs(dist)>5)dragging.moved=true;
       offset=clamp(Math.round(dragging.base-dist*visible/(canvas.clientWidth||300)),0,Math.max(0,current.chart.dates.length-visible));render();}
   },{passive:false});
   canvas.addEventListener('touchend',e=>{if(dragging&&!dragging.moved&&e.changedTouches.length){const rect=canvas.getBoundingClientRect();selectCandle(e.changedTouches[0].clientX-rect.left);}dragging=null;pinch=null;});
   if('ResizeObserver'in window)new ResizeObserver(()=>render()).observe(canvas);
   window.addEventListener('resize',render);
 }
 function range(){const x=current.chart, n=x.dates.length,cnt=Math.min(visible,n),end=n-offset,start=Math.max(0,end-cnt);return {x,n,start,end,cnt};}
 function selectCandle(px){if(!current)return;const canvas=byId('candleCanvas'),{start,cnt}=range();const left=10,right=59;
   const width=Math.max(5,canvas.clientWidth-left-right);hovered=clamp(start+Math.floor((px-left)/width*cnt),start,start+cnt-1);render();}
 function render(){
   const canvas=byId('candleCanvas');if(!canvas||!current||!valid(current)||canvas.clientWidth<60)return;
   const device=Math.min(window.devicePixelRatio||1,2.5), width=canvas.clientWidth,height=canvas.clientHeight||315;
   canvas.width=Math.round(width*device);canvas.height=Math.round(height*device);
   const ctx=canvas.getContext('2d');ctx.setTransform(device,0,0,device,0,0);ctx.clearRect(0,0,width,height);
   const {x,start,end,cnt}=range(),left=10,right=64,top=18,bottom=27,volHeight=52,sep=11;
   const cw=width-left-right,pBottom=height-bottom-volHeight-sep, pHeight=pBottom-top;
   if(cw<=20||pHeight<=30)return;
   const lo=Math.min(...x.low.slice(start,end)),hi=Math.max(...x.high.slice(start,end)),pad=Math.max((hi-lo)*.12,hi*.0001);
   const min=lo-pad,max=hi+pad, y=v=>top+(max-v)/(max-min)*pHeight;
   const bx=i=>left+((i-start)+.5)*cw/cnt, step=cw/cnt;
   ctx.font='11px system-ui, sans-serif';ctx.textAlign='right';ctx.textBaseline='middle';
   for(let i=0;i<5;i++){const yy=top+i*pHeight/4;ctx.strokeStyle='rgba(140,185,195,.14)';ctx.beginPath();ctx.moveTo(left,yy);ctx.lineTo(width-right+3,yy);ctx.stroke();ctx.fillStyle='#83a5b4';ctx.fillText(fmt(max-i*(max-min)/4),width-4,yy);}
   const maxVol=Math.max(1,...x.volume.slice(start,end));const vy=height-bottom;
   for(let i=start;i<end;i++){
     const open=x.open[i],close=x.close[i],high=x.high[i],low=x.low[i],up=close>=open, xx=bx(i),color=up?'#29d6b3':'#f07888';
     if(mode==='candles'){
       ctx.strokeStyle=color;ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(xx,y(high));ctx.lineTo(xx,y(low));ctx.stroke();
       ctx.fillStyle=color;ctx.fillRect(xx-Math.max(1,step*.34),Math.min(y(open),y(close)),Math.max(2,Math.min(18,step*.68)),Math.max(1.5,Math.abs(y(open)-y(close))));
     }
     ctx.fillStyle=up?'rgba(41,214,179,.38)':'rgba(240,120,136,.38)';
     ctx.fillRect(xx-Math.min(16,step*.28),vy-(Number(x.volume[i])||0)/maxVol*volHeight,Math.max(1.5,Math.min(16,step*.56)),(Number(x.volume[i])||0)/maxVol*volHeight);
   }
   const drawLine=(vals,color,lineWidth)=>{
     ctx.strokeStyle=color;ctx.lineWidth=lineWidth;ctx.lineJoin='round';ctx.beginPath();let started=false;
     for(let i=start;i<end;i++){const v=vals?.[i];if(v==null||!Number.isFinite(v)){started=false;continue;}const xx=bx(i);if(started)ctx.lineTo(xx,y(v));else{ctx.moveTo(xx,y(v));started=true;}}
     ctx.stroke();
   };
   if(mode==='line')drawLine(x.close,'#36e1bb',2.4);
   drawLine(x.ema20,'#9eb8ff',1.4);drawLine(x.ema50,'#e8bc71',1.4);
   [['long_stop_reference','#ee7a8a','손절'],['long_target_reference','#45c995','목표']].forEach(([k,color,label])=>{
     const v=current[k];if(!Number.isFinite(v)||v<min||v>max)return;
     ctx.setLineDash([4,5]);ctx.strokeStyle=color;ctx.beginPath();ctx.moveTo(left,y(v));ctx.lineTo(width-right,y(v));ctx.stroke();ctx.setLineDash([]);
     ctx.fillStyle=color;ctx.font='10px system-ui';ctx.textAlign='left';ctx.fillText(label,left+4,y(v)-7);ctx.textAlign='right';
   });
   ctx.fillStyle='#779aa9';ctx.textAlign='left';ctx.font='10px system-ui';ctx.fillText('거래량',left+4,vy-volHeight+8);
   [start,Math.floor((start+end-1)/2),end-1].forEach((i,j)=>{if(i<start||i>=end)return;const stamp=String(x.dates[i]||'').replace('T',' ').slice(current.mode==='스윙'?5:5,current.mode==='스윙'?10:16);ctx.textAlign=j===0?'left':j===2?'right':'center';ctx.fillText(stamp,bx(i),height-10);});
   if(hovered!=null&&hovered>=start&&hovered<end){const xx=bx(hovered);ctx.strokeStyle='rgba(220,244,245,.5)';ctx.setLineDash([3,3]);ctx.beginPath();ctx.moveTo(xx,top);ctx.lineTo(xx,vy);ctx.stroke();ctx.setLineDash([]);}
   const endIndex=hovered!=null&&hovered<end&&hovered>=start?hovered:end-1;
   byId('candleDetails').textContent=`${String(x.dates[endIndex]).replace('T',' ').slice(0,19)} · 시 ${fmt(x.open[endIndex])} / 고 ${fmt(x.high[endIndex])} / 저 ${fmt(x.low[endIndex])} / 종 ${fmt(x.close[endIndex])} · 거래량 ${fmt(x.volume[endIndex])}`;
 }
 function draw(d){install();current=valid(d)?d:null;hovered=null;offset=0;visible=65;
   if(!current){if(byId('candleDetails'))byId('candleDetails').textContent='OHLC 데이터가 없거나 유효하지 않아 캔들을 표시하지 않습니다.';return;}
   requestAnimationFrame(render);
 }
 window.NOVACandles={draw,render,valid};
})();
