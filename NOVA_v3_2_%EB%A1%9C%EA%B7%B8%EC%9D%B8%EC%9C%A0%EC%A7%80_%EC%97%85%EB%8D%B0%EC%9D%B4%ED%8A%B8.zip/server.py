"""NOVA v3 mobile PWA API: read-only, no trading endpoints and no broker order capability.
Start locally with `python server.py`; see README for LAN/public access.
"""
from __future__ import annotations

import hmac
import hashlib
import secrets
import math
import os
from pathlib import Path
import threading
import time
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

import pandas as pd
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from engine import Config, feature_frame, decide
from backtest import run_backtest
from data_sources import demo_data, yahoo_data, kis_data, ticker_format, market_zone
from stock_lookup import search_stocks

BASE = Path(__file__).resolve().parent
ASSETS = BASE / 'static'
app = FastAPI(title='NOVA AI Trading Mobile', docs_url=None, redoc_url=None, openapi_url=None)
app.mount('/static', StaticFiles(directory=ASSETS), name='static')
CACHE_LOCK = threading.Lock()
CACHE = {}
RATE = {}
CACHE_TTL = 52
MAX_CACHE = 72
KST = ZoneInfo('Asia/Seoul')
LABEL = {'BUY':'매수 후보', 'SELL':'매도·보유분 축소 검토', 'HOLD':'관망'}
MODES = {'1분','5분','스윙'}
SOURCES = {'yahoo','kis','demo'}
AUTH_COOKIE = 'nova3_auth'
REMEMBER_SECONDS = 30 * 24 * 3600
SESSION_SECONDS = 12 * 3600

if os.environ.get('NOVA_PUBLIC_DEPLOY') == '1' and len(os.environ.get('NOVA_ACCESS_TOKEN','')) < 16:
    raise RuntimeError('공개 서버 배포시 NOVA_ACCESS_TOKEN을 16자 이상으로 설정하세요.')


def _cookie_key(token: str) -> bytes:
    # Server-only key. Changing NOVA_ACCESS_TOKEN invalidates all remembered devices.
    return hashlib.sha256(('nova3-cookie:v1:' + token).encode('utf-8')).digest()


def _cookie_valid(value: str, token: str) -> bool:
    if not value or not token:
        return False
    try:
        version, expiry, nonce, signature = value.split('.')
        if version != 'v1' or not expiry.isdecimal() or len(nonce) != 32 or len(signature) != 64:
            return False
        if not all(ch in '0123456789abcdef' for ch in nonce + signature):
            return False
        exp = int(expiry)
        now = int(time.time())
        if not now < exp <= now + REMEMBER_SECONDS:
            return False
        message = f'{version}.{expiry}.{nonce}'
        expected = hmac.new(_cookie_key(token), message.encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature)
    except (ValueError, TypeError):
        return False


def _is_authenticated(request: Request) -> bool:
    token = os.environ.get('NOVA_ACCESS_TOKEN', '')
    if not token:
        return True
    supplied = request.headers.get('Authorization', '')
    if supplied and hmac.compare_digest(supplied, 'Bearer ' + token):
        return True
    return _cookie_valid(request.cookies.get(AUTH_COOKIE, ''), token)


def _authorize(request: Request):
    if not _is_authenticated(request):
        raise HTTPException(401, '인증이 만료됐습니다. 설정에서 서버 접근 토큰을 입력하세요.')


def _secure_cookie(request: Request) -> bool:
    # Render sets NOVA_PUBLIC_DEPLOY=1. Local HTTP development continues to work.
    return os.environ.get('NOVA_PUBLIC_DEPLOY') == '1' or request.url.scheme == 'https'


@app.get('/api/auth/status')
def auth_status(request: Request):
    return JSONResponse({'authenticated': _is_authenticated(request),
                         'token_required': bool(os.environ.get('NOVA_ACCESS_TOKEN'))},
                        headers={'Cache-Control': 'no-store'})


@app.post('/api/auth/login')
def auth_login(request: Request, body: dict):
    _limit(request)
    expected = os.environ.get('NOVA_ACCESS_TOKEN', '')
    supplied = body.get('token', '')
    remember = body.get('remember') is True
    if not isinstance(supplied, str) or len(supplied) > 1024:
        raise HTTPException(400, '올바르지 않은 토큰 형식입니다.')
    if expected and not hmac.compare_digest(supplied, expected):
        raise HTTPException(401, '서버 접근 토큰이 일치하지 않습니다.')
    response = JSONResponse({'authenticated': True, 'remembered': remember, 'days': 30 if remember else 0},
                            headers={'Cache-Control': 'no-store'})
    if expected:
        duration = REMEMBER_SECONDS if remember else SESSION_SECONDS
        expiry = str(int(time.time()) + duration)
        message = f'v1.{expiry}.{secrets.token_hex(16)}'
        signature = hmac.new(_cookie_key(expected), message.encode(), hashlib.sha256).hexdigest()
        response.set_cookie(AUTH_COOKIE, message + '.' + signature,
                            max_age=duration if remember else None,
                            httponly=True, secure=_secure_cookie(request),
                            samesite='lax', path='/')
    return response


@app.post('/api/auth/logout')
def auth_logout(request: Request):
    response = JSONResponse({'authenticated': False}, headers={'Cache-Control':'no-store'})
    response.delete_cookie(AUTH_COOKIE, path='/', secure=_secure_cookie(request), httponly=True, samesite='lax')
    return response


def _limit(request: Request):
    ip = request.client.host if request.client else 'unknown'
    now = time.monotonic()
    with CACHE_LOCK:
        ts = [x for x in RATE.get(ip,[]) if now-x < 60]
        if len(ts) >= 24:
            raise HTTPException(429, '요청이 너무 많습니다. 잠시 뒤 다시 조회하세요.')
        ts.append(now)
        RATE[ip] = ts
        if len(RATE)>500:
            RATE.clear()


def _cached(key, make):
    now = time.monotonic()
    with CACHE_LOCK:
        entry = CACHE.get(key)
        if entry and now-entry[0] <= CACHE_TTL:
            return dict(entry[1], cached=True, cache_age_seconds=round(now-entry[0]))
    result = make()
    with CACHE_LOCK:
        if len(CACHE)>=MAX_CACHE:
            CACHE.clear()
        CACHE[key]=(time.monotonic(),result)
    return dict(result,cached=False,cache_age_seconds=0)


def _safe_float(n):
    try:
        v=float(n)
        return round(v,6) if math.isfinite(v) else None
    except (ValueError,TypeError):return None


def _last_age_minutes(bar:pd.Timestamp, ticker:str, mode:str)->float|None:
    try:
        stamp = pd.Timestamp(bar)
        if stamp.tzinfo is None:
            stamp=stamp.tz_localize(market_zone(ticker))
        if mode=='1분':stamp+=pd.Timedelta(minutes=1)
        elif mode=='5분':stamp+=pd.Timedelta(minutes=5)
        else:stamp+=pd.Timedelta(hours=16 if market_zone(ticker).key=='America/New_York' else 15,minutes=30 if market_zone(ticker).key=='Asia/Seoul' else 0)
        return max(0,round((pd.Timestamp.now(tz='UTC')-stamp.tz_convert('UTC')).total_seconds()/60,1))
    except Exception: return None


def _payload(symbol:str,mode:str,source:str,cost_bps:int)->dict:
    cfg = Config.for_mode(mode, cost_bps)
    if source=='demo':
        market=demo_data(mode)
    elif source=='yahoo':
        market=yahoo_data(symbol,mode)
    else:
        key=os.environ.get('KIS_APP_KEY','')
        secret=os.environ.get('KIS_APP_SECRET','')
        if not key or not secret:
            raise ValueError('KIS 연결을 위해 서버 환경변수 KIS_APP_KEY 및 KIS_APP_SECRET이 필요합니다.')
        market=kis_data(symbol,mode,key,secret)
    f=feature_frame(market.bars,mode)
    d=decide(f,cfg)
    bt=run_backtest(market.bars,cfg)
    age=_last_age_minutes(f.index[-1],market.symbol if not market.synthetic else '005930.KS',mode)
    fresh_limit=8 if mode=='1분' else 25 if mode=='5분' else 3*24*60
    stale = False if market.synthetic else age is None or age > fresh_limit
    chart=f.iloc[-125:][['Close','ema20','ema50']]
    times=[x.isoformat() for x in chart.index]
    # Note: role #13 is a risk veto; it is NOT one of the 12 counted directional votes.
    return {
        'symbol': market.symbol,
        'mode':mode,'source':source,'provider':market.provider,
        'is_demo':market.synthetic, 'is_stale':stale,
        'price_age_minutes':age, 'fetched_at':market.retrieved_at,
        'quote_time':market.quote_time,'last_completed_bar':d.time,
        'freshness':market.freshness,'provider_note':market.note,
        'currency':market.currency,
        'quote':_safe_float(market.quote),'reference':_safe_float(d.reference),
        'signal':d.signal,'signal_label':LABEL[d.signal],
        'signal_is_current':not market.synthetic and not stale,
        'rsi':_safe_float(d.rsi),
        'atr':_safe_float(d.atr),
        'buy_votes':d.buy_votes,'sell_votes':d.sell_votes,'hold_votes':d.hold_votes,
        'risk_veto':d.risk_veto,'risk_message':d.risk_message,
        'long_stop_reference':_safe_float(d.stop),
        'long_target_reference':_safe_float(d.target),
        'long_risk_reward':_safe_float(d.risk_reward),
        'cost_bps_one_side':cost_bps,
        'max_hold_bars':cfg.max_hold_bars,
        'votes':[{'role':x.role,'direction':x.direction,'label':x.label,'reason':x.reason,'category':x.category} for x in d.votes],
        'chart':{'dates':times,'close':[_safe_float(x) for x in chart['Close']],
                 'ema20':[_safe_float(x) for x in chart['ema20']],
                 'ema50':[_safe_float(x) for x in chart['ema50']]},
        'backtest':{
            'total_return_pct':_safe_float(bt.total_return*100),
            'benchmark_return_pct':_safe_float(bt.benchmark_return*100),
            'max_drawdown_pct':_safe_float(bt.max_drawdown*100),
            'closed_trades':bt.closed_trades,
            'win_rate_pct':_safe_float(bt.win_rate*100 if bt.win_rate is not None else None),
            'directional_hit_rate_pct':_safe_float(bt.directional_hit_rate*100 if bt.directional_hit_rate is not None else None),
            'directional_samples':bt.directional_samples,
            'last_20pct_rate_pct':_safe_float(bt.latest_20pct_hit_rate*100 if bt.latest_20pct_hit_rate is not None else None),
            'last_20pct_samples':bt.latest_20pct_samples,
            'buy_signals':bt.buy_signals,'sell_signals':bt.sell_signals,
            'curve':{'dates':[str(i) for i in bt.curve.index[::max(1,len(bt.curve)//90)]],
                      'strategy':[_safe_float(v) for v in bt.curve['전략 자산'].iloc[::max(1,len(bt.curve)//90)]],
                      'benchmark':[_safe_float(v) for v in bt.curve['비교 매수보유'].iloc[::max(1,len(bt.curve)//90)]]},
            'recent_trades':[
                {'entry':str(x['진입시점']),'exit':str(x['청산시점']),
                 'pnl_pct':_safe_float(x['수익률']*100),'reason':str(x['청산사유'])}
                for x in bt.trades.tail(8).iloc[::-1].to_dict('records')],
        },
        'disclaimer':'규칙 기반 분석이며 미래 수익률을 예측·보장하지 않습니다. 마지막 완료봉에 근거하며 매도는 보유분 축소 의견입니다.',
    }


@app.get('/')
def index():
    return FileResponse(ASSETS/'index.html',headers={'Cache-Control':'no-cache'})

@app.get('/manifest.webmanifest')
def manifest():
    return FileResponse(ASSETS/'manifest.webmanifest',media_type='application/manifest+json')

@app.get('/sw.js')
def service_worker():
    return FileResponse(ASSETS/'sw.js',media_type='application/javascript',headers={'Cache-Control':'no-store','Service-Worker-Allowed':'/'})

@app.get('/healthz')
def healthz():
    return {'status':'ok','orders_enabled':False,'app_version':'3.2','stock_name_search':True}

@app.get('/api/status')
def status(request:Request):
    _authorize(request)
    return {'kis_configured':bool(os.environ.get('KIS_APP_KEY') and os.environ.get('KIS_APP_SECRET')),
            'server_time_utc':datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'yahoo_realtime_guaranteed':False,'streaming':False,'real_orders':False,
            'lan_without_auth':os.environ.get('NOVA_BIND_HOST')=='0.0.0.0' and not bool(os.environ.get('NOVA_ACCESS_TOKEN'))}

@app.get('/api/search')
def stock_search(request: Request, q: str = ''):
    _authorize(request)
    _limit(request)
    if not 1 <= len(q.strip()) <= 40:
        raise HTTPException(422, '검색어를 1~40자로 입력하세요.')
    try:
        result = _cached(('stock_search', q.strip().casefold()), lambda: search_stocks(q))
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})


@app.get('/api/analysis')
def analysis(request:Request,symbol:str='AAPL',mode:str='스윙',source:str='yahoo',cost_bps:int=15):
    _authorize(request)
    _limit(request)
    if mode not in MODES:raise HTTPException(422,'분석 주기는 1분, 5분, 스윙 중에서 선택하세요.')
    if source not in SOURCES:raise HTTPException(422,'올바르지 않은 공급원입니다.')
    if not 0<=cost_bps<=100:raise HTTPException(422,'거래비용은 편도 0~100bp로 입력하세요.')
    if source=='demo':symbol='DEMO'
    else:
        try: symbol=ticker_format(symbol)
        except ValueError as exc: raise HTTPException(422,str(exc)) from exc
    if source=='kis' and not (symbol.endswith('.KS') or symbol.endswith('.KQ')):
        raise HTTPException(422,'KIS는 국내 6자리 종목코드만 지원합니다.')
    try:
        value=_cached((source,symbol,mode,cost_bps),lambda:_payload(symbol,mode,source,cost_bps))
    except ValueError as exc:
        raise HTTPException(422,str(exc)) from exc
    except Exception as exc:
        raise HTTPException(502, f'시세 조회/분석 실패 ({type(exc).__name__}). 종목·데이터 기간·공급원/네트워크를 확인하세요.') from exc
    return JSONResponse(value,headers={'Cache-Control':'no-store'})

if __name__=='__main__':
    import uvicorn
    uvicorn.run(app,host=os.environ.get('NOVA_BIND_HOST','127.0.0.1'),port=int(os.environ.get('PORT','8000')))
