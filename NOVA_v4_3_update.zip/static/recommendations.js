/* NOVA v4.3: on-demand, authenticated FSC T+1 or KRX EOD scanner. No orders. */
'use strict';
(()=>{
  const $ = id=>document.getElementById(id);
  const preview=Boolean(window.NOVA_PREVIEW_DATA);
  let timer=null, busy=false, lastJob='', shownResult='';
  const viewOpen=()=>window.NOVAConnect?.currentView()==='recommendations'&&!document.hidden;
  const won=v=>v==null||!Number.isFinite(Number(v))?'미확인':new Intl.NumberFormat('ko-KR',{maximumFractionDigits:0}).format(Number(v))+'원';
  const money=v=>v==null?'—':new Intl.NumberFormat('ko-KR',{maximumFractionDigits:1}).format(Number(v)/1e8)+'억원';
  const headers=()=>{const h={};try{const t=sessionStorage.getItem('nova3-token');if(t)h.Authorization='Bearer '+t;}catch{}return h;};
  const status=(message,warn=false)=>{const p=$('recommendStatus');if(p){p.textContent=message;p.classList.toggle('warn',warn);}};
  function cell(title,value){const card=document.createElement('div');card.className='recommend-stat';const l=document.createElement('span');l.textContent=title;const v=document.createElement('strong');v.textContent=String(value);card.append(l,v);return card;}
  function render(res){
    const nums=$('recommendNumbers'), list=$('recommendResults');if(!nums||!list)return;
    nums.replaceChildren();list.replaceChildren();nums.hidden=false;
    nums.append(cell('시장 전체 조회',`${res.total_market_rows??0}종목`),
      cell('1차 통과',`${res.screen_passed??0}종목`),
      cell('NOVA 심층 분석',`${res.deep_succeeded??0}/${res.deep_target??0}종목`),
      cell('최종 매수 후보',`${res.recommended_count??0}종목`));
    const pre=document.createElement('div');pre.className='recommend-status';
    const m=(res.markets_scanned||[]).map(x=>x==='kospi'?'코스피':'코스닥').join(' + ');
    pre.textContent=`${res.data_source||'일별 자료'} · 기준일 ${res.data_date||'미확인'} · ${m}\n선별 범위: 전체 일별 종목 ${res.total_market_rows}개 → 1차 ${res.screen_passed}개 → 상위 ${res.deep_target}개 심층 검증 · 심층 실패 ${res.deep_failed||0}개. 단타·실시간 검색이 아닌 장 마감 스윙 조건입니다.`;
    list.appendChild(pre);
    const items=Array.isArray(res.recommendations)?res.recommendations:[];
    if(!items.length){const blank=document.createElement('div');blank.className='recommend-empty';
      blank.textContent=(res.deep_failed?'심층 자료 조회 실패가 있어 일부 평가가 불완전합니다. ':'')+'이번 검색에서 모든 기술·재무·검증 조건을 통과한 종목이 없습니다. 추천 개수를 맞추기 위해 무리하게 추가하지 않습니다.';
      list.appendChild(blank);}
    for(const [i,r] of items.entries()){
      const card=document.createElement('article');card.className='recommend-card';
      const head=document.createElement('div');head.className='recommend-title';
      const name=document.createElement('strong');name.textContent=`${i+1}. ${r.name}`;
      const tag=document.createElement('em');tag.textContent='매수 후보';head.append(name,tag);card.append(head);
      const meta=document.createElement('p');meta.className='recommend-meta';meta.textContent=`${r.symbol} · ${r.market==='kospi'?'코스피':'코스닥'} · 기준일 ${r.asof} · ${r.price_data_source || ('시장 종가 '+won(r.close_krx))} · NOVA 완료봉 ${r.last_completed_bar||'미확인'}`;card.append(meta);
      const reasons=document.createElement('ul');reasons.className='recommend-reasons';
      for(const t of r.reason||[]){const li=document.createElement('li');li.textContent=t;reasons.appendChild(li);}card.append(reasons);
      const prices=document.createElement('div');prices.className='recommend-prices';
      for(const [l,v] of [['분석 기준가',r.reference],['손절 참고',r.stop],['목표 참고',r.target]]){
        const box=document.createElement('div');const label=document.createElement('span');label.textContent=l;const val=document.createElement('strong');val.textContent=won(v);box.append(label,val);prices.append(box);
      }card.append(prices);
      const open=document.createElement('button');open.type='button';open.className='recommend-open';open.textContent='종목 상세 분석 열기 ›';open.onclick=()=>window.NOVAConnect?.openRecommendation(r.symbol,r.name);card.append(open);
      list.append(card);
    }
    const foot=document.createElement('p');foot.className='note';foot.textContent=`${res.data_lag||'장 마감 자료'} 기준. 조회된 날짜의 장 마감 자료 기준입니다. 총 ${res.total_market_rows}개 종목 각각에 대해 장기 기술적 백테스트를 실행한 것은 아닙니다. 종목별 과거 성과는 미래 확률이 아닙니다. 서버가 재시작되면 기록이 사라집니다.`;list.append(foot);
    if((res.rejected||[]).length){const info=document.createElement('details');info.className='install-guide recommend-help';const summ=document.createElement('summary');summ.textContent=`심층 검토에서 제외된 종목 ${(res.rejected||[]).length}개 보기`;info.append(summ);for(const x of res.rejected||[]){const p=document.createElement('p');p.textContent=`${x.name} (${x.symbol}): ${x.reason}`;info.append(p);}list.append(info);}
  }
  async function fetchState(){
    if(preview){status('오프라인 체험판에서는 실데이터 전체 검색을 실행하지 않습니다. 서버에 금융위원회 API 키를 설정하세요.',true);return;}
    if(busy)return;
    busy=true;
    try{
      const r=await fetch('/api/recommendations/status',{headers:headers(),cache:'no-store'});
      const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(typeof d.detail==='string'?d.detail:`조회 실패 HTTP ${r.status}`);
      const chosen=$('recommendSource')?.value||'auto';
      const isReady=chosen==='fsc'?d.fsc_configured:chosen==='krx'?d.krx_configured:(d.fsc_configured||d.krx_configured);
      if(!isReady){status('선택한 데이터 공급원의 인증키가 없습니다. 금융위원회 주식시세정보 활용신청 후 FSC_STOCK_API_KEY를 Render에 설정하세요.',true);$('recommendScan').disabled=true;return;}
      $('recommendScan').disabled=false;
      const requestedMarket=$('recommendMarket')?.value||'all';
      const selectedSource=chosen==='auto'?(d.fsc_configured?'fsc':'krx'):chosen;
      if(d.source&&d.source!==selectedSource){stopPoll();status('이전 검색은 다른 데이터 공급원으로 실행됐습니다. 현재 선택한 공급원으로 새 검색을 실행하세요.');return;}
      if(d.market&&d.market!==requestedMarket){stopPoll();status('이전 검색은 다른 시장을 대상으로 했습니다. 현재 선택한 시장으로 다시 검색하세요.');return;}
      if(d.status==='running'){
        status(d.progress?.message||'KRX 전 종목 및 심층 후보를 검색 중입니다…');startPoll();return;
      }
      stopPoll();
      if(d.status==='failed'){status(`검색 실패: ${d.error?.message||'공급원 오류'}`,true);return;}
      if(d.status==='complete'&&d.result){
        status(`마지막 검색 완료 · ${d.result.data_date} 기준 · ${d.result.recommended_count}개 매수 후보 · ${d.result.data_source||'일별'} · 실시간 아님`);
        render(d.result);return;
      }
      status(`데이터 공급원 연결 준비 · ${chosen==='auto'?'금융위원회 우선 자동 선택':chosen==='fsc'?'금융위원회 T+1':'KRX 일별'} · 검색 시 과거 기준일을 확인하세요.`);
    }catch(e){status(e.message||'검색 상태 확인 실패',true);}finally{busy=false;}
  }
  async function scan(){
    if(preview)return;
    $('recommendScan').disabled=true;
    status('선택한 데이터 공급원의 일별 시세를 확인하고 있습니다. 앱을 열어 둔 채 결과를 확인하세요.');
    try{
      const r=await fetch('/api/recommendations/run',{method:'POST',headers:{...headers(),'Content-Type':'application/json'},body:JSON.stringify({market:$('recommendMarket').value,source:$('recommendSource')?.value||'auto'}),cache:'no-store'});
      const d=await r.json().catch(()=>({}));
      if(!r.ok){const detail=d.detail;throw new Error(typeof detail==='string'?detail:(detail?.message||`HTTP ${r.status}`));}
      status(d.progress?.message||'전체 시장 검색을 시작했습니다.');startPoll();
    }catch(e){status(e.message||'검색을 시작할 수 없습니다.',true);$('recommendScan').disabled=false;}
  }
  async function diagnose(){
    const btn=$('recommendDiagnose'),out=$('recommendDiagnosis');
    if(!btn||!out)return;
    if(preview){out.hidden=false;out.textContent='체험판에서는 실제 KRX 연결을 진단하지 않습니다.';return;}
    btn.disabled=true;out.hidden=false;out.replaceChildren();out.textContent='KRX 운영 API를 코스피·코스닥별로 확인 중입니다…';
    try{
      const resp=await fetch('/api/recommendations/diagnose',{method:'POST',headers:headers(),cache:'no-store'});
      const d=await resp.json().catch(()=>({}));
      if(!resp.ok)throw new Error(typeof d.detail==='string'?d.detail:`진단 요청 실패 HTTP ${resp.status}`);
      out.replaceChildren();
      const top=document.createElement('p');top.textContent=`운영 API 진단 기준일: ${d.date||'미설정'} · 인증키: ${d.configured?'서버에 설정됨':'미설정'}`;out.append(top);
      for(const item of d.results||[]){
        const itemNode=document.createElement('p');
        const m=item.market==='kospi'?'코스피':'코스닥';
        const statusLabel=item.state==='success'?'정상 수신':item.state==='no_data'?'자료 없음':item.state==='auth_denied'?'인증/권한 실패':'연결 실패';
        const count=item.record_count!=null?` · 종목 ${item.record_count}건`:'';
        itemNode.textContent=`${m} (${item.api_id||'서비스'}): ${statusLabel} · HTTP ${item.http_status??'미확인'} · KRX 코드 ${item.krx_code??'없음'}${count} · ${item.detail||'원인 미확인'}`;
        out.append(itemNode);
      }
      const note=document.createElement('small');note.textContent='요청: 운영 API · GET · AUTH_KEY 헤더 전송(값 비공개). 인증 오류면 Render 개인 키 및 두 서비스 이용 승인을 확인하세요. 샘플 API 성공만으로 운영 인증은 확인되지 않습니다.';out.append(note);
    }catch(err){out.textContent=err.message||'진단을 수행할 수 없습니다.';}
    finally{btn.disabled=false;}
  }
  function stopPoll(){if(timer){clearInterval(timer);timer=null;}}
  function startPoll(){if(timer)return;timer=setInterval(()=>{if(viewOpen())fetchState();else if(document.hidden)stopPoll();},4500);}
  function onViewChange(next){
    if(next!=='recommendations'){stopPoll();return;}
    fetchState();
  }
  function init(){
    if(!$('recommendScan'))return;
    $('recommendScan').onclick=scan;
    const diag=$('recommendDiagnose');if(diag)diag.onclick=diagnose;
    const source=$('recommendSource');if(source)source.onchange=()=>{const n=$('recommendNumbers');if(n)n.hidden=true;$('recommendResults').replaceChildren();fetchState();};
    $('recommendMarket').onchange=()=>{const n=$('recommendNumbers');if(n)n.hidden=true;$('recommendResults').replaceChildren();status('검색 범위를 변경했습니다. ‘전체 시장 검색 시작’을 누르세요.');};
    document.addEventListener('visibilitychange',()=>{if(document.hidden)stopPoll();else if(viewOpen())fetchState();});
  }
  window.NOVAScanner={onViewChange,load:fetchState};
  window.addEventListener('DOMContentLoaded',init);
})();
