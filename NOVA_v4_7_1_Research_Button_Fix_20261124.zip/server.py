"""NOVA v3 mobile PWA API: read-only, no trading endpoints and no broker order capability.
Start locally with `python server.py`; see README for LAN/public access.
"""
from __future__ import annotations

import hmac
import logging
import hashlib
import secrets
import re
import math
import os
from pathlib import Path
import threading
import time
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from zoneinfo import ZoneInfo

import pandas as pd
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from engine import Config, feature_frame, decide
from structural_risk import evidence_from_features, reprice_from_evidence
from backtest import run_backtest
from data_sources import demo_data, yahoo_data, kis_data, ticker_format, market_zone
from stock_lookup import search_stocks
from dart_financial import DARTError, get_client
from finance_gate import assess_financial
from signal_policy import resolve_final_signal
from signal_journal import evaluate_batch
from evidence_store import backend as evidence_backend, append_analysis, count_snapshots, list_snapshots
from market_sessions import krx_session
from completed_session import completed_swing_bars
from paper_lab import simulate_paper
from auto_evidence import (store_scan as store_auto_scan, evaluate_pending as evaluate_auto_pending,
                           report as auto_evidence_report, status as auto_evidence_status,
                           evaluate_server_observations as evaluate_auto_observed,
                           record_auto_attempt)
from news_sources import fetch_news, NewsUnavailable
from signal_quality import quality_gate
from high_precision_adoption import observe_high_precision
from shadow_context import build_shadow_inputs, fetch_yahoo_reference
from quality_validation import quality_comparison
from signal_stats import signal_performance
from higher_timeframes import PERIODS, chart_data, fetch_long_daily, fetch_kis_native_period, latest_kis_period
from trend_context import summarize_higher_trends
from market_scanner import run_market_scan, MarketScanError, diagnose_connection, completed_dates
from scan_freshness import assess_scan_sessions
from public_market_data import FSCStockClient
from recommendation_backtest import run_screen_history
from investor_flow import stock_code, get_flows, get_quote, get_intraday
from naver_investor import get_naver_flows, NaverFlowError
from popular_stocks import fetch_popularity
from regime_research import capture_market_context, regime_report

KIS_CHART_LOG = logging.getLogger('nova.kis.chart')
BASE = Path(__file__).resolve().parent
ASSETS = BASE / 'static'
app = FastAPI(title='NOVA AI Trading Mobile', docs_url=None, redoc_url=None, openapi_url=None)
app.mount('/static', StaticFiles(directory=ASSETS), name='static')
CACHE_LOCK = threading.Lock()
# Fixed-size lock stripes coalesce identical concurrent provider downloads
# without serializing all symbols under the global cache lock.
CACHE_KEY_LOCKS = [threading.Lock() for _ in range(64)]
CACHE = {}
RATE = {}
CACHE_TTL = 52
FIN_CACHE_TTL = 6 * 3600
JOURNAL_CACHE_LOCK = threading.Lock()
JOURNAL_FRAMES = {}
JOURNAL_CACHE_TTL = 12 * 60
WATCH_CACHE_TTL = 90
MAX_CACHE = 72
KST = ZoneInfo('Asia/Seoul')
SCAN_LOCK = threading.RLock()
SCAN_STATE = {'status':'idle','progress':{},'result':None,'error':None,'started_monotonic':None,'market':'all'}
SCAN_JOB = None
BACKTEST_LOCK = threading.RLock()
BACKTEST_STATE = {'status':'idle','result':None,'error':None,'progress':{},'market':'all','weeks':4}
BACKTEST_JOB = None
POPULAR_LOCK = threading.RLock()
POPULAR_STATE = {'status':'idle','source':None,'result':None,'error':None}
POPULAR_JOB = None
AUTO_LOCK = threading.RLock()
AUTO_JOB = None
AUTO_STATE = {'status':'idle','started_at':None,'completed_at':None,'error_code':None,'result':None}
LABEL = {'BUY':'매수 후보', 'SELL':'매도·보유분 축소 검토', 'HOLD':'관망'}
MODES = {'1분','5분','15분','스윙'}
SOURCES = {'yahoo','kis','demo','auto'}
AUTH_COOKIE = 'nova3_auth'
REMEMBER_SECONDS = 30 * 24 * 3600
SESSION_SECONDS = 12 * 3600

if os.environ.get('NOVA_PUBLIC_DEPLOY') == '1' and len(os.environ.get('NOVA_ACCESS_TOKEN','')) < 16:
    raise RuntimeError('공개 서버 배포시 NOVA_ACCESS_TOKEN을 16자 이상으로 설정하세요.')


def _cookie_key(token: str) -> bytes:
    # Server-only key. Changing NOVA_ACCESS_TOKEN invalidates all remembered devices.
    return hashlib.sha256(('nova3-cookie:v1:' + token).encode('utf-8')).digest()


def _cookie_valid(value: str, token: str) -> bool:
    if not value or not token:
        return False
    try:
        version, expiry, nonce, signature = value.split('.')
        if version != 'v1' or not expiry.isdecimal() or len(nonce) != 32 or len(signature) != 64:
            return False
        if not all(ch in '0123456789abcdef' for ch in nonce + signature):
            return False
        exp = int(expiry)
        now = int(time.time())
        if not now < exp <= now + REMEMBER_SECONDS:
            return False
        message = f'{version}.{expiry}.{nonce}'
        expected = hmac.new(_cookie_key(token), message.encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, signature)
    except (ValueError, TypeError):
        return False


def _is_authenticated(request: Request) -> bool:
    token = os.environ.get('NOVA_ACCESS_TOKEN', '')
    if not token:
        return True
    supplied = request.headers.get('Authorization', '')
    if supplied and hmac.compare_digest(supplied, 'Bearer ' + token):
        return True
    return _cookie_valid(request.cookies.get(AUTH_COOKIE, ''), token)


def _authorize(request: Request):
    if not _is_authenticated(request):
        raise HTTPException(401, '인증이 만료됐습니다. 설정에서 서버 접근 토큰을 입력하세요.')


def _secure_cookie(request: Request) -> bool:
    # Render sets NOVA_PUBLIC_DEPLOY=1. Local HTTP development continues to work.
    return os.environ.get('NOVA_PUBLIC_DEPLOY') == '1' or request.url.scheme == 'https'


@app.get('/api/auth/status')
def auth_status(request: Request):
    return JSONResponse({'authenticated': _is_authenticated(request),
                         'token_required': bool(os.environ.get('NOVA_ACCESS_TOKEN'))},
                        headers={'Cache-Control': 'no-store'})


@app.post('/api/auth/login')
def auth_login(request: Request, body: dict):
    _limit(request)
    expected = os.environ.get('NOVA_ACCESS_TOKEN', '')
    supplied = body.get('token', '')
    remember = body.get('remember') is True
    if not isinstance(supplied, str) or len(supplied) > 1024:
        raise HTTPException(400, '올바르지 않은 토큰 형식입니다.')
    if expected and not hmac.compare_digest(supplied, expected):
        raise HTTPException(401, '서버 접근 토큰이 일치하지 않습니다.')
    response = JSONResponse({'authenticated': True, 'remembered': remember, 'days': 30 if remember else 0},
                            headers={'Cache-Control': 'no-store'})
    if expected:
        duration = REMEMBER_SECONDS if remember else SESSION_SECONDS
        expiry = str(int(time.time()) + duration)
        message = f'v1.{expiry}.{secrets.token_hex(16)}'
        signature = hmac.new(_cookie_key(expected), message.encode(), hashlib.sha256).hexdigest()
        response.set_cookie(AUTH_COOKIE, message + '.' + signature,
                            max_age=duration if remember else None,
                            httponly=True, secure=_secure_cookie(request),
                            samesite='lax', path='/')
    return response


@app.post('/api/auth/logout')
def auth_logout(request: Request):
    response = JSONResponse({'authenticated': False}, headers={'Cache-Control':'no-store'})
    response.delete_cookie(AUTH_COOKIE, path='/', secure=_secure_cookie(request), httponly=True, samesite='lax')
    return response


def _limit(request: Request):
    ip = request.client.host if request.client else 'unknown'
    now = time.monotonic()
    with CACHE_LOCK:
        ts = [x for x in RATE.get(ip,[]) if now-x < 60]
        if len(ts) >= 24:
            raise HTTPException(429, '요청이 너무 많습니다. 60초 후 다시 조회하세요.', headers={'Retry-After': '60'})
        ts.append(now)
        RATE[ip] = ts
        if len(RATE)>500:
            RATE.clear()


def _cached(key, make, ttl=CACHE_TTL):
    # Double-check under a per-key stripe: concurrent requests for the same
    # symbol should not simultaneously hit Yahoo/Naver/KIS quota limits.
    now = time.monotonic()
    with CACHE_LOCK:
        entry = CACHE.get(key)
        if entry and now-entry[0] <= ttl:
            return dict(entry[1], cached=True, cache_age_seconds=round(now-entry[0]))
    with CACHE_KEY_LOCKS[hash(key) % len(CACHE_KEY_LOCKS)]:
        now = time.monotonic()
        with CACHE_LOCK:
            entry = CACHE.get(key)
            if entry and now-entry[0] <= ttl:
                return dict(entry[1], cached=True, cache_age_seconds=round(now-entry[0]))
        # No fabricated fallback: a failed provider fetch remains an error.
        result = make()
        with CACHE_LOCK:
            if len(CACHE)>=MAX_CACHE:
                CACHE.clear()
            CACHE[key]=(time.monotonic(),result)
        return dict(result,cached=False,cache_age_seconds=0)


def _safe_float(n):
    try:
        v=float(n)
        return round(v,6) if math.isfinite(v) else None
    except (ValueError,TypeError):return None


def _last_age_minutes(bar:pd.Timestamp, ticker:str, mode:str)->float|None:
    try:
        stamp = pd.Timestamp(bar)
        if stamp.tzinfo is None:
            stamp=stamp.tz_localize(market_zone(ticker))
        if mode=='1분':stamp+=pd.Timedelta(minutes=1)
        elif mode=='5분':stamp+=pd.Timedelta(minutes=5)
        elif mode=='15분':stamp+=pd.Timedelta(minutes=15)
        else:stamp+=pd.Timedelta(hours=16 if market_zone(ticker).key=='America/New_York' else 15,minutes=30 if market_zone(ticker).key=='Asia/Seoul' else 0)
        return max(0,round((pd.Timestamp.now(tz='UTC')-stamp.tz_convert('UTC')).total_seconds()/60,1))
    except Exception: return None



def _get_financial_state(symbol: str, mode: str) -> tuple[str, str, int | None]:
    """Consistent DART assessment for both individual and watchlist signals.

    DART is a best-effort overlay. A missing/failed response MUST never
    promote a domestic swing BUY. We do not leak credentials or provider URLs.
    """
    if mode != '스윙':
        return 'NOT_APPLIED', '단타는 재무 필터를 적용하지 않습니다.', None
    if not symbol.endswith(('.KS', '.KQ')):
        return 'NOT_SUPPORTED', 'OpenDART 미지원 해외 종목입니다.', None
    try:
        client = get_client()
        fp = hashlib.sha256(client.key.encode()).hexdigest()[:12]
        overview = _cached(('dart', fp, symbol, 3),
                           lambda: client.overview(symbol, years=3), ttl=FIN_CACHE_TTL)
        gate = assess_financial(overview)
        return gate['gate'], gate['reason'], gate['as_of_annual_year']
    except Exception:
        # Never expose provider details, API key or auth headers in a response.
        return 'UNKNOWN', 'OpenDART 재무정보 미확인: 검증할 수 없습니다.', None



def _payload(symbol:str,mode:str,source:str,cost_bps:int,asof_date:str|None=None)->dict:
    cfg = Config.for_mode(mode, cost_bps)
    resolved_source=source
    fallback_reason=None
    if source=='demo':
        market=demo_data(mode)
    elif source=='yahoo':
        market=yahoo_data(symbol,mode)
    elif source=='auto':
        # Automatic selection is opt-in from the app settings; it must NOT be
        # used for historic as-of FSC/KRX recommendation scans.
        if asof_date is not None:
            raise ValueError('과거 기준일 분석에는 명시적 Yahoo 공급원이 필요합니다.')
        if mode!='스윙':
            market=yahoo_data(symbol,mode)
            resolved_source='yahoo'
            fallback_reason='단타 자동 선택은 기존 Yahoo 분석을 유지합니다.'
        else:
            key=os.environ.get('KIS_APP_KEY','').strip()
            secret=os.environ.get('KIS_APP_SECRET','').strip()
            try:
                if not key or not secret:
                    raise ValueError('KIS_NOT_CONFIGURED')
                market=kis_data(symbol,mode,key,secret)
                resolved_source='kis'
            except Exception:
                # Do not leak credentials or broker error messages. A Yahoo
                # fallback is still subject to the completed-session staleness
                # gate, so last Friday is not considered fresh after Monday EOD.
                market=yahoo_data(symbol,mode)
                resolved_source='yahoo'
                fallback_reason='KIS 조회를 사용할 수 없어 Yahoo 완료봉으로 대체했습니다. 최신 거래일 확인이 필요합니다.'
    elif source=='kis':
        key=os.environ.get('KIS_APP_KEY','')
        secret=os.environ.get('KIS_APP_SECRET','')
        if not key.strip() or not secret.strip():
            raise ValueError('KIS 연결을 위해 서버 환경변수 KIS_APP_KEY 및 KIS_APP_SECRET이 필요합니다.')
        market=kis_data(symbol,mode,key,secret)
    else:
        raise ValueError('지원하지 않는 시세 공급원입니다.')
    scan_freshness=None
    if asof_date is not None:
        # Compare actual provider sessions BEFORE removing future bars. Historical
        # publication lag must never be mistaken for today's live-price freshness.
        scan_freshness=assess_scan_sessions(market.bars.index,asof_date)
        # FSC T+1 / KRX snapshot alignment. Recompute ALL indicators, backtests
        # and signals after dropping future bars; don't just relabel a current signal.
        if mode!='스윙' or source!='yahoo' or not re.fullmatch(r'\d{8}',asof_date):
            raise ValueError('일별 공식 시세의 완료봉 기준일이 잘못되었습니다.')
        historical=market.bars.loc[[str(pd.Timestamp(t).date()).replace('-','')<=asof_date for t in market.bars.index]].copy()
        if len(historical)<110:
            raise ValueError('시장 기준일에 맞는 과거 완료봉이 충분하지 않습니다.')
        if str(pd.Timestamp(historical.index[-1]).date()).replace('-','')!=asof_date:
            raise ValueError('Yahoo 완료봉과 공식 스냅샷 기준일이 일치하지 않습니다.')
        market.bars=historical
        market.quote=None  # The live quote is later than the as-of snapshot.
        market.quote_time=''  # Never label today's quote as historical.
        market.note=str(market.note or '') + ' · 공식 일별 기준일로 과거 완료봉 재계산'
    completed_session=None
    if mode=='스윙' and not market.synthetic and asof_date is None:
        # Strip any still-open daily bar *before* indicators/backtests/signals.
        # This also respects KRX's special session close (e.g. 16:30 exam day).
        market.bars, completed_session = completed_swing_bars(market.bars)
        if len(market.bars)<65:
            raise ValueError('확정 거래일 기준 완료봉이 65개 미만입니다. 분석을 보류합니다.')
    f=feature_frame(market.bars,mode)
    higher_trend = (summarize_higher_trends(market.bars, '005930.KS' if market.synthetic else market.symbol, now=datetime.now(KST), historical=asof_date is not None)
                    if mode == '스윙' else None)
    d=decide(f,cfg)
    bt=run_backtest(market.bars,cfg)
    q=quality_gate(f,cfg,raw_signal=d.signal)
    compared=quality_comparison(f,cfg)
    signal_stats=signal_performance(f,cfg)
    age=_last_age_minutes(f.index[-1],market.symbol if not market.synthetic else '005930.KS',mode)
    fresh_limit={'1분':8, '5분':25, '15분':55, '스윙':3*24*60}[mode]
    live_price_stale = False if market.synthetic else age is None or age > fresh_limit
    # A market-wide as-of scan compares completed historical sessions; do NOT
    # apply a 72-hour wall clock to an older Friday snapshot on Monday.
    # Live swing analysis uses completed KRX sessions; intraday remains wall-clock based.
    stale = (bool(scan_freshness['stale']) if scan_freshness is not None
             else bool(completed_session['stale']) if completed_session is not None
             else live_price_stale)
    fgate, fnote, fyear = _get_financial_state(market.symbol, mode) if not market.synthetic else ('NOT_APPLIED', '가상 데이터', None)
    policy = resolve_final_signal(q['strict_signal'], mode=mode, symbol=market.symbol,
                                  financial_gate=fgate, finance_reason=fnote,
                                  stale=stale, is_demo=market.synthetic)
    # Live-observed reference context for read-only research only.  A past
    # market-scan date NEVER loads today's source data for historic decisions.
    # References are cached individually; even a provider outage may not change
    # the existing actionable BUY/SELL or prevent the original analysis.
    research_context = {'benchmark': None, 'sector': None, 'flows': None, 'diagnostics': {}}
    try:
        if mode == '스윙' and market.symbol.endswith(('.KS','.KQ')) and not market.synthetic:
            def cached_ref(ticker):
                return _cached(('research_ref_20261112',ticker),
                               lambda: {'frame':fetch_yahoo_reference(ticker)}, ttl=900)['frame']
            def cached_flow(code):
                # Reuse exactly the KIS/Naver result already fetched in the
                # dedicated investor-flow tab.  Do not trigger slow, repeated
                # unofficial scraping from the stock-analysis endpoint.
                with CACHE_LOCK:
                    c=CACHE.get(('v46_flow_per_investor_20261112',code))
                    return c[1] if c and time.monotonic()-c[0]<=600 else None
            research_context=build_shadow_inputs(market.symbol,now=datetime.now(KST),
                            ref_loader=cached_ref,flow_loader=cached_flow,
                            historical_asof=asof_date)
    except Exception:
        research_context['diagnostics']={'overall':{'status':'UNAVAILABLE',
               'detail':'연구 자료 조회 실패 (기존 매수 판단 영향 없음)'}}
    try:
        hp = observe_high_precision(features=f, cfg=cfg, symbol=market.symbol,
                                    mode=mode, is_demo=market.synthetic, is_stale=stale,
                                    financial_gate=fgate, decision_at=datetime.now(KST),
                                    benchmark=research_context.get('benchmark'),
                                    sector=research_context.get('sector'),
                                    flows=research_context.get('flows'))
        hp['context_data']=research_context['diagnostics']
    except Exception:
        # Research overlay must never interrupt the legacy analysis response.
        hp = {'adoption_mode':'SHADOW_ONLY', 'state':'RESEARCH_ERROR',
              'display':'고정밀 연구 오류 · 기존 신호는 유지',
              'baseline_signal_modified':False, 'live_orders_approved':False,
              'performance_advantage_verified':False, 'checks':[], 'reasons':['연구 관찰 처리 오류'],
              'disclaimer':'연구 관찰 전용 · 실제 주문 신호가 아닙니다.'}
    risk_structure = reprice_from_evidence(evidence_from_features(f, cfg), cost_bps=cost_bps, demo=market.synthetic, stale=stale)
    chart=f.iloc[-125:][['Open','High','Low','Close','Volume','ema20','ema50']]
    times=[x.isoformat() for x in chart.index]
    # Note: role #13 is a risk veto; it is NOT one of the 12 counted directional votes.
    return {
        'symbol': market.symbol,
        'mode':mode,'source':resolved_source,'requested_source':source,
        'source_fallback_reason':fallback_reason,'provider':market.provider,
        'is_demo':market.synthetic, 'is_stale':stale,
        'price_age_minutes':age, 'live_price_stale':live_price_stale,
        'scan_freshness':scan_freshness, 'completed_session':completed_session,
        'asof_evaluation_only':asof_date is not None,
        'fetched_at':market.retrieved_at,
        'quote_time':market.quote_time,'last_completed_bar':d.time,
        'freshness':market.freshness,
        'provider_note':market.note+((' · '+fallback_reason) if fallback_reason else ''),
        'currency':market.currency,
        'quote':_safe_float(market.quote),'reference':_safe_float(d.reference),
        'signal':policy['final_signal'],
        'signal_label':('관망 · 지난 완료봉' if stale else LABEL[policy['final_signal']]),
        'strict_signal':q['strict_signal'],
        'raw_signal':d.signal,'quality_gate':q,'quality_comparison':compared,
        'signal_performance':signal_stats,
        'higher_timeframe_context':higher_trend,
        'high_precision_research':hp,
        'signal_is_current':policy['signal_is_current'],
        'final_actionable_signal':policy['final_actionable_signal'],
        'historical_signal':policy['historical_signal'],
        'final_reason':policy['final_reason'],
        'financial_gate':fgate, 'finance_note':fnote,
        'financial_asof_year':fyear,
        'rsi':_safe_float(d.rsi),
        'atr':_safe_float(d.atr),
        'buy_votes':d.buy_votes,'sell_votes':d.sell_votes,'hold_votes':d.hold_votes,
        'risk_veto':d.risk_veto,'risk_message':d.risk_message,
        'long_stop_reference':_safe_float(d.stop),
        'long_target_reference':_safe_float(d.target),
        'long_risk_reward':_safe_float(d.risk_reward),
        'risk_structure':risk_structure,
        'cost_bps_one_side':cost_bps,
        'max_hold_bars':cfg.max_hold_bars,
        'backtest_exit_policy':'종료봉 종가에서 전략과 매수보유 모두 가상청산(편도 수수료 적용)',
        'votes':[{'role':x.role,'direction':x.direction,'label':x.label,'reason':x.reason,'category':x.category} for x in d.votes],
        'chart':{'dates':times,
                 'open':[_safe_float(x) for x in chart['Open']],
                 'high':[_safe_float(x) for x in chart['High']],
                 'low':[_safe_float(x) for x in chart['Low']],
                 'volume':[_safe_float(x) for x in chart['Volume']],
                 'close':[_safe_float(x) for x in chart['Close']],
                 'ema20':[_safe_float(x) for x in chart['ema20']],
                 'ema50':[_safe_float(x) for x in chart['ema50']]},
        'backtest':{
            'total_return_pct':_safe_float(bt.total_return*100),
            'benchmark_return_pct':_safe_float(bt.benchmark_return*100),
            'max_drawdown_pct':_safe_float(bt.max_drawdown*100),
            'closed_trades':bt.closed_trades,
            'win_rate_pct':_safe_float(bt.win_rate*100 if bt.win_rate is not None else None),
            'directional_hit_rate_pct':_safe_float(bt.directional_hit_rate*100 if bt.directional_hit_rate is not None else None),
            'directional_samples':bt.directional_samples,
            'last_20pct_rate_pct':_safe_float(bt.latest_20pct_hit_rate*100 if bt.latest_20pct_hit_rate is not None else None),
            'last_20pct_samples':bt.latest_20pct_samples,
            'buy_signals':bt.buy_signals,'sell_signals':bt.sell_signals,
            'curve':{'dates':[str(i) for i in bt.curve.index[::max(1,len(bt.curve)//90)]],
                      'strategy':[_safe_float(v) for v in bt.curve['전략 자산'].iloc[::max(1,len(bt.curve)//90)]],
                      'benchmark':[_safe_float(v) for v in bt.curve['비교 매수보유'].iloc[::max(1,len(bt.curve)//90)]]},
            'recent_trades':[
                {'entry':str(x['진입시점']),'exit':str(x['청산시점']),
                 'pnl_pct':_safe_float(x['수익률']*100),'reason':str(x['청산사유'])}
                for x in bt.trades.tail(8).iloc[::-1].to_dict('records')],
        },
        'disclaimer':'규칙 기반 분석이며 미래 수익률을 예측·보장하지 않습니다. 마지막 완료봉에 근거하며 매도는 보유분 축소 의견입니다.',
    }


@app.get('/')
def index():
    return FileResponse(ASSETS/'index.html',headers={'Cache-Control':'no-cache'})

@app.get('/favicon.ico')
def favicon():
    # Some browsers request the legacy path even when a PNG icon link exists.
    return FileResponse(ASSETS/'icons/icon-192.png',media_type='image/png',headers={'Cache-Control':'public, max-age=86400'})

@app.get('/manifest.webmanifest')
def manifest():
    return FileResponse(ASSETS/'manifest.webmanifest',media_type='application/manifest+json')

@app.get('/sw.js')
def service_worker():
    return FileResponse(ASSETS/'sw.js',media_type='application/javascript',headers={'Cache-Control':'no-store','Service-Worker-Allowed':'/'})

@app.get('/healthz')
def healthz():
    return {'status':'ok','orders_enabled':False,'app_version':'4.7.1','analysis_modes':['1분','5분','15분','스윙'],'higher_trend_context_research_only':True,'release_tag':'4.5-stability-20261112','feature_tag':'4.5-domestic-only-20261112','scan_freshness_tag':'4.5-session-aware-rejection-20261112','flow_history_tag':'4.5-nav-flow-per-investor-20261112','stock_name_search':True,'dart_feature':True,'financial_risk_filter':True,'historical_fundamental_backtest':False,'forward_signal_journal':True,'evidence_lab_version':'4.7.0-auto-research','persistent_server_journal':evidence_backend()!='disabled','watchlist_visible_tab_only':True,'push_notifications':False,'strict_signal_quality':True,'quality_hit_rate_verified':False,'final_signal_policy':'financial-then-notification','intraday_journal_verified':False,'candlestick_chart':True,'stock_news':True,'news_affects_signal':False,'signal_role_statistics':True,'calibrated_buy_probability':False,'higher_timeframe_charts':True,'higher_timeframes_affect_signal':False,'market_recommendations':True,'nasdaq_search':False,'nasdaq_watchlist_scan':False,'us_tickers_enabled':False,'korean_market_only':True,'market_scope_tag':'4.5-domestic-only-20261112','domestic_interest_candidates':True,'market_scan_requires_krx_api':False,'market_scan_fsc_tplus1':True,'realtime_market_scan':False,'server_persistent_scan_results':evidence_backend()!='disabled','historical_market_screen_backtest':True,'full_recommendation_strategy_backtested':False,'high_precision_adoption_mode':'SHADOW_ONLY','high_precision_live_validated':False,'shadow_context_tag':'4.5-yahoo-index-etf-proxy-cached-share-flow-20261112','investor_flows_daily':True,'investor_flows_naver_fallback':True,'structure_levels_research_only':True,'krx_market_calendar':'XKRX_with_verified_special_hours','quote_rest_polling':True,'realtime_quote_websocket':False,'kis_period_rest_polling':True,'kis_period_native_ohlcv':True,'auto_swing_kis_first':True,'completed_session_freshness':True,'kis_period_refresh_seconds':20,'domestic_activity_top20':True,'naver_popular_official_link_only':True,'recommendation_breadth':'24-48-60','market_regime_research':'observed_only_shadow_v47','market_regime_live_adoption':False,'strict_buy_policy_unchanged':True,'investor_flow_research_only':True,'recommendation_ui_release':'2026-11-20-status-rank-cachefix'}

@app.get('/api/status')
def status(request:Request):
    _authorize(request)
    return {'kis_configured':bool(os.environ.get('KIS_APP_KEY') and os.environ.get('KIS_APP_SECRET')),
            'dart_configured':len(os.environ.get('OPENDART_API_KEY','').strip())==40,
            'news_provider_configured':bool(os.environ.get('NAVER_NEWS_CLIENT_ID') and os.environ.get('NAVER_NEWS_CLIENT_SECRET')),
            'news_provider_fallback':'google_news_rss',
            'krx_configured':bool(os.environ.get('KRX_API_KEY','').strip()),
            'fsc_configured':bool(os.environ.get('FSC_STOCK_API_KEY','').strip()),
            'marketwide_scanner':'금융위원회 주식시세 T+1 우선, KRX 선택 지원',
            'server_time_utc':datetime.now(timezone.utc).isoformat(timespec='seconds'),
            'release_tag':'4.5-domestic-only-20261112',
            'quote_provider':'KIS_ONLY', 'quote_requires_kis_credentials':True,
            'investor_flow_provider':'KIS_THEN_NAVER', 'kis_status':'CONFIGURED_NOT_VERIFIED' if (os.environ.get('KIS_APP_KEY','').strip() and os.environ.get('KIS_APP_SECRET','').strip()) else 'NOT_CONFIGURED',
            'yahoo_realtime_guaranteed':False,'streaming':False,'real_orders':False,
            'high_precision_adoption_mode':'SHADOW_ONLY','high_precision_live_validated':False,'investor_flow_enabled':True,'investor_flow_naver_public_fallback':True,'quote_snapshot_refresh_seconds':20,
            'lan_without_auth':os.environ.get('NOVA_BIND_HOST')=='0.0.0.0' and not bool(os.environ.get('NOVA_ACCESS_TOKEN'))}

# v4.5: read-only KIS investor flows and near-live REST quotation snapshots.
# They are not blended into the 1st-stage selection or historical backtest.
def _kis_creds():
    key, secret = os.environ.get('KIS_APP_KEY', '').strip(), os.environ.get('KIS_APP_SECRET', '').strip()
    if not key or not secret:
        raise HTTPException(503, 'KIS 앱 키가 미설정입니다. Render에 KIS_APP_KEY와 KIS_APP_SECRET을 설정하세요.')
    return key, secret

@app.get('/api/market/session')
def market_session(request: Request):
    """Regular KRX session only: read-only, never a trading permission."""
    _authorize(request)
    return JSONResponse(krx_session(), headers={'Cache-Control': 'no-store'})


@app.get('/api/market/flows')
def market_flows(request: Request, symbol: str = '005930'):
    _authorize(request)
    _limit(request)
    try: code = stock_code(symbol)
    except ValueError as exc: raise HTTPException(422, str(exc)) from None
    def resolve_flow():
        # Existing KIS is retained; public Naver only when KIS is absent,
        # failed or did not supply completed data. No trading signals modified.
        key = os.environ.get('KIS_APP_KEY', '').strip()
        secret = os.environ.get('KIS_APP_SECRET', '').strip()
        kis_problem = 'KIS 미설정'
        if key and secret:
            try:
                kis = get_flows(key, secret, code)
                has_quantities = any(
                    any(row.get(name) is not None for name in ('foreign', 'institution', 'individual'))
                    for row in kis.get('daily', []) if isinstance(row, dict)
                )
                if kis.get('has_data') and has_quantities:
                    kis['provider'] = 'kis'
                    kis['independent_source_verified'] = False
                    rows = kis.get('daily') or []
                    if len(rows) < 20 or any(not a.get('complete') for a in kis.get('aggregate',[]) if a.get('period')==20):
                        kis['history_expansion_status'] = (
                            f'KIS 완료 일별 {len(rows)}건: KIS 조회 성공으로 네이버 대체 조회를 실행하지 않음. '
                            '원천 20일 부족·필드 누락은 미확인입니다.')
                    return kis
                kis_problem = 'KIS 완료 거래일 자료 없음'
            except Exception:
                kis_problem = 'KIS 인증·권한 또는 응답 오류'
        try:
            naver = get_naver_flows(code)
            naver['fallback_reason'] = kis_problem
            return naver
        except NaverFlowError as exc:
            raise HTTPException(502, f'수급 자료 미확인: {kis_problem}; {exc}') from None
        except Exception:
            raise HTTPException(502, f'수급 자료 미확인: {kis_problem}; 네이버 조회 처리 오류') from None

    result = _cached(('v46_flow_per_investor_20261112', code), resolve_flow, ttl=300)
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})

@app.get('/api/market/intraday')
def market_intraday(request: Request, symbol: str = '005930'):
    _authorize(request)
    _limit(request)
    try: code = stock_code(symbol)
    except ValueError as exc: raise HTTPException(422, str(exc)) from None
    key, secret = _kis_creds()
    try:
        result = _cached(('v45_intraday', code, datetime.now(KST).date().isoformat()),
                         lambda: get_intraday(key, secret, code), ttl=75)
    except Exception:
        raise HTTPException(502, 'KIS 당일 분봉 수신 실패. 서버 API 및 장중 데이터 제공 여부를 확인하세요.') from None
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})

@app.get('/api/market/quote')
def market_quote(request: Request, symbol: str = '005930'):
    _authorize(request)
    _limit(request)
    try: code = stock_code(symbol)
    except ValueError as exc: raise HTTPException(422, str(exc)) from None
    key, secret = _kis_creds()
    try:
        result = _cached(('v45_quote', code), lambda: get_quote(key, secret, code), ttl=10)
    except Exception:
        raise HTTPException(502, 'KIS 현재가 수신 실패. API 사용 승인·시장 시간·네트워크를 확인하세요.') from None
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})

@app.get('/api/news')
def news_search(request: Request, symbol: str = '', name: str = ''):
    """Read-only stock news, explicitly not used by the trade signal engine."""
    _authorize(request)
    _limit(request)
    try:
        if not symbol and not name:
            raise ValueError('종목명 또는 종목코드를 입력하세요.')
        # Do not resolve decommissioned US tickers via the news entry point.
        if symbol and not re.fullmatch(r'\d{6}(?:\.(?:KS|KQ))?',symbol.strip().upper()):
            raise ValueError('뉴스 조회는 국내 코스피·코스닥 종목코드만 지원합니다.')
        # TTL avoids provider overuse and prevents accidental real-time claims.
        query_key=(symbol.strip().upper(),name.strip())
        result=_cached(('v39_news',query_key),
                       lambda:fetch_news(*query_key),ttl=600)
        return JSONResponse(result,headers={'Cache-Control':'no-store'})
    except ValueError as exc:
        raise HTTPException(422,str(exc)) from None
    except NewsUnavailable as exc:
        raise HTTPException(503,str(exc)) from None
    except Exception:
        raise HTTPException(502,'뉴스 수신 실패. 원문 검색 링크를 이용해 주세요.') from None


@app.get('/api/chart/history')
def long_chart(request: Request, symbol: str = '005930.KS', source: str = 'yahoo', timeframe: str = '1w'):
    """Dedicated chart-only aggregation; DOES NOT change NOVA's trading signals."""
    _authorize(request)
    _limit(request)
    if source not in SOURCES:raise HTTPException(422,'시세 공급원은 yahoo/kis/demo 중 선택하세요.')
    if timeframe not in PERIODS:raise HTTPException(422,'차트 주기는 일봉·주봉·월봉·연봉만 지원합니다.')
    if source=='demo':symbol='DEMO'
    else:
        try:symbol=ticker_format(symbol)
        except ValueError as exc:raise HTTPException(422,str(exc)) from None
    if source!='demo' and not symbol.endswith(('.KS','.KQ')):
        raise HTTPException(422,'국내 코스피·코스닥 종목만 차트 조회를 지원합니다.')
    if source == 'kis':
        _kis_creds()
        try:
            # Native D/W/M/Y bars provide several years of weekly/monthly/
            # yearly history, unlike the short swing-only KIS daily series.
            # _cached() is a JSON-like dict cache: if given a DataFrame
            # directly, it converts it to {column: Series}, breaking
            # chart_data() and producing HTTP 502 even with valid KIS bars.
            # Keep the DataFrame intact inside a dict envelope.
            cached_bars = _cached(('v45-kis-native-period-df-v2', symbol, timeframe),
                                  lambda: {'bars': fetch_kis_native_period(symbol, timeframe)}, ttl=900)
            bars = cached_bars['bars']
            result = chart_data(bars, timeframe, symbol, source)
            result['provider'] = 'KIS 기간별 시세(KRX)'
            result['polling_supported'] = True
            result['refresh_seconds'] = 20
            result['streaming'] = False
            result['note'] = 'KIS REST 기간별 OHLCV(15분 이내 캐시 가능). 장중 현재 봉은 별도 20초 조회로 갱신하며 체결 단위 실시간 스트림은 아닙니다. 분석·매매신호에는 미반영됩니다.'
            return JSONResponse(result, headers={'Cache-Control': 'no-store'})
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from None
        except Exception as exc:
            # Preserve only a broker error CODE, not msg1, headers or secrets.
            # Previous release masked every exception as the same 502 and made
            # the DataFrame/dict cache bug impossible to identify from logs.
            match = re.search(r'KIS 시세 오류 ([A-Za-z0-9_-]{1,30}):', str(exc))
            # Distinguish HTTP throttling/server failure from upstream network
            # and payload errors without exposing sensitive broker responses.
            safe_category = re.fullmatch(
                r'KIS_(?:HTTP_[0-9]{1,3}|UPSTREAM_(?:TIMEOUT|NETWORK)|BAD_(?:JSON|PAYLOAD)|RETRY_EXHAUSTED)',
                str(exc))
            safe_code = (match.group(1) if match else
                         safe_category.group(0) if safe_category else type(exc).__name__[:32])
            KIS_CHART_LOG.warning('KIS historical candle request failed: period=%s type=%s code=%s',
                                  timeframe, type(exc).__name__, safe_code)
            raise HTTPException(502, f'KIS 기간별 차트 조회 실패 [{safe_code}]. 인증·시세 조회 권한·호출 제한을 확인하세요.') from None
    try:
        # Expensive max-history download shared across W/M/Y chart selections.
        hist=_cached(('v41-daily-history',source,symbol),lambda:{'bars':fetch_long_daily(symbol,source)},ttl=1800)['bars']
        result=chart_data(hist,timeframe,symbol,source,synthetic=(source=='demo'))
        return JSONResponse(result,headers={'Cache-Control':'no-store'})
    except ValueError as exc:raise HTTPException(422,str(exc)) from None
    except Exception as exc:
        # Never return provider request headers, tokens or tracebacks.
        raise HTTPException(502,f'장기 차트 자료 조회 실패 ({type(exc).__name__}). 공급원·종목·네트워크를 확인하세요.') from None


@app.get('/api/chart/live')
def live_period_chart(request: Request, symbol: str = '005930.KS', timeframe: str = '1d'):
    # Read-only broker OHLCV snapshots; does not change trading signals.
    _authorize(request)
    _limit(request)
    if timeframe not in PERIODS:
        raise HTTPException(422, '차트 주기는 일봉·주봉·월봉·연봉만 지원합니다.')
    try:
        symbol = ticker_format(symbol)
        if not symbol.endswith(('.KS', '.KQ')):
            raise ValueError('국내 종목만 지원합니다.')
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    _kis_creds()
    try:
        result = _cached(('v45-kis-live-period', symbol, timeframe),
                         lambda: latest_kis_period(symbol, timeframe), ttl=12)
        return JSONResponse(result, headers={'Cache-Control': 'no-store'})
    except ValueError as exc:
        raise HTTPException(502, str(exc)) from None
    except Exception:
        raise HTTPException(502, 'KIS 장중 봉 조회 실패. 시세 공급원·조회 제한·장 운영 시간을 확인하세요.') from None

@app.get('/api/search')
def stock_search(request: Request, q: str = '', market: str = 'kr'):
    _authorize(request)
    _limit(request)
    if market!='kr':
        raise HTTPException(422,'한국 코스피·코스닥 종목 검색만 지원합니다.')
    if not 1 <= len(q.strip()) <= 40:
        raise HTTPException(422, '검색어를 1~40자로 입력하세요.')
    try:
        result = _cached(('stock_search', 'kr', q.strip().casefold()), lambda: search_stocks(q))
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    return JSONResponse(result, headers={'Cache-Control': 'no-store'})




@app.get('/api/fundamentals')
def fundamentals(request: Request, symbol: str, years: int = 3):
    """Read-only official OpenDART; no historical trading-signal look-ahead."""
    _authorize(request)
    _limit(request)
    try:
        symbol=ticker_format(symbol)
        client=get_client()
        # Cache key includes a fingerprint of the configured key, not the key itself.
        key_fingerprint=hashlib.sha256(client.key.encode()).hexdigest()[:12]
        result=_cached(('dart',key_fingerprint,symbol,years),
                       lambda:client.overview(symbol,years=years),ttl=FIN_CACHE_TTL)
        # Pure current-time overlay. Deliberately not inserted into historical OHLC backtests.
        body=dict(result)
        body['financial_gate']=assess_financial(body)
        return JSONResponse(body,headers={'Cache-Control':'no-store'})
    except DARTError as exc:
        code=exc.code
        status=503 if code in ('no_key','network','registry_network','020','012','800') else 422
        raise HTTPException(status, {'code':code,'message':str(exc)}) from None
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    except Exception:
        # Do not accidentally leak key via requests exception's URL in response.
        raise HTTPException(502, 'DART 재무정보 처리 실패. 서버 로그를 확인하세요.') from None



def _journal_daily_bars(symbol: str, source: str) -> pd.DataFrame:
    """Use finished daily candles; never cache an unfinished in-session bar."""
    key = (symbol, source)
    now = time.monotonic()
    with JOURNAL_CACHE_LOCK:
        cached = JOURNAL_FRAMES.get(key)
        if cached is not None and now - cached[0] <= JOURNAL_CACHE_TTL:
            return cached[1].copy()
    if source == 'yahoo':
        d = yahoo_data(symbol, '스윙').bars
    elif source == 'kis':
        key_id = os.environ.get('KIS_APP_KEY', '')
        secret = os.environ.get('KIS_APP_SECRET', '')
        if not key_id or not secret:
            raise ValueError('KIS API 키가 서버에 설정되지 않았습니다.')
        d = kis_data(symbol, '스윙', key_id, secret).bars
    else:
        raise ValueError('지원되지 않는 시세 공급원입니다.')
    with JOURNAL_CACHE_LOCK:
        if len(JOURNAL_FRAMES) >= 15:
            JOURNAL_FRAMES.clear()
        JOURNAL_FRAMES[key] = (time.monotonic(), d.copy())
    return d


@app.post('/api/journal/evaluate')
def journal_evaluate(request: Request, body: dict):
    """Evaluate browser-held snapshots, with no server-side journal persistence."""
    _authorize(request)
    _limit(request)
    try:
        return JSONResponse(evaluate_batch(body.get('records'), _journal_daily_bars),
                            headers={'Cache-Control': 'no-store'})
    except (TypeError, ValueError) as exc:
        raise HTTPException(422, str(exc)) from None



@app.get('/api/evidence/status')
def evidence_status(request: Request):
    _authorize(request)
    enabled = evidence_backend() != 'disabled'
    response = {'enabled': enabled, 'storage': evidence_backend() if enabled else 'browser_only',
                'total': 0, 'scope': '분석 API를 실제 조회한 순간의 스윙 BUY/SELL만 기록',
                'automatic_history_reconstruction': False,
                'note': ('DB 미설정 · 기존 기기 신호 기록만 유지됩니다. Render 무료 파일시스템은 영구 보관용이 아닙니다.'
                         if not enabled else '서버 기록은 최초 관찰 시점에 고정되며, 자동 주문은 수행하지 않습니다.')}
    if enabled:
        try:
            response['total'] = count_snapshots()
        except Exception:
            response['storage_error'] = True
            response['note'] = 'DB 연결 오류 · 신호 기록 보장 불가, 관리자가 저장소를 확인하세요.'
    return JSONResponse(response, headers={'Cache-Control':'no-store'})


@app.post('/api/evidence/report')
def evidence_report(request: Request, body: dict):
    """On-demand prospective outcomes and no-fill single-position paper research."""
    _authorize(request)
    _limit(request)
    if evidence_backend() == 'disabled':
        raise HTTPException(503, '영구 DB가 연결되지 않아 서버 실전관찰 성적표를 생성할 수 없습니다.')
    n=body.get('limit',60)
    if type(n) is not int or not 1 <= n <= 60:
        raise HTTPException(422, '최근 기록 조회 범위는 1~60건입니다.')
    try:
        all_rows=list_snapshots(limit=n)
        total=count_snapshots()
    except Exception:
        raise HTTPException(503, '신호 기록 DB를 조회하지 못했습니다.') from None
    if not all_rows:
        return JSONResponse({'count':0,'total':total,'status':'no_observations',
                             'note':'DB 연결 이후 실제 분석에서 관찰된 신호가 아직 없습니다. 과거 추천을 소급 생성하지 않습니다.'},
                            headers={'Cache-Control':'no-store'})
    # The same bounded source set is used for directional evidence and paper lab.
    keys=[];rows=[]
    for rec in all_rows:
        pair=(rec['symbol'],rec['source'])
        if pair not in keys:
            if len(keys)>=4:continue
            keys.append(pair)
        rows.append(rec)
    # Sort chronologically for non-overlapping paper trades.
    rows.sort(key=lambda r:(r['observed_at'],r['id']))
    try:
        assessed=evaluate_batch(rows,_journal_daily_bars)
        paper=simulate_paper(rows,_journal_daily_bars,hold_days=5)
    except Exception:
        raise HTTPException(502,'성적표 계산 실패 · 완료 일봉 및 데이터 공급원을 확인하세요.') from None
    horizons={}
    for horizon in (1,3,5,10):
        completed=[r['horizons'][str(horizon)] for r in assessed['results']
                   if r.get('horizons',{}).get(str(horizon),{}).get('status')=='complete']
        hits=sum(bool(r.get('direction_hit')) for r in completed)
        buy_net=[r['buy_net_pct'] for r in completed if isinstance(r.get('buy_net_pct'),(int,float))]
        horizons[str(horizon)]={'complete':len(completed),'pending_or_unavailable':len(rows)-len(completed),
             'direction_hit_pct':round(hits/len(completed)*100,1) if completed else None,
             'mean_buy_net_pct':round(sum(buy_net)/len(buy_net),3) if buy_net else None,
             'buy_sample':len(buy_net)}
    return JSONResponse({'count':len(rows),'requested':len(all_rows),'total':total,
      'excluded_by_four_source_limit':len(all_rows)-len(rows),
      'status':'partial' if total>len(rows) else 'observed',
      'horizons':horizons,'paper':paper,
      'note':'실제 조회 시 저장된 서버 관찰 표본만 대상으로 계산합니다. 사용자가 조회한 종목에 편중될 수 있으며, 과거 전체 종목의 최종 추천 성능이 아닙니다. 자동 주문·24시간 자동 수집 없음.'},
      headers={'Cache-Control':'no-store'})


# v3.6: bounded foreground watchlist scan. Does not register cron jobs or trade orders.
# A scan generates CURRENT rule-based signals; its output is NOT a backtested probability.
def _watch_item(symbol: str, mode: str, source: str, cost_bps: int) -> dict:
    key = ('v381-watch-item', source, symbol, mode, cost_bps)

    def calculate() -> dict:
        if source == 'yahoo':
            market = yahoo_data(symbol, mode)
        else:
            app_key, secret = os.environ.get('KIS_APP_KEY', ''), os.environ.get('KIS_APP_SECRET', '')
            if not (app_key and secret):
                raise ValueError('KIS 연동 키가 설정되지 않았습니다.')
            market = kis_data(symbol, mode, app_key, secret)
        features = feature_frame(market.bars, mode)
        cfg=Config.for_mode(mode, cost_bps)
        decision = decide(features, cfg)
        q=quality_gate(features,cfg,raw_signal=decision.signal)
        age = _last_age_minutes(features.index[-1], market.symbol, mode)
        stale_limit = 8 if mode == '1분' else 25 if mode == '5분' else 3 * 24 * 60
        is_stale = age is None or age > stale_limit
        result = {
            'symbol': market.symbol, 'mode': mode, 'source': source,
            'status': 'ok', 'technical': decision.signal,
            'combined': q['strict_signal'], 'financial_gate': 'NOT_APPLIED',
            'quality_gate': q,
            'finance_note': '단타에는 현재 재무 위험 필터를 적용하지 않습니다.',
            'reference': _safe_float(decision.reference), 'currency': market.currency,
            'stop': _safe_float(decision.stop), 'target': _safe_float(decision.target),
            'risk_reward': _safe_float(decision.risk_reward),
            'bar_time': decision.time, 'provider': market.provider,
            'fetched_at': market.retrieved_at,
            'price_age_minutes': age, 'is_stale': is_stale or bool(market.synthetic), 'is_demo': bool(market.synthetic),
            'freshness': market.freshness, 'provider_note': market.note,
            'risk_veto': decision.risk_veto,
            'note': '완료봉 기반 규칙형 신호. 실시간 시세 보장 및 주문 실행 없음.'
        }
        financial_gate, finance_note, financial_year = _get_financial_state(symbol, mode)
        policy = resolve_final_signal(q['strict_signal'], mode=mode, symbol=symbol,
                                      financial_gate=financial_gate,
                                      finance_reason=finance_note, stale=is_stale,
                                      is_demo=bool(market.synthetic))
        result['combined'] = policy['final_signal']
        result['historical_signal'] = policy['historical_signal']
        result['final_actionable_signal'] = policy['final_actionable_signal']
        result['signal_is_current'] = policy['signal_is_current']
        result['final_reason'] = policy['final_reason']
        result['financial_gate'] = financial_gate
        result['finance_note'] = finance_note
        result['financial_asof_year'] = financial_year
        return result

    return _cached(key, calculate, ttl=WATCH_CACHE_TTL)


@app.post('/api/watch/scan')
def watch_scan(request: Request, body: dict):
    """Read-only bounded batch, no disk persistence, no orders, no background task."""
    _authorize(request)
    _limit(request)
    symbols = body.get('symbols')
    modes = body.get('modes', ['5분', '스윙'])
    source = body.get('source', 'yahoo')
    cost_bps = body.get('cost_bps', 15)
    if not isinstance(symbols, list) or not 1 <= len(symbols) <= 5 or not all(isinstance(x, str) for x in symbols):
        raise HTTPException(422, '한 번에 1~5개 종목만 감시할 수 있습니다.')
    if not isinstance(modes, list) or not 1 <= len(modes) <= 2 or not all(isinstance(x,str) for x in modes) or len(set(modes)) != len(modes) or any(x not in MODES for x in modes):
        raise HTTPException(422, '분석 주기는 1분·5분·스윙 중 중복 없이 최대 2개를 선택하세요.')
    if source not in ('yahoo', 'kis'):
        raise HTTPException(422, '관심종목 감시는 Yahoo 또는 KIS 시세만 지원합니다.')
    if type(cost_bps) is not int or not 0 <= cost_bps <= 100:
        raise HTTPException(422, '거래비용은 편도 0~100bp로 지정하세요.')
    try:
        normalized = [ticker_format(x) for x in symbols]
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    if len(set(normalized)) != len(normalized):
        raise HTTPException(422, '중복 종목을 제거해 주세요.')
    if any(not s.endswith(('.KS', '.KQ')) for s in normalized):
        raise HTTPException(422, '관심종목 감시는 코스피·코스닥만 지원합니다.')
    tasks = [(symbol, mode) for symbol in normalized for mode in modes]
    rows = {}
    # Max 3 concurrent remote data calls for the small free Render instance.
    with ThreadPoolExecutor(max_workers=min(3, len(tasks))) as pool:
        futures = {pool.submit(_watch_item, s, m, source, cost_bps): (s, m) for s, m in tasks}
        for future in as_completed(futures):
            s, m = futures[future]
            try:
                rows[(s, m)] = future.result()
            except Exception as exc:
                # No provider URL or API credentials are included in client-facing errors.
                rows[(s, m)] = {'symbol': s, 'mode': m, 'source': source, 'status': 'error',
                                'error': f'시세 또는 재무자료 조회 실패 ({type(exc).__name__}).',
                                'is_stale': True, 'combined': None}
    results = [rows[key] for key in tasks]
    return JSONResponse({'status': 'ok', 'version': '3.8.1',
                         'scanned_at': datetime.now(timezone.utc).isoformat(timespec='seconds'),
                         'requested': len(tasks), 'successful': sum(x['status'] == 'ok' for x in results),
                         'results': results, 'polling': 'visible-tab-only', 'real_orders': False},
                        headers={'Cache-Control': 'no-store'})


@app.get('/api/analysis')
def analysis(request:Request,symbol:str='005930.KS',mode:str='스윙',source:str='yahoo',cost_bps:int=15,entry_price:float|None=None):
    _authorize(request)
    _limit(request)
    if mode not in MODES:raise HTTPException(422,'분석 주기는 1분, 5분, 스윙 중에서 선택하세요.')
    if source not in SOURCES:raise HTTPException(422,'올바르지 않은 공급원입니다.')
    if not 0<=cost_bps<=100:raise HTTPException(422,'거래비용은 편도 0~100bp로 입력하세요.')
    if source=='demo':symbol='DEMO'
    else:
        try: symbol=ticker_format(symbol)
        except ValueError as exc: raise HTTPException(422,str(exc)) from exc
    if source!='demo' and not symbol.endswith(('.KS','.KQ')):
        raise HTTPException(422,'국내 코스피·코스닥 종목만 분석할 수 있습니다.')
    # A cached pre-close Friday bar must never remain classified as current
    # after Monday's close. Change the swing cache key at the official KRX
    # close boundary (including the known 16:30 exam-day exception).
    close_boundary=None
    if mode=='스윙' and source!='demo':
        now_kst=datetime.now(KST)
        session=krx_session(now_kst)
        close_text=session.get('close_kst') or '15:30'
        try:
            close_min=int(close_text[:2])*60+int(close_text[3:])
        except (ValueError,TypeError):
            close_min=15*60+30
        close_boundary=(now_kst.date().isoformat(), now_kst.hour*60+now_kst.minute>=close_min)
    try:
        value=_cached((source,symbol,mode,cost_bps,close_boundary),lambda:_payload(symbol,mode,source,cost_bps))
    except ValueError as exc:
        raise HTTPException(422,str(exc)) from exc
    except Exception as exc:
        raise HTTPException(502, f'시세 조회/분석 실패 ({type(exc).__name__}). 종목·데이터 기간·공급원/네트워크를 확인하세요.') from exc
    if entry_price is not None:
        # Optional user fill/what-if only recomputes the READ-ONLY risk overlay.
        # It never changes legacy signal, backtest, chart or ATR reference lines.
        evidence=value.get('risk_structure',{}).get('evidence',{})
        custom=reprice_from_evidence(evidence, entry_price=entry_price, cost_bps=cost_bps,
                                     demo=value.get('is_demo',False), stale=value.get('is_stale',False))
        if custom['state']=='INVALID_ENTRY':
            raise HTTPException(422,custom['reason'])
        value={**value,'risk_structure':custom}
    # Persist only a genuine current analysis observation if durable storage
    # is explicitly configured. Failure must never alter trading decisions.
    if evidence_backend() != 'disabled':
        try:
            append_analysis(value)
        except Exception:
            logging.getLogger('nova.evidence').warning('Evidence database write failed: check DATABASE_URL or persistent disk')
    return JSONResponse(value,headers={'Cache-Control':'no-store'})

if __name__=='__main__':
    import uvicorn
    uvicorn.run(app,host=os.environ.get('NOVA_BIND_HOST','127.0.0.1'),port=int(os.environ.get('PORT','8000')))


# v4.2 — Market-wide EOD recommendation screener. No automated orders.
def _scan_snapshot():
    with SCAN_LOCK:
        state=dict(SCAN_STATE)
    state.pop('started_monotonic', None)
    state['krx_configured']=bool(os.environ.get('KRX_API_KEY','').strip())
    state['fsc_configured']=bool(os.environ.get('FSC_STOCK_API_KEY','').strip())
    state['available_sources']=['fsc','krx']
    state['storage']='server_memory_plus_ranked_evidence' if evidence_backend()!='disabled' else 'server_memory_only'
    return state


def _cached_research_flow(symbol: str) -> dict | None:
    # No new scraping/requests during broad market scan. Reuse ONLY fresh
    # existing user-observed flow data; never backdate the observation.
    code=symbol[:6]
    with CACHE_LOCK:
        item=CACHE.get(('v46_flow_per_investor_20261112',code))
    if not item or time.monotonic()-item[0]>300:
        return None
    result=item[1]
    return result if isinstance(result,dict) and result.get('symbol')==code else None


def _scan_worker(market: str, job_id: str, provider: str, api_key: str, depth: int=48):
    def progress(p):
        with SCAN_LOCK:
            if SCAN_STATE.get('job_id')==job_id:
                SCAN_STATE['progress']=p
    try:
        client = FSCStockClient(api_key) if provider == 'fsc' else None
        result=run_market_scan(market=market,api_key=api_key,client=client,
                     analyze=lambda sym:_payload(sym,'스윙','yahoo',15),
                     analyze_asof=lambda sym,date:_payload(sym,'스윙','yahoo',15,asof_date=date),
                     progress=progress,depth=depth,auxiliary_flow=_cached_research_flow)
        # Store the first actually observed ranked market candidates, without
        # changing existing recommendation decisions or screen response timing.
        if evidence_backend() != 'disabled':
            try:
                contexts=capture_market_context()
                store_auto_scan(result,market_context=contexts)
            except Exception:
                logging.getLogger('nova.autotrack').warning('Market scan evidence persistence failed')
        with SCAN_LOCK:
            if SCAN_STATE.get('job_id')==job_id:
                SCAN_STATE.update(status='complete',result=result,error=None,
                   completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'),
                   completed_monotonic=time.monotonic())
    except MarketScanError as err:
        with SCAN_LOCK:
            if SCAN_STATE.get('job_id')==job_id:
                SCAN_STATE.update(status='failed',result=None,
                  error={'code':err.code,'message':str(err)},
                  completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))
    except Exception:
        with SCAN_LOCK:
            if SCAN_STATE.get('job_id')==job_id:
                SCAN_STATE.update(status='failed',result=None,
                  error={'code':'internal','message':'시장 검색에 실패했습니다. 서버 로그와 시세 공급원을 확인하세요.'},
                  completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))


def _auto_auth(request: Request):
    """Dedicated cron-only secret; never accept browser login as cron permission."""
    token=os.environ.get('NOVA_AUTOTRACK_TOKEN','')
    enabled=os.environ.get('NOVA_AUTOTRACK_ENABLED','')=='1'
    if not enabled or len(token)<24:
        raise HTTPException(503,'자동 추적 예약 실행이 설정되지 않았습니다.')
    provided=request.headers.get('X-Nova-Autotrack-Token','')
    if not hmac.compare_digest(provided,token):
        raise HTTPException(401,'자동 추적 예약 실행 인증 실패')
    if evidence_backend()=='disabled':
        raise HTTPException(503,'영구 DB가 필요합니다.')


def _auto_worker():
    started=datetime.now(timezone.utc)
    summary={'scan':None,'evaluation':None}
    errors=[]
    def set_phase(state):
        with AUTO_LOCK: AUTO_STATE['status']=state
    try:
        # Market screening may require tens of Yahoo/OpenDART calls. Run once
        # after market close; skip absent provider credentials instead of inventing recommendations.
        provider='fsc' if os.environ.get('FSC_STOCK_API_KEY','').strip() else 'krx'
        api_key=os.environ.get('FSC_STOCK_API_KEY' if provider=='fsc' else 'KRX_API_KEY','').strip()
        if api_key:
            try:
                set_phase('scanning')
                client=FSCStockClient(api_key) if provider=='fsc' else None
                result=run_market_scan(market='all',api_key=api_key,client=client,
                    analyze=lambda symbol:_payload(symbol,'스윙','yahoo',15),
                    analyze_asof=lambda symbol,date:_payload(symbol,'스윙','yahoo',15,asof_date=date),
                    depth=24,auxiliary_flow=None)
                contexts=capture_market_context()
                summary['scan']=store_auto_scan(result,market_context=contexts)
                summary['scan'].update(source_date=result.get('data_date'),
                      deep_target=result.get('deep_target'),deep_failed=result.get('deep_failed'),
                      status='partial' if result.get('incomplete') else 'complete')
            except MarketScanError as exc:
                summary['scan']={'status':'failed','code':exc.code}
                errors.append('scan_provider_or_snapshot')
            except Exception:
                summary['scan']={'status':'failed','code':'SCAN_FAILED'}
                errors.append('scan_unavailable')
        else:
            summary['scan']={'status':'skipped','code':'NO_FSC_OR_KRX_API_KEY'}
            errors.append('scan_provider_not_configured')
        # Post-trade observations are independent of the marketwide scan.
        # Retry failed lookups on the next scheduled day (and retain raw evidence).
        set_phase('evaluating')
        try:
            summary['evaluation']=evaluate_auto_pending(_journal_daily_bars,max_symbols=12)
        except Exception:
            summary['evaluation']={'status':'failed','code':'EVALUATION_FAILED'}
            errors.append('evaluation_unavailable')
        try:
            summary['observed_signals']=evaluate_auto_observed(_journal_daily_bars,max_symbols=12)
        except Exception:
            summary['observed_signals']={'status':'failed','code':'OBSERVATION_EVALUATION_FAILED'}
            errors.append('observed_evaluation_unavailable')
    except Exception:
        errors.append('internal_worker_failure')
    finally:
        finished=datetime.now(timezone.utc)
        state='partial' if errors else 'complete'
        try:
            record_auto_attempt(started_at=started,completed_at=finished,state=state,summary=summary)
        except Exception:
            logging.getLogger('nova.autotrack').warning('Cannot persist automation job audit record')
            errors.append('audit_store_failed')
        with AUTO_LOCK:
            AUTO_STATE.update(status='partial' if errors else 'complete',
                completed_at=finished.isoformat(timespec='seconds'),
                result=summary,error_code=','.join(errors) if errors else None)


@app.post('/api/autotrack/run')
def autotrack_run(request: Request):
    _auto_auth(request)
    global AUTO_JOB
    with AUTO_LOCK:
        if AUTO_STATE.get('status') in ('scanning','evaluating','queued'):
            return JSONResponse({'status':'already_running','started_at':AUTO_STATE['started_at']},
                                headers={'Cache-Control':'no-store'})
        AUTO_STATE.update(status='queued',started_at=datetime.now(timezone.utc).isoformat(timespec='seconds'),
                          completed_at=None,error_code=None,result=None)
        AUTO_JOB=threading.Thread(target=_auto_worker,daemon=True,name='nova-auto-evidence')
        AUTO_JOB.start()
        return JSONResponse({'status':'queued','started_at':AUTO_STATE['started_at']},
                            headers={'Cache-Control':'no-store'})


@app.get('/api/autotrack/job')
def autotrack_job(request: Request):
    _auto_auth(request)
    with AUTO_LOCK: state=dict(AUTO_STATE)
    return JSONResponse(state,headers={'Cache-Control':'no-store'})


@app.get('/api/autotrack/status')
def autotrack_status(request: Request):
    _authorize(request)
    configured=os.environ.get('NOVA_AUTOTRACK_ENABLED')=='1' and len(os.environ.get('NOVA_AUTOTRACK_TOKEN',''))>=24
    response={'configured':configured,'database_connected':evidence_backend()!='disabled',
              'scheduler':'external_github_actions_required',
              'collection':'full-market snapshot screened, top 24 deep-analyzed when FSC/KRX key exists',
              'orders_enabled':False}
    with AUTO_LOCK:
        response['local_job_status']=AUTO_STATE.get('status')
        response['last_local_run']=AUTO_STATE.get('completed_at')
    if evidence_backend()!='disabled':
        try:response.update(auto_evidence_status())
        except Exception:response['storage_error']=True
    return JSONResponse(response,headers={'Cache-Control':'no-store'})


@app.get('/api/autotrack/report')
def autotrack_report(request: Request):
    _authorize(request)
    _limit(request)
    if evidence_backend()=='disabled':
        raise HTTPException(503,'영구 DB 미연결')
    try:return JSONResponse(auto_evidence_report(),headers={'Cache-Control':'no-store'})
    except Exception:
        raise HTTPException(503,'자동 추천 검증 기록을 조회하지 못했습니다.') from None


@app.get('/api/research/market-regimes')
def research_market_regimes(request: Request):
    """Research-only: immutable scan-time regimes and subsequent outcome comparison."""
    _authorize(request)
    _limit(request)
    if evidence_backend() == 'disabled':
        raise HTTPException(503,'영구 DB 연결 후 시장 상황별 연구가 가능합니다.')
    try:
        from auto_evidence import list_candidates, list_completed, latest_scan_regimes
        payload=regime_report(list_candidates(500),list_completed())
        payload['latest_market_snapshots']=latest_scan_regimes(3)
        return JSONResponse(payload,headers={'Cache-Control':'no-store'})
    except Exception:
        logging.getLogger('nova.regime').exception('Market-regime read-only report failed')
        raise HTTPException(503,'시장 상황 연구 결과를 조회하지 못했습니다.') from None


# Domestic market-activity rankings; independent from NOVA BUY/SELL.
# Naver popularity is linked on the client, never scraped or redistributed.
def _popular_snapshot():
    with POPULAR_LOCK:
        state = dict(POPULAR_STATE)
    state.pop('completed_monotonic', None)
    state['fsc_configured'] = bool(os.environ.get('FSC_STOCK_API_KEY','').strip())
    state['krx_configured'] = bool(os.environ.get('KRX_API_KEY','').strip())
    state['naver_direct_link'] = 'https://stock.naver.com/market/stock/kr/stocklist/top'
    state['not_buy_signal'] = True
    state['not_realtime'] = True
    return state


def _popular_worker(job_id: str, source: str, key: str):
    try:
        result = fetch_popularity(source=source,key=key)
        with POPULAR_LOCK:
            if POPULAR_STATE.get('job_id') == job_id:
                POPULAR_STATE.update(status='complete',result=result,error=None,
                    completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'),
                    completed_monotonic=time.monotonic())
    except MarketScanError as exc:
        with POPULAR_LOCK:
            if POPULAR_STATE.get('job_id') == job_id:
                POPULAR_STATE.update(status='failed',result=None,
                    error={'code':exc.code,'message':str(exc)})
    except Exception:
        with POPULAR_LOCK:
            if POPULAR_STATE.get('job_id') == job_id:
                POPULAR_STATE.update(status='failed',result=None,
                    error={'code':'provider_error','message':'시장 활동 순위 자료를 확인할 수 없습니다. 공급원 연결을 점검하세요.'})


@app.get('/api/popular/status')
def popular_status(request: Request):
    _authorize(request)
    _limit(request)
    return JSONResponse(_popular_snapshot(),headers={'Cache-Control':'no-store'})


@app.post('/api/popular/run')
def popular_run(request: Request, body: dict):
    _authorize(request)
    _limit(request)
    source = body.get('source','auto')
    if source not in ('auto','fsc','krx'):
        raise HTTPException(422,'데이터 공급원은 auto, fsc, krx 중 하나여야 합니다.')
    if source == 'auto':
        source = 'fsc' if os.environ.get('FSC_STOCK_API_KEY','').strip() else 'krx'
    name = 'FSC_STOCK_API_KEY' if source == 'fsc' else 'KRX_API_KEY'
    key = os.environ.get(name,'').strip()
    if not key:
        raise HTTPException(503,{'code':'source_unavailable',
          'message':'국내 시장 활동 순위에는 FSC_STOCK_API_KEY 또는 KRX_API_KEY 설정이 필요합니다.'})
    global POPULAR_JOB
    with POPULAR_LOCK:
        if POPULAR_STATE.get('status') == 'running':
            return JSONResponse(dict(_popular_snapshot(),notice='현재 인기종목 순위 자료를 확인 중입니다.'),headers={'Cache-Control':'no-store'})
        if POPULAR_STATE.get('status') == 'complete' and POPULAR_STATE.get('source') == source and \
           POPULAR_STATE.get('completed_monotonic') and time.monotonic()-POPULAR_STATE['completed_monotonic'] < 30*60:
            return JSONResponse(dict(_popular_snapshot(),notice='30분 이내 조회 결과를 재사용합니다.'),headers={'Cache-Control':'no-store'})
        job_id = secrets.token_hex(8)
        POPULAR_STATE.clear()
        POPULAR_STATE.update(status='running',source=source,job_id=job_id,result=None,error=None,
          started_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))
        POPULAR_JOB = threading.Thread(target=_popular_worker,args=(job_id,source,key),daemon=True,
                                     name='nova-market-activity-rank')
        POPULAR_JOB.start()
    return JSONResponse(_popular_snapshot(),headers={'Cache-Control':'no-store'})


@app.get('/api/recommendations/status')
def recommendations_status(request: Request):
    _authorize(request)
    _limit(request)
    return JSONResponse(_scan_snapshot(),headers={'Cache-Control':'no-store'})


@app.post('/api/recommendations/run')
def recommendations_run(request: Request, body: dict):
    _authorize(request)
    _limit(request)
    depth=body.get('depth',48)
    if type(depth) is not int or depth not in (24,48,60):
        raise HTTPException(422,'심층 분석 수는 24/48/60 중에서 선택하세요.')
    market=body.get('market','all')
    if market not in ('all','kospi','kosdaq'):
        raise HTTPException(422,'시장 구분은 all, kospi, kosdaq 중 하나여야 합니다.')
    provider=body.get('source','auto')
    if provider not in ('auto','fsc','krx'):
        raise HTTPException(422, '데이터 공급원은 auto, fsc, krx 중 하나여야 합니다.')
    if provider=='auto':
        provider='fsc' if os.environ.get('FSC_STOCK_API_KEY','').strip() else 'krx'
    keyname='FSC_STOCK_API_KEY' if provider=='fsc' else 'KRX_API_KEY'
    key=os.environ.get(keyname,'').strip()
    if not key:
        if provider=='fsc':
            raise HTTPException(503, {'code':'fsc_not_configured',
                'message':'공공데이터포털 금융위원회_주식시세정보를 활용 신청하고 Render의 FSC_STOCK_API_KEY를 설정하세요.'})
        raise HTTPException(503, {'code':'krx_not_configured',
            'message':'FSC_STOCK_API_KEY 또는 KRX_API_KEY가 없습니다. 금융위원회 주식시세 API 활용신청을 권장합니다.'})
    with BACKTEST_LOCK:
        if BACKTEST_STATE.get('status') == 'running':
            raise HTTPException(409,'과거 검증이 진행 중입니다. 종료 후 전체 시장 검색을 실행하세요.')
    global SCAN_JOB
    with SCAN_LOCK:
        current=SCAN_STATE.get('status')
        if current=='running':
            return JSONResponse(dict(_scan_snapshot(),notice='이미 시장 검색이 진행 중입니다.'),
                                headers={'Cache-Control':'no-store'})
        if (current=='complete' and SCAN_STATE.get('market')==market and SCAN_STATE.get('source')==provider and
            SCAN_STATE.get('depth')==depth and
            SCAN_STATE.get('completed_monotonic') and
            time.monotonic()-SCAN_STATE['completed_monotonic']<20*60):
            return JSONResponse(dict(_scan_snapshot(),notice='20분 이내 완료한 검색 결과를 재사용합니다.'),
                                headers={'Cache-Control':'no-store'})
        job_id=secrets.token_hex(8)
        SCAN_STATE.clear()
        label='금융위원회 T+1' if provider=='fsc' else 'KRX 장 마감'
        SCAN_STATE.update(status='running',market=market,source=provider,depth=depth,job_id=job_id,
            progress={'phase':'provider','done':0,'total':None,'message':f'{label} 일별 시장자료 확인 중'},
            result=None,error=None,started_at=datetime.now(timezone.utc).isoformat(timespec='seconds'),
            started_monotonic=time.monotonic())
        SCAN_JOB=threading.Thread(target=_scan_worker,args=(market,job_id,provider,key,depth),daemon=True,
                                   name='nova-market-eod-scan')
        SCAN_JOB.start()
    return JSONResponse(_scan_snapshot(),headers={'Cache-Control':'no-store'})


@app.post('/api/recommendations/diagnose')
def recommendations_diagnose(request: Request):
    """Auth-protected, user-triggered KRX production connection check.

    No raw keys, headers, provider response, or arbitrary URLs disclosed.
    """
    _authorize(request)
    _limit(request)
    key=os.environ.get('KRX_API_KEY','').strip()
    if not key:
        return JSONResponse({'configured':False,'date':None,'results':[],
            'notes':'Render 환경변수 KRX_API_KEY가 설정되지 않았습니다.'},
            headers={'Cache-Control':'no-store'})
    date=next(completed_dates(datetime.now(KST)))
    details=diagnose_connection(key,date,['kospi','kosdaq'])
    return JSONResponse(details,headers={'Cache-Control':'no-store'})


# v4.4 historical baseline: authenticate, run a bounded weekly FSC screen
# on past snapshots, evaluate only after publication, and never call this
# "final NOVA recommendation" performance.
def _history_snapshot():
    with BACKTEST_LOCK:
        data = dict(BACKTEST_STATE)
    data.pop('started_monotonic', None)
    data['fsc_configured'] = bool(os.environ.get('FSC_STOCK_API_KEY','').strip())
    data['scope'] = 'first_stage_only'
    return data


def _history_worker(job_id: str, market: str, weeks: int, cost_bps: int, key: str):
    def on_progress(info):
        with BACKTEST_LOCK:
            if BACKTEST_STATE.get('job_id') == job_id:
                BACKTEST_STATE['progress'] = info
    try:
        result = run_screen_history(market=market, api_key=key, weeks=weeks,
                                    cost_bps=cost_bps, progress=on_progress)
        with BACKTEST_LOCK:
            if BACKTEST_STATE.get('job_id') == job_id:
                BACKTEST_STATE.update(status='complete',result=result,error=None,
                    completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'),
                    completed_monotonic=time.monotonic())
    except MarketScanError as exc:
        with BACKTEST_LOCK:
            if BACKTEST_STATE.get('job_id') == job_id:
                BACKTEST_STATE.update(status='failed',result=None,
                    error={'code':exc.code,'message':str(exc)},
                    completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))
    except Exception:
        # Never expose provider URLs: FSC serviceKey can be embedded in exception.
        with BACKTEST_LOCK:
            if BACKTEST_STATE.get('job_id') == job_id:
                BACKTEST_STATE.update(status='failed',result=None,
                    error={'code':'history_failed',
                           'message':'과거 시세를 검증할 수 없습니다. 공급원 상태와 서버 로그를 확인하세요.'},
                    completed_at=datetime.now(timezone.utc).isoformat(timespec='seconds'))


@app.get('/api/recommendations/backtest/status')
def recommendation_backtest_status(request: Request):
    _authorize(request)
    _limit(request)
    return JSONResponse(_history_snapshot(),headers={'Cache-Control':'no-store'})


@app.post('/api/recommendations/backtest/run')
def recommendation_backtest_run(request: Request, body: dict):
    _authorize(request)
    _limit(request)
    market = body.get('market','all')
    weeks = body.get('weeks',4)
    cost = body.get('cost_bps',15)
    if market not in ('all','kospi','kosdaq') or type(weeks) is not int or weeks not in (4,8) or type(cost) is not int or not 0<=cost<=100:
        raise HTTPException(422,'허용 범위: 시장 all/kospi/kosdaq, 과거 4/8주, 편도 비용 0~100bp')
    key = os.environ.get('FSC_STOCK_API_KEY','').strip()
    if not key:
        raise HTTPException(503, {'code':'fsc_not_configured',
              'message':'Render에 FSC_STOCK_API_KEY를 먼저 설정하세요.'})
    with SCAN_LOCK:
        if SCAN_STATE.get('status') == 'running':
            raise HTTPException(409,'현재 종목추천 검색 중입니다. 검색이 종료된 후 백테스트를 실행하세요.')
    global BACKTEST_JOB
    with BACKTEST_LOCK:
        if BACKTEST_STATE.get('status') == 'running':
            return JSONResponse(dict(_history_snapshot(),notice='과거 검증이 이미 진행 중입니다.'),headers={'Cache-Control':'no-store'})
        if (BACKTEST_STATE.get('status') == 'complete' and
            BACKTEST_STATE.get('market') == market and
            BACKTEST_STATE.get('weeks') == weeks and
            BACKTEST_STATE.get('cost_bps') == cost and
            BACKTEST_STATE.get('completed_monotonic') and
            time.monotonic()-BACKTEST_STATE['completed_monotonic'] < 20*60):
            return JSONResponse(dict(_history_snapshot(),notice='20분 이내 완료된 과거 검증을 재사용합니다.'),headers={'Cache-Control':'no-store'})
        job_id=secrets.token_hex(8)
        BACKTEST_STATE.clear()
        BACKTEST_STATE.update(status='running',market=market,weeks=weeks,cost_bps=cost,
              job_id=job_id,result=None,error=None,started_at=datetime.now(timezone.utc).isoformat(timespec='seconds'),
              started_monotonic=time.monotonic(),
              progress={'phase':'starting','done':0,'total':weeks,'message':'과거 일별 전체시장 스냅샷 조회 시작'})
        BACKTEST_JOB=threading.Thread(target=_history_worker,args=(job_id,market,weeks,cost,key),daemon=True,name='nova-market-history')
        BACKTEST_JOB.start()
    return JSONResponse(_history_snapshot(),headers={'Cache-Control':'no-store'})
