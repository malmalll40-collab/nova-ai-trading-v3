/* NOVA v5.2 – isolated observational research and on-demand trade feed.
   No write routes, no trading order, no overrides to the existing decision. */
(()=>{
'use strict';
const byId=id=>document.getElementById(id);
let current=null;
let referenceClose=null;
let inflight=null;
let socket=null;
let wsTarget=null;
let wsConnected=false;
let currentResearch=null;
let batchPoll=null;
let batchJob=null;
const money=v=>Number.isFinite(Number(v))?Math.round(Number(v)).toLocaleString('ko-KR')+'원':'미확인';
const percent=v=>typeof v==='number'&&Number.isFinite(v)?`${v>0?'+':''}${v.toFixed(2)}%`:'표본 없음';
const unsignedPct=v=>typeof v==='number'&&Number.isFinite(v)?`${v.toFixed(2)}%`:'미확인';
const errMsg=msg=>String(msg||'조회 실패').slice(0,180);
const el=(tag,className='',text='')=>{const x=document.createElement(tag);if(className)x.className=className;if(text)x.textContent=text;return x;};
function status(text,error=false){const s=byId('v5ResearchStatus');if(!s)return;s.textContent=text;s.classList.toggle('v5-error',error);}
function stopSocket(message){
 if(socket){const old=socket;socket=null;try{old.close(1000,'Stopped by user');}catch{}}
 const value=byId('v5LiveValue');if(value)value.hidden=true;
 wsTarget=null;wsConnected=false;
 const button=byId('v5LiveToggle');if(button)button.textContent='체결 관찰 시작';
 const label=byId('v5LiveState');if(label&&message)label.textContent=message;
}
function setAnalysis(data){
 const key=data?.symbol&&data?.mode==='스윙'&&!data.is_demo?data.symbol:null;
 if(key!==current){if(inflight){inflight.abort();inflight=null;}
   currentResearch=null;
   const content=byId('v5ResearchContent');if(content)content.hidden=true;
   const tradeRows=byId('v51TradeRows');if(tradeRows)tradeRows.replaceChildren();
   status(key?`${key.slice(0,6)} 과거 완료봉 연구 준비 · 버튼을 누르면 조회합니다.`:'스윙 실종목의 완료봉에서만 연구할 수 있습니다.');
   if(socket)stopSocket('종목 또는 분석 주기가 바뀌어 실시간 관찰을 종료했습니다.');
 }
 current=key;
 referenceClose=Number.isFinite(Number(data?.reference))&&Number(data.reference)>0?Number(data.reference):null;
 const button=byId('v5ResearchRun');if(button)button.disabled=!key;
}
function metric(label,value){const row=el('div','v5-metric');row.append(el('span','',label),el('b','',value));return row;}
function methodCard(label,stats,reason=''){
 const c=el('article','v5-method-card');c.appendChild(el('strong','',label));
 if(!stats||stats.status!=='READY'){
   c.appendChild(el('p','v5-note',reason||stats?.reason||'검증 불가 · 자료 미확인'));return c;
 }
 c.append(metric('실제 가상거래',`${stats.completed_trades??0}건`));
 c.append(metric('가상 순수익률',Number(stats.completed_trades)>0?percent(stats.portfolio_return_pct):'평가할 거래 없음'));
 c.append(metric('최대 낙폭',Number(stats.completed_trades)>0?percent(stats.portfolio_mdd_pct):'평가할 거래 없음'));
 c.append(metric('거래 승률',percent(stats.win_rate_pct)));
 c.append(metric('진입 조건',`${stats.buy_opportunities??0}회`));
 return c;
}
function renderRiskAudit(audit){
 const summary=byId('v52RiskSummary'),ledger=byId('v52RiskLedger');
 const trials=byId('v52FilterTrials'),overlap=byId('v52RoleOverlap');
 if(!summary||!ledger||!trials||!overlap)return;
 for(const element of [summary,ledger,trials,overlap])element.replaceChildren();
 if(!audit||audit.status!=='READY'){
   summary.append(el('p','v51-empty','위험 연구를 계산할 자료가 부족합니다. 실전 신호에는 영향이 없습니다.'));return;
 }
 const signalSummary=el('div','v52-summary-grid');
 for(const [label,value] of [['검증 거래 수',`${audit.baseline_validation_trades??0}건`],
   ['손실 거래',`${audit.loss_trade_count??0}건`],['연구 판단',audit.review_status||'검증 대기']]){
   const cell=el('div','v52-summary-cell');cell.append(el('small','',label),el('strong','',value));signalSummary.append(cell);
 }
 summary.append(signalSummary);
 summary.append(el('p','v5-note',audit.scope||'시장 환경·수급 확인과 추가 검증이 필요합니다.'));
 const history=audit.risk_ledger||[];
 if(!history.length)ledger.append(el('div','v51-empty','검증 구간에 평가 가능한 기존 13개 역할 가상거래가 없습니다.'));
 for(const x of history){
   const box=el('details','v52-risk-record');
   box.append(el('summary','',`${x.signal_date} 신호 → ${x.entry_date} 진입 · ${percent(x.trade_return_pct)} · 위험표시 ${(x.flagged_risks||[]).length}개`));
   const feat=x.signal_day_features||{};
   box.append(el('div','v52-risk-detail',`신호일 ATR/종가 ${unsignedPct(feat.atr_close_pct)} · EMA20 이격 ${typeof feat.ema20_distance_atr==='number'?feat.ema20_distance_atr.toFixed(2)+' ATR':'미확인'} · RSI ${typeof feat.rsi_value==='number'?feat.rsi_value.toFixed(1):'미확인'}`));
   box.append(el('div','v52-risk-detail',`전일 지수 20일 수익률 ${percent(feat.market_prior_20d_pct)} · 다음 시가 갭 ${percent(x.open_gap_pct)} (동일 시가 체결 보장 불가)`));
   box.append(el('div','v52-risk-detail',`경고: ${(x.flagged_risks||[]).join(', ')||'고정 조건 위반 확인 없음'} · 자료 미확인: ${(x.unknown_risks||[]).join(', ')||'없음'}`));
   box.append(el('div','v52-risk-disclaimer','위험표시는 사후 진단용이며 이 손실의 원인이나 미래 가격 예측이 아닙니다.'));
   ledger.append(box);
 }
 for(const f of audit.filter_trials||[]){
   const box=el('details','v52-filter-row');
   box.append(el('summary','',`${f.label} · ${f.status==='READY'?(f.validation?.completed_trades??0)+'건 비교':'자료 보류'}`));
   box.append(el('div','v52-risk-detail',f.rule));
   if(f.status!=='READY')box.append(el('div','v52-risk-detail',f.reason||'비교 데이터 부족'));
   else{
     const before=audit.baseline_validation_trades??0;
     box.append(el('div','v52-risk-detail',`검증 거래 ${before}건 → ${f.validation?.completed_trades??0}건 · 검증 총자산 수익률 차이 ${typeof f.validation_return_difference_pp==='number'?(f.validation_return_difference_pp>0?'+':'')+f.validation_return_difference_pp.toFixed(3)+'%p':'미확인'}`));
     box.append(el('div','v52-risk-detail',`형성 기간 거래 ${f.formation?.completed_trades??0}건 · 제거 거래 ${f.avoided_trade_count??0}건 (수익 거래 ${f.avoided_winners??0}건 포함) · 추가 거래 ${f.new_trade_count??0}건`));
     if((f.validation?.completed_trades??0)===0)box.append(el('div','v52-risk-disclaimer','가상 거래 0건은 성능 향상 또는 위험 제거 성공의 증거가 아닙니다.'));
     for(const t of (f.avoided_trade_examples||[]).slice(0,5))box.append(el('div','v52-risk-detail',`제외 ${t.signal_date} · ${percent(t.net_trade_return_pct)} (가상)`));
   }
   box.append(el('div','v52-risk-disclaimer','사전 고정 필터의 조건 비교이며, 최종 신호는 변경하지 않았습니다.'));
   trials.append(box);
 }
 const r=audit.role_overlap||{};
 overlap.append(el('p','v5-note',`검증 ${r.validation_sessions??0}개 시점 · 10개 독립 역할의 ${(r.evaluated_pairs??0)}쌍 중 기준을 충족한 중복 후보 ${(r.candidates||[]).length}쌍`));
 const pairs=(r.candidates||[]).length?r.candidates:r.most_observed_pairs||[];
 if(!pairs.length)overlap.append(el('p','v51-empty','역할 활동 표본이 부족합니다.'));
 for(const p of pairs.slice(0,8))overlap.append(el('div','v52-risk-detail',`역할 ${p.roles?.join(' ↔ ')||'—'} · 동시 활성 ${p.both_active??0}회 · 같은 방향 ${p.direction_agreement_pct==null?'미확인':p.direction_agreement_pct+'%'} · 활동 겹침 ${p.activity_overlap_pct==null?'미확인':p.activity_overlap_pct+'%'}${p.redundancy_candidate?' · 중복 가능성':''}`));
 overlap.append(el('p','v52-risk-disclaimer',r.interpretation||'역할 제거 권고 아님'));
}
function render(data){
 const container=byId('v5ResearchContent');const cards=byId('v5MethodCards');
 const roles=byId('v5RoleAblation');const aiBox=byId('v5AIDetails');const limits=byId('v5Limitations');
 if(!container||!cards||!roles||!aiBox||!limits)return;
 cards.replaceChildren();roles.replaceChildren();aiBox.replaceChildren();limits.replaceChildren();container.hidden=true;
 if(data.status!=='READY'){
   status(`연구 보류 · ${data.reason||'자료 부족'}`);return;
 }
 currentResearch=data;
 const phase=data.validation||{};
 const ai=phase.ai_model||{};
 const period=byId('v5StudyPeriod');period.textContent=`검증 구간 ${phase.start||'—'} ~ ${phase.end||'—'} · 자료 ${data.source||'미확인'} · 비용 편도 ${phase.baseline?.cost_bps_per_side??15}bp`;
 cards.append(methodCard('기존 13개 역할',phase.baseline));
 cards.append(methodCard('연구 5-Core',phase.five_core));
 cards.append(methodCard('AI 연구 신호',ai.research_strategy,ai.reason||'학습/검증 표본 부족'));
 const reference=el('article','v5-method-card');reference.append(el('strong','','AI 모델 검증 상태'));
 reference.append(metric('학습 완료 표본',`${ai.train_samples??0}건`));
 reference.append(metric('검증 완료 표본',`${ai.validation_samples??0}건`));
 reference.append(metric('Brier 점수',typeof ai.brier_score==='number'?String(ai.brier_score):'검증 전'));
 reference.append(metric('단순 기준 Brier',typeof ai.naive_train_rate_brier==='number'?String(ai.naive_train_rate_brier):'검증 전'));
 cards.append(reference);
 let best=null;
 for(const item of data.role_ablations||[]){
   const r=el('details','v5-role-row v51-role-detail');
   const label=el('summary');const diff=item.return_difference_pp;
   label.append(el('span','',item.role),el('b','',diff===null?'계산 불가':`${diff>0?'+':''}${diff.toFixed(3)}%p`));
   r.append(label);
   const note=el('div','v51-role-note');
   note.append(el('div','',`기본 완료 ${item.base_completed_trades??0}건 → 제거 후 ${item.without_completed_trades??0}건 · 없어지는 거래 ${item.removed_trade_count??0}건 · 새로 생기는 거래 ${item.added_trade_count??0}건`));
   for(const x of (item.removed_trade_examples||[]))note.append(el('div','',`제외된 가상거래: ${x.signal_date} → ${x.exit_date} · ${percent(x.net_trade_return_pct)}`));
   for(const x of (item.added_trade_examples||[]))note.append(el('div','',`추가된 가상거래: ${x.signal_date} → ${x.exit_date} · ${percent(x.net_trade_return_pct)}`));
   note.append(el('div','',item.interpretation_warning||'역할 제거는 원인 분석이 아니라 조건 변화 실험입니다.'));
   r.append(note);roles.append(r);
   if(typeof diff==='number'&&(best===null||diff>best))best=diff;
 }
 aiBox.textContent=ai.status==='READY'?`AI 연구 표본: 학습 ${ai.train_samples}건 / 검증 ${ai.validation_samples}건. 점수 범위 ${ai.score_range?.join('~')||'—'} · 보정된 상승 확률 아님. 실전 신호 반영 없음.`:`AI 연구 보류: ${ai.reason||'평가 자료 부족'}. 현재 매매 판단에는 영향이 없습니다.`;
 if(best!==null){aiBox.appendChild(el('p','v5-note','역할을 제거했을 때의 수익률 차이는 인과적 기여도나 전략 채택 근거가 아닙니다. 표본과 시장 상황에 따라 결과가 달라집니다.'));}
 for(const warning of data.bias_warnings||[]){const p=el('p','',`• ${warning}`);limits.append(p);}
 limits.append(el('p','',data.assumptions||''));
 container.hidden=false;
 renderRiskAudit(data.risk_audit);
 showTrades();
 status(`검증 구간 분석 완료 · 연구 결과는 실제 매매 신호·주문·추천 순위를 변경하지 않습니다.${data.source_fallback_reason?' · '+data.source_fallback_reason:''}`);
}
function showTrades(){
 const box=byId('v51TradeRows');if(!box)return;
 box.replaceChildren();
 const which=byId('v51TradeMethod')?.value||'baseline';
 const ledger=currentResearch?.trade_diagnostics?.[which]||[];
 const model=which==='baseline'?currentResearch?.validation?.baseline:
             which==='five_core'?currentResearch?.validation?.five_core:
             currentResearch?.validation?.ai_model?.research_strategy;
 if(!model||model.status!=='READY'){
   box.append(el('p','v51-empty','연구 결과가 없거나 해당 엔진의 검증 자료가 부족합니다.'));return;
 }
 if(!ledger.length){box.append(el('p','v51-empty','평가할 가상거래 0건 · 수익률 0%를 검증된 안전 성적으로 해석하면 안 됩니다.'));return;}
 for(const x of ledger){
   const line=el('article','v51-trade');
   const net=x.net_trade_return_pct;const tone=net>=0?'v51-positive':'v51-negative';
   line.append(el('strong','',`신호 ${x.signal_date} · 가상 진입 ${x.entry_date} → 청산 ${x.exit_date}`));
   line.append(el('small','',`진입 ${money(x.entry_price)} · 청산 ${money(x.exit_price)} · ${x.quantity_shares}주 · 실거래 아님`));
   line.append(el('b',tone,`비용 차감 거래수익률 ${percent(net)} · 가상 손익 ${money(x.net_pnl_krw)}`));
   box.append(line);
 }
 if(model.trade_ledger_truncated)box.append(el('div','v51-empty','거래 로그는 최대 60건까지만 표시합니다.'));
}
const knownStockNames={'005930.KS':'삼성전자','000660.KS':'SK하이닉스','005380.KS':'현대차','247540.KQ':'에코프로비엠','086520.KQ':'에코프로','035420.KS':'NAVER','068270.KS':'셀트리온'};
function batchMetric(label,obj){
 const node=el('div','v51-batch-metric');node.append(el('small','',label));
 const n=obj?.completed_trades??0;
 node.append(el('strong','',obj?.status==='READY'?(n?percent(obj.portfolio_return_pct):'거래 0건'):'미확인'));
 return node;
}
function batchDisplay(state){
 const box=byId('v51BatchResults'),msg=byId('v51BatchStatus');if(!box||!msg)return;
 const rows=state.rows||[];box.hidden=false;box.replaceChildren();
 msg.textContent=state.status==='running'?`여러 종목 분석 중: ${state.finished||0}/${state.symbols?.length||0} 완료 · 시세 공급원 응답에 따라 지연될 수 있습니다.`:
 state.status==='complete'?`일괄 분석 완료: ${rows.filter(r=>r.status==='READY').length}/${rows.length} 종목 계산 완료 · 개별 검증 구간 확인`:
 '작업 대기. 서버 재시작·절전 시 진행 중 작업이 사라질 수 있습니다.';
 for(const r of rows){
   const wrap=el('details','v51-batch-stock');
   const headline=el('summary');headline.append(el('strong','',`${knownStockNames[r.symbol]||r.symbol} · ${r.symbol}`),el('span','',r.status==='READY'?'완료':'보류'));
   wrap.append(headline);
   if(r.status!=='READY')wrap.append(el('p','v5-note',r.reason||'자료 부족'));
   else{
     wrap.append(el('p','v51-batch-meta',`검증 ${r.validation_start||'—'} ~ ${r.validation_end||'—'} · ${r.source||'미확인'} 공급원 · ${r.source_fallback_reason||'각 종목별 시계열 별도 검증'}`));
     const cards=el('div','v51-batch-metrics');
     cards.append(batchMetric('13개 역할 가상 수익률',r.baseline),batchMetric('5-Core 가상 수익률',r.five_core),batchMetric('AI 가상 수익률',r.ai_model?.research_strategy));wrap.append(cards);
     const totals=el('p','v5-note',`거래 수: 13역할 ${r.baseline?.completed_trades??0}건 · 5-Core ${r.five_core?.completed_trades??0}건 · AI ${r.ai_model?.research_strategy?.completed_trades??0}건`);
     wrap.append(totals);
     const risk=r.risk_audit||{};if(risk.status==='READY')wrap.append(el('p','v52-batch-risk',`손실 거래 ${risk.loss_trade_count??0}/${risk.baseline_validation_trades??0}건 · 사전 고정 위험 필터 ${(risk.filter_trials||[]).filter(x=>x.status==='READY').length}개 비교 · 실전 신호 미변경`));
     let aiB=r.ai_model?.brier_score,naive=r.ai_model?.naive_train_rate_brier;
     wrap.append(el('p','v5-note',typeof aiB==='number'&&typeof naive==='number'?`AI Brier ${aiB.toFixed(4)} / 단순 기준 ${naive.toFixed(4)} · ${aiB<naive?'단순 기준보다 낮은 오차 (우월성 미확정)':'AI 기준 모델보다 개선 미입증'}`:'AI 오차 지표 평가 대기'));
     const trades=(r.trade_diagnostics||{}).baseline||[];
     wrap.append(el('div','v51-batch-subtitle',`기존 13역할 가상 거래 내역 (${trades.length}건)`));
     for(const t of trades.slice(0,12))wrap.append(el('div','v51-batch-meta',`${t.signal_date} 신호 → ${t.entry_date} 진입 → ${t.exit_date} 청산 · ${percent(t.net_trade_return_pct)} · 실제 체결 아님`));
     if(trades.length>12)wrap.append(el('p','v5-note','화면에는 최대 12건을 표시합니다.'));
     const roles=(r.role_ablations||[]).filter(x=>x.removed_trade_count||x.added_trade_count);
     if(roles.length){
       wrap.append(el('div','v51-batch-subtitle','거래 변화가 확인된 역할 제거 실험'));
       for(const x of roles)wrap.append(el('div','v51-batch-meta',`${x.role}: 기본 ${x.base_completed_trades}건 → 제거 ${x.without_completed_trades}건 · 제외 ${x.removed_trade_count} / 추가 ${x.added_trade_count}건`));
     }
   }
   box.append(wrap);
 }
 if(state.status==='complete' && rows.length){
   box.append(el('p','v51-empty','종목별 투자금·검증일·시세 공급원 차이가 있습니다. 이 값들을 더해 실제 포트폴리오 수익률처럼 해석하지 마세요.'));
 }
}
function stopBatchPoll(){if(batchPoll){clearTimeout(batchPoll);batchPoll=null;}}
async function batchStatus(){
 const response=await fetch('/api/research/v5/batch/status',{credentials:'same-origin',cache:'no-store'});
 if(!response.ok)throw new Error(`진행 조회 HTTP ${response.status}`);
 const state=await response.json();
 if(!batchJob && state.status==='running' && state.job_id)batchJob=state.job_id;
 if(batchJob&&state.job_id!==batchJob){throw new Error('서버가 재시작되었거나 다른 작업이 시작되어 이전 작업 결과가 없습니다.');}
 batchDisplay(state);
 if(state.status==='running')batchPoll=setTimeout(()=>batchStatus().catch(batchFailure),5000);
 else{batchJob=null;const button=byId('v51BatchRun');if(button)button.disabled=false;}
}
function batchFailure(e){stopBatchPoll();batchJob=null;const b=byId('v51BatchRun');if(b)b.disabled=false;const p=byId('v51BatchStatus');if(p)p.textContent=`일괄 연구 상태 확인 실패: ${errMsg(e.message)} · 다시 실행 전 서버 상태를 확인하세요.`;}
async function runBatch(){
 if(batchJob){return;}
 const raw=byId('v51BatchSymbols')?.value||'';
 const symbols=raw.split(/[,\n;]/).map(x=>x.trim().toUpperCase()).filter(Boolean);
 const statusNode=byId('v51BatchStatus');
 if(symbols.length<2||symbols.length>5||symbols.some(x=>!/^\d{6}\.(KS|KQ)$/.test(x))||new Set(symbols).size!==symbols.length){
   statusNode.textContent='종목을 2~5개 입력하세요. 예: 005930.KS, 000660.KS · 중복이나 6자리/시장 구분 누락은 허용하지 않습니다.';return;
 }
 const b=byId('v51BatchRun');b.disabled=true;statusNode.textContent='연구 작업 등록 중…';
 try{
   const cost=window.NOVAConnect?.cost?.()??15;
   const response=await fetch('/api/research/v5/batch/run',{method:'POST',credentials:'same-origin',
     headers:{'Content-Type':'application/json'},body:JSON.stringify({symbols,source:'auto',cost_bps:Math.max(0,Math.min(100,Math.round(Number(cost)||15)))})});
   const result=await response.json().catch(()=>({}));
   if(!response.ok)throw new Error(result.detail||`HTTP ${response.status}`);
   batchJob=result.job_id;stopBatchPoll();await batchStatus();
 }catch(e){batchFailure(e);}
}
async function fetchResearch(){
 if(!current){status('스윙 종목 분석을 먼저 실행해 주세요.');return;}
 if(inflight){status('이미 연구를 조회 중입니다.');return;}
 const target=current;
 const controller=new AbortController();inflight=controller;
 const button=byId('v5ResearchRun');button.disabled=true;button.textContent='과거 성과 계산 중…';
 status('KIS 완료 일봉·시장지수 확인 및 시간순 연구 계산 중…');
 try{
   const source=window.NOVAConnect?.source?.()||'auto';
   const safeSource=['kis','auto','yahoo'].includes(source)?source:'auto';
   const cost=window.NOVAConnect?.cost?.()??15;
   const resp=await fetch(`/api/research/v5?symbol=${encodeURIComponent(target)}&source=${encodeURIComponent(safeSource)}&cost_bps=${Math.max(0,Math.min(100,Math.round(Number(cost)||15)))}`,
                          {credentials:'same-origin',cache:'no-store',signal:controller.signal});
   const result=await resp.json().catch(()=>({}));
   if(target!==current)return;
   if(!resp.ok)throw new Error(typeof result.detail==='string'?result.detail:`HTTP ${resp.status}`);
   render(result);
 }catch(e){if(e.name!=='AbortError'&&target===current)status(`연구 조회 실패 · ${errMsg(e.message)}. 기존 매매 결과는 유지됩니다.`,true);
 }finally{if(inflight===controller)inflight=null;button.disabled=!current;button.textContent='현재 종목 정밀 연구 실행';}
}
async function liveButton(){
 const btn=byId('v5LiveToggle'),label=byId('v5LiveState');
 if(socket){stopSocket('수동으로 실시간 관찰을 중단했습니다. 기존 REST 조회는 계속됩니다.');return;}
 if(!current){label.textContent='먼저 국내 종목의 스윙 분석을 해 주세요.';return;}
 btn.disabled=true;label.textContent='KIS 실시간 기능 활성화 상태 확인 중…';
 try{
   const r=await fetch('/api/realtime/kis/status',{credentials:'same-origin',cache:'no-store'});
   const body=await r.json().catch(()=>({}));
   if(!r.ok)throw new Error('접근 권한 확인 필요');
   if(!body.enabled){label.textContent='기본값은 비활성화입니다. Render에 NOVA_KIS_WS_ENABLED=1을 설정하고 KIS 권한을 확인해야 이용할 수 있습니다.';btn.textContent='연결 가능 여부 확인';return;}
   if(!('WebSocket' in window))throw new Error('이 브라우저는 WebSocket을 지원하지 않습니다.');
   const symbol=current,code=symbol.slice(0,6);
   const url=`${location.protocol==='https:'?'wss':'ws'}://${location.host}/api/realtime/kis/stream?symbol=${encodeURIComponent(symbol)}`;
   socket=new WebSocket(url);wsTarget=symbol;wsConnected=false;
   btn.textContent='관찰 중단';label.textContent='KIS 체결 채널 연결 시도 중…';
   socket.onmessage=event=>{
     if(wsTarget!==current){stopSocket('종목이 변경되어 관찰을 종료했습니다.');return;}
     let d;try{d=JSON.parse(event.data);}catch{return;}
     if(d.type==='trade'&&d.symbol===code){
       wsConnected=true;byId('v5LiveValue').hidden=false;
       byId('v5LivePrice').textContent=money(d.price);
       byId('v5LiveTime').textContent=`체결 ${d.trade_time_kst||'—'} · ${d.trade_volume??0}주`;
       const gap=referenceClose==null?null:100*(Number(d.price)/referenceClose-1);
       const flag=gap==null?'완료봉 비교 미확인':`${gap>=0?'+':''}${gap.toFixed(2)}% · ${Math.abs(gap)>=5?'큰 변동 관찰':Math.abs(gap)>=3?'변동 확대 관찰':'참고 범위'}`;
       label.textContent=`KIS 체결 틱 수신 · ${d.observed_at_kst||'—'} · 완료봉 대비 ${flag} · 기존 신호 미변경`;
     }else if(d.type==='error'){label.textContent=errMsg(d.message);stopSocket(label.textContent);}
     else if(d.message)label.textContent=errMsg(d.message);
   };
   socket.onclose=()=>{
     if(wsTarget===symbol){socket=null;wsTarget=null;btn.textContent='체결 관찰 시작';
       if(!wsConnected)label.textContent+=' · 체결 데이터 수신 전 종료';}
   };
   socket.onerror=()=>{label.textContent='실시간 체결 연결 오류 · REST 시세는 계속 사용합니다.';};
 }catch(e){label.textContent=errMsg(e.message);}
 finally{btn.disabled=false;}
}
function onViewChange(view){
 const menu=byId('v5MoreMenu'),more=byId('v5MoreNav');
 if(menu)menu.hidden=true;if(more){more.setAttribute('aria-expanded','false');more.classList.toggle('active',['finance','news','guide'].includes(view));}
 if(view!=='analyze'&&socket)stopSocket('종목 분석 화면을 벗어나 실시간 관찰을 종료했습니다.');
}
function init(){
 const button=byId('v5ResearchRun');if(button)button.addEventListener('click',fetchResearch);
 const live=byId('v5LiveToggle');if(live)live.addEventListener('click',liveButton);
 const ledgerSelect=byId('v51TradeMethod');if(ledgerSelect)ledgerSelect.addEventListener('change',showTrades);
 const batchButton=byId('v51BatchRun');if(batchButton)batchButton.addEventListener('click',runBatch);
 const batchRefresh=byId('v51BatchRefresh');if(batchRefresh)batchRefresh.addEventListener('click',()=>{stopBatchPoll();batchStatus().catch(batchFailure);});
 const menu=byId('v5MoreMenu'),more=byId('v5MoreNav');
 if(more&&menu){more.addEventListener('click',()=>{
   const opening=menu.hidden;menu.hidden=!opening;more.setAttribute('aria-expanded',String(opening));
 });}
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&socket)stopSocket('화면이 숨겨져 체결 관찰을 종료했습니다.');});
 window.addEventListener('pagehide',()=>{if(socket)stopSocket();stopBatchPoll();});
}
window.NOVAV5={setAnalysis,onViewChange,stopSocket};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
