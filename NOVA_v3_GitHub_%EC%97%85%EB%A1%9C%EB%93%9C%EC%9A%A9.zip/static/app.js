/* NOVA v3 Mobile: read-only PWA. Polling only while tab is visible; no persistent push. */
'use strict';
const $ = id => document.getElementById(id);
const PREVIEW = Boolean(window.NOVA_PREVIEW_DATA);
const safeStore = {
  get(key, fallback){ try { const v=localStorage.getItem(key); return v===null?fallback:JSON.parse(v); } catch {return fallback;} },
  set(key,val){ try {localStorage.setItem(key,JSON.stringify(val));} catch {} }
};
const safeSession = {get(key){try{return sessionStorage.getItem(key)||''}catch{return ''}},set(key,value){try{sessionStorage.setItem(key,value)}catch{}}};
let config = safeStore.get('nova3-config',{source:'yahoo',mode:'스윙',cost:15,auto:false});
if(PREVIEW) config={...config,source:'demo'};
let watchlist = safeStore.get('nova3-watch',[]);
let latest = null;
let pending = null;
let pendingInstall = null;
let refreshTimer = null;
let view = 'analyze';
const ICON={BUY:'↗',SELL:'↘',HOLD:'—'};
const sanitize = s => String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const format = (n, c='') => n==null || !Number.isFinite(Number(n))?'미확인':new Intl.NumberFormat('ko-KR',{maximumFractionDigits:Number(n)<100?2:0}).format(Number(n))+(c?' '+c:'');
const pct = n => n==null || !Number.isFinite(Number(n))?'표본 없음':`${Number(n)>0?'+':''}${Number(n).toFixed(2)}%`;
const shortTime = text => text?String(text).replace('T',' ').replace(/\+\d\d:\d\d$/,'').slice(0,19):'미확인';
const setText = (id,t) => {$(id).textContent=t;};
function showMessage(text='',kind=''){
  const el=$('message');el.hidden=!text;el.className='screen-message '+kind;el.textContent=text;
}
function setConnection(label,active=false,fail=false){
  const badge=$('connectionBadge');badge.className='status-pill '+(fail?'offline':active?'online':'');
  badge.lastChild.textContent=label;
}
function storeConfig(){if(!PREVIEW)safeStore.set('nova3-config',config);}
function displayMode(){document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===config.mode));}
function selectView(next){
  view=next;
  ['analyze','backtest','watchlist'].forEach(x=>{
    const p=$('view-'+x);p.hidden=x!==next;
    document.querySelector(`[data-view="${x}"]`).classList.toggle('active',x===next);
  });
  if(next==='watchlist')renderWatchlist();
  if(next==='backtest'&&latest)renderBacktest(latest);
}
function compareIcon(signal){return ICON[signal]??'—';}
function renderChart(container, series, opts={}){
  const lines=(series??[]).filter(x=>x.values&&x.values.length);
  if(!lines.length){container.textContent='차트 데이터가 없습니다.';return;}
  const values=lines.flatMap(x=>x.values).map(Number).filter(Number.isFinite);
  if(!values.length){container.textContent='차트 데이터가 없습니다.';return;}
  let min=Math.min(...values),max=Math.max(...values);
  const p=Math.max(0.001,(max-min)*.14);min-=p;max+=p;
  const left=16,top=16,w=648,h=198;
  const count=Math.max(...lines.map(x=>x.values.length));
  const X=(i,len)=>left+(len<2?w:(i/(len-1)*w));
  const Y=v=>top+h-(Number(v)-min)/(max-min)*h;
  let paths='';
  for(const line of lines){
    const segments=[];let current=[];
    line.values.forEach((v,i)=>{
      if(v==null||!Number.isFinite(Number(v))){if(current.length)segments.push(current);current=[];return;}
      current.push(`${current.length?'L':'M'}${X(i,line.values.length).toFixed(1)},${Y(v).toFixed(1)}`);
    });
    if(current.length)segments.push(current);
    for(const seg of segments){paths+=`<path d="${seg.join(' ')}" fill="none" stroke="${line.color}" stroke-width="${line.width||2.1}" vector-effect="non-scaling-stroke" stroke-linecap="round" stroke-linejoin="round" />`;}
  }
  const grid=Array.from({length:4},(_,i)=>{let y=top+i*h/3;return `<line x1="${left}" x2="${left+w}" y1="${y}" y2="${y}" stroke="#ffffff15" stroke-width="1" />`}).join('');
  const label=Number.isFinite(max)?format(max):'—';
  container.innerHTML=`<svg viewBox="0 0 680 240" role="img" aria-label="${sanitize(opts.label||'가격 그래프')}" preserveAspectRatio="xMidYMid meet"><defs><linearGradient id="graphFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#58e2c2" stop-opacity=".13"/><stop offset="100%" stop-color="#58e2c2" stop-opacity="0"/></linearGradient></defs>${grid}${paths}<text x="668" y="13" text-anchor="end" font-size="11" fill="#83aab5">${sanitize(label)}</text><text x="668" y="232" text-anchor="end" font-size="11" fill="#83aab5">${sanitize(format(min))}</text></svg>`;
}
function renderRoles(d){
  const box=$('roleList');box.innerHTML='';
  d.votes.forEach(x=>{
    const row=document.createElement('div');row.className='role';
    row.innerHTML=`<div class="role-text"><div class="role-title">${sanitize(x.role)}</div><div class="role-reason">${sanitize(x.reason)}</div></div><span class="role-tag ${x.direction===1?'buy':x.direction===-1?'sell':''}">${sanitize(x.label)}</span>`;
    box.appendChild(row);
  });
}
function renderBacktest(d){
  const t=d.backtest;
  setText('directionAccuracy',pct(t.directional_hit_rate_pct));
  setText('directionSamples',`과거 신호 ${t.directional_samples}건`);
  setText('tradeWinRate',pct(t.win_rate_pct));
  setText('tradeCount',`청산 거래 ${t.closed_trades}건`);
  setText('strategyReturn',pct(t.total_return_pct));
  setText('maxDrawdown',pct(t.max_drawdown_pct));
  setText('benchReturn',pct(t.benchmark_return_pct));
  const problem = t.directional_samples<30||t.closed_trades<10||t.last_20pct_samples<20;
  $('sampleWarning').hidden=!problem;
  renderChart($('equityChart'),[
    {values:t.curve.strategy,color:'#58e2c2',width:2.9},
    {values:t.curve.benchmark,color:'#81a6f9',width:2.2}
  ],{label:'모의 자산 곡선'});
  const list=$('tradeList');list.innerHTML='';
  if(!t.recent_trades.length){list.innerHTML='<div class="watch-empty">청산 거래 기록이 없습니다.</div>';return;}
  t.recent_trades.forEach(tr=>{
    const row=document.createElement('div');row.className='trade-item';
    row.innerHTML=`<div><div class="trade-reason">${sanitize(tr.reason)}</div><div class="trade-date">${sanitize(shortTime(tr.entry))} → ${sanitize(shortTime(tr.exit))}</div></div><div class="trade-pnl ${tr.pnl_pct>=0?'positive':'negative'}">${sanitize(pct(tr.pnl_pct))}</div>`;
    list.appendChild(row);
  });
}
function renderWatchlist(){
  const el=$('watchList');el.innerHTML='';
  if(!watchlist.length){el.innerHTML='<div class="watch-empty">아직 저장한 종목이 없습니다.<br>분석 화면에서 ☆ 관심 버튼을 눌러 추가하세요.</div>';return;}
  watchlist.forEach(symbol=>{
    const row=document.createElement('div');row.className='watch-item';
    const btn=document.createElement('button');btn.className='watch-target';btn.type='button';btn.textContent='↗  '+symbol;
    btn.onclick=()=>{ $('symbolInput').value=symbol;if(config.source==='demo'){$('sourceSelect').value='yahoo';config.source='yahoo';}selectView('analyze');analyze(); };
    const remove=document.createElement('button');remove.className='watch-remove';remove.type='button';remove.textContent='삭제';
    remove.onclick=()=>{watchlist=watchlist.filter(x=>x!==symbol);safeStore.set('nova3-watch',watchlist);renderWatchlist();updateWatchButton();};
    row.append(btn,remove);el.appendChild(row);
  });
}
function updateWatchButton(){
  const symbol=$('symbolInput').value.trim().toUpperCase();
  const on=watchlist.includes(symbol);
  const b=$('watchButton');b.classList.toggle('saved',on);b.innerHTML=(on?'★':'☆')+' <span>관심</span>';b.setAttribute('aria-label',on?'관심종목 삭제':'관심종목 추가');
}
function maybeNotify(d){
  if(d.is_demo||d.is_stale||!d.signal_is_current||!('Notification' in window)||Notification.permission!=='granted')return;
  const key=`${d.source}/${d.symbol}/${d.mode}`;
  const saved=safeStore.get('nova3-last-signals',{});
  if(saved[key]&&saved[key]!==d.signal){
    try{new Notification(`NOVA ${d.symbol}: ${d.signal_label}`,{body:`${d.mode} 완료봉 기준 · ${format(d.reference,d.currency)} · 최신 시세 아님 가능`,icon:'/static/icons/icon-192.png'});}catch{}
  }
  saved[key]=d.signal;
  if(Object.keys(saved).length>60){Object.keys(saved).slice(0,20).forEach(k=>delete saved[k]);}
  safeStore.set('nova3-last-signals',saved);
}
function render(d){
  latest=d;
  $('results').hidden=false;
  setText('symbolName',d.is_demo?'DEMO · 가상 종목':d.symbol);
  setText('dataMode',d.mode==='스윙'?'일봉':d.mode+'봉');
  setText('signalLabel',d.signal_label);
  setText('signalDescription',d.signal==='SELL'?'보유분 축소 검토 · 공매도 진입 아님':d.signal==='BUY'?'기술적 매수 조건 충족 · 수익 보장 아님':'진입 조건 미충족 · 관망');
  setText('signalTimestamp',shortTime(d.last_completed_bar));
  setText('signalCircle',compareIcon(d.signal));
  const sig=document.querySelector('.signal-card');sig.classList.toggle('sell',d.signal==='SELL');sig.classList.toggle('hold',d.signal==='HOLD');
  $('demoWarning').hidden=!d.is_demo;
  $('staleWarning').hidden=!d.is_stale;
  setText('lastClose',format(d.reference,d.currency));
  setText('quoteValue',format(d.quote,d.currency));
  const total=Math.max(1,d.buy_votes+d.sell_votes+d.hold_votes);
  for(const [id,value] of [['voteBuyBar',d.buy_votes],['voteHoldBar',d.hold_votes],['voteSellBar',d.sell_votes]])$(id).style.width=(100*value/total)+'%';
  setText('voteBuy',d.buy_votes);setText('voteSell',d.sell_votes);setText('voteHold',d.hold_votes);
  setText('stopPrice',format(d.long_stop_reference,d.currency));setText('targetPrice',format(d.long_target_reference,d.currency));
  setText('riskReward',`참고 손익비 ${d.long_risk_reward==null?'미확인':d.long_risk_reward.toFixed(2)} : 1`);
  setText('metaData',`${d.provider} · ${d.freshness} · 조회: ${shortTime(d.fetched_at)} · 완료봉 경과 ${d.price_age_minutes??'미확인'}분 · ${d.provider_note}`);
  setText('chartEnd',shortTime(d.last_completed_bar));
  renderChart($('priceChart'),[
    {values:d.chart.close,color:'#58e2c2',width:2.9},
    {values:d.chart.ema20,color:'#81a6f9',width:2}
  ],{label:'완료봉 종가 및 20기간 지수이동평균'});
  renderRoles(d);renderBacktest(d);updateWatchButton();maybeNotify(d);
  const state = d.is_demo?'가상 데이터':d.is_stale?'봉 업데이트 지연':'데이터 조회됨';setConnection(state,!d.is_stale&&!d.is_demo,false);
}
async function analyze(){
  if(pending){pending.abort();pending=null;}
  const symbol=$('symbolInput').value.trim().toUpperCase();
  if(!symbol && config.source!=='demo'){showMessage('종목코드를 입력해 주세요.','error');return;}
  showMessage('마지막 완료봉과 과거 데이터를 분석 중입니다.','loading');
  setConnection('조회 중');
  const button=document.querySelector('#searchForm button');button.disabled=true;
  const ctrl=new AbortController();pending=ctrl;
  let timedOut=false;
  const kill=setTimeout(()=>{timedOut=true;ctrl.abort();},30000);
  try{
    let data;
    if(PREVIEW){
      if(config.source!=='demo'){throw new Error('이 HTML은 가상 데이터 데모입니다. 실제 종목 분석은 배포된 NOVA 서버에서 이용하세요.');}
      data=window.NOVA_PREVIEW_DATA[config.mode];
      if(!data)throw new Error('해당 주기 데모 데이터가 없습니다.');
    }else{
      const params=new URLSearchParams({symbol,mode:config.mode,source:config.source,cost_bps:String(config.cost)});
      const token=safeSession.get('nova3-token');
      const response=await fetch('/api/analysis?'+params,{headers:token?{'Authorization':'Bearer '+token}:{},cache:'no-store',signal:ctrl.signal});
      if(!response.ok){
        const err=await response.json().catch(()=>({}));
        const detail=typeof err.detail==='string'?err.detail:`HTTP ${response.status}`;
        throw new Error(detail);
      }
      data=await response.json();
    }
    if(ctrl.signal.aborted)return;
    showMessage('');
    render(data);
  }catch(err){
    if(ctrl.signal.aborted&&!timedOut)return;
    $('results').hidden=true;
    setConnection('조회 실패',false,true);
    showMessage('데이터를 가져오지 못했습니다. '+(timedOut?'조회 시간이 초과되었습니다.':err.message)+'\n데이터가 없을 때는 실제 신호를 생성하지 않습니다.','error');
  }finally{clearTimeout(kill);if(pending===ctrl)pending=null;button.disabled=false;}
}
function scheduleRefresh(){
  if(refreshTimer){clearInterval(refreshTimer);refreshTimer=null;}
  if(config.auto&&!PREVIEW)refreshTimer=setInterval(()=>{
    if(!document.hidden&&!pending)analyze();
  },60000);
}
function init(){
  const oldSymbol=safeStore.get('nova3-symbol','AAPL');
  $('symbolInput').value=PREVIEW?'DEMO':oldSymbol;
  config.mode=['1분','5분','스윙'].includes(config.mode)?config.mode:'스윙';
  $('sourceSelect').value=config.source;
  if(PREVIEW){$('sourceSelect').value='demo';$('sourceSelect').disabled=true;$('costInput').disabled=true;$('autoRefresh').disabled=true;}
  $('costInput').value=config.cost;
  $('costDisplay').textContent=`편도 ${config.cost}bp`;
  $('autoRefresh').checked=config.auto;
  $('tokenInput').value=safeSession.get('nova3-token');
  displayMode();
  $('searchForm').addEventListener('submit',e=>{e.preventDefault();safeStore.set('nova3-symbol',$('symbolInput').value.trim().toUpperCase());analyze();});
  document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{config.mode=b.dataset.mode;storeConfig();displayMode();analyze();});
  document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>selectView(b.dataset.view));
  document.querySelectorAll('[data-symbol]').forEach(b=>b.onclick=()=>{if(PREVIEW){showMessage('가상 데이터 미리보기에서는 실제 종목을 조회할 수 없습니다.','error');return;}$('symbolInput').value=b.dataset.symbol;safeStore.set('nova3-symbol',b.dataset.symbol);if(config.source==='demo'){config.source='yahoo';$('sourceSelect').value='yahoo';}config.mode=config.mode;storeConfig();selectView('analyze');analyze();});
  $('watchButton').onclick=()=>{
    if(!latest)return;
    if(latest.is_demo){showMessage('가상 데이터는 관심종목으로 등록할 수 없습니다.');return;}
    const symbol=latest.symbol;
    if(watchlist.includes(symbol))watchlist=watchlist.filter(x=>x!==symbol);
    else watchlist.unshift(symbol);
    watchlist=watchlist.slice(0,30);
    safeStore.set('nova3-watch',watchlist);updateWatchButton();
  };
  $('settingsButton').onclick=()=>$('settingsDialog').showModal();
  $('costInput').oninput=()=>setText('costDisplay',`편도 ${$('costInput').value}bp`);
  $('saveSettings').onclick=()=>{
    config.source=$('sourceSelect').value;config.cost=Number($('costInput').value);config.auto=$('autoRefresh').checked;
    safeSession.set('nova3-token',$('tokenInput').value.trim());
    if(PREVIEW){config.source='demo';config.cost=15;config.auto=false;$('sourceSelect').value='demo';}
    storeConfig();scheduleRefresh();analyze();
  };
  $('sourceSelect').onchange=()=>{
    const val=$('sourceSelect').value;
    const msg=val==='kis'?'KIS_APP_KEY / KIS_APP_SECRET을 서버 환경변수로 설정하세요. 국내주식만 지원합니다.':val==='demo'?'가상 시세로 모든 기능을 시험합니다. 실제 종목과 무관합니다.':'Yahoo 공개 데이터는 거래소 공식 실시간 시세가 아니며 이용 약관을 확인해야 합니다.';
    setText('sourceHint',msg);
  };
  $('sourceSelect').dispatchEvent(new Event('change'));
  $('notificationButton').onclick=async()=>{
    if(!('Notification'in window)||!window.isSecureContext){showMessage('알림은 HTTPS 등 보안 연결에서 지원됩니다.','error');return;}
    const perm=await Notification.requestPermission();showMessage(perm==='granted'?'신호 변경 알림이 허용되었습니다. 브라우저가 열려 있을 때 선택 종목만 감시합니다.':'알림이 허용되지 않았습니다.');
  };
  $('installButton').onclick=async()=>{
    if(pendingInstall){pendingInstall.prompt();try{await pendingInstall.userChoice;}catch{}pendingInstall=null;}
    else showMessage('갤럭시 Chrome/삼성 인터넷에서 HTTPS로 접속한 뒤 브라우저 메뉴의 “앱 설치” 또는 “홈 화면에 추가”를 선택하세요.','');
    $('settingsDialog').close();
  };
  window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();pendingInstall=e;});
  if('serviceWorker'in navigator&&!PREVIEW&&(location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1'))navigator.serviceWorker.register('/sw.js').catch(()=>{});
  window.addEventListener('online',()=>setConnection('네트워크 연결됨'));
  window.addEventListener('offline',()=>setConnection('오프라인',false,true));
  scheduleRefresh();renderWatchlist();analyze();
}
window.addEventListener('DOMContentLoaded',init);
