"""KIS authenticated REST quotes and minute/daily history; yfinance non-guaranteed quotes; synthetic DEMO.

KIS uses read-only quotation endpoints; NO broker ordering code is present.
Credentials are passed in memory, never written to a file by this module.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
import re, threading, time
import numpy as np
import pandas as pd
import requests
from engine import clean_bars

KST=ZoneInfo('Asia/Seoul')
NY=ZoneInfo('America/New_York')
TOKENS: dict[str,tuple[str,float]]={}
TOKEN_LOCK=threading.Lock()

@dataclass
class MarketData:
    bars:pd.DataFrame
    provider:str
    symbol:str
    interval:str
    quote:float|None
    quote_time:str
    retrieved_at:str
    freshness:str
    note:str
    currency:str
    synthetic:bool=False


def ticker_format(ticker:str)->str:
    raw=ticker.strip().upper()
    if re.fullmatch(r'\d{6}',raw): return raw+'.KS'
    if not re.fullmatch(r'[A-Z0-9^.=-]{1,24}',raw):
        raise ValueError('종목코드 형식이 잘못되었습니다. 예: 005930.KS, AAPL, NVDA')
    return raw


def market_zone(ticker:str):
    return KST if ticker.endswith(('.KS','.KQ')) else NY


def is_session_finished(now:datetime, mode:str, symbol:str)->bool:
    zone=market_zone(symbol)
    here=now.astimezone(zone)
    close = (15,30) if zone==KST else (16,0)
    return here.hour*60+here.minute >= close[0]*60+close[1]


def discard_unfinished(bars:pd.DataFrame, mode:str,symbol:str,now:datetime|None=None)->pd.DataFrame:
    """Exclude open candle according to timestamp convention (minute bar start); daily current partial.
    tz-aware index required for intraday. yfinance/KIS both use start-time minute timestamps.
    """
    if bars.empty:return bars
    now=now or datetime.now(timezone.utc)
    d=bars.sort_index().copy()
    if mode=='스윙':
        local=now.astimezone(market_zone(symbol))
        last=pd.Timestamp(d.index[-1])
        last_date=last.date()
        if last_date==local.date() and not is_session_finished(now,mode,symbol):
            return d.iloc[:-1]
    else:
        if d.index.tz is None:
            raise ValueError('분봉의 시간대 정보가 없습니다')
        delta=timedelta(minutes=1 if mode=='1분' else 5)
        if d.index[-1].to_pydatetime()+delta>now.astimezone(d.index.tz):
            return d.iloc[:-1]
    return d


def demo_data(mode:str,seed:int=240)->MarketData:
    rng=np.random.default_rng(seed)
    if mode=='스윙':
        idx=pd.bdate_range(end=pd.Timestamp.now(tz=KST).date(),periods=330)
        vol=0.012
    else:
        days=pd.bdate_range(end=pd.Timestamp.now(tz=KST).date(),periods=5)
        # 9:00 to 15:29 each session (synthetic 1-minute candles).
        dates=[pd.Timestamp(day.date(),tz=KST)+pd.Timedelta(hours=9) for day in days]
        idx=pd.DatetimeIndex([x+pd.Timedelta(minutes=m) for x in dates for m in range(390)])
        vol=.0008
    ret=rng.normal(.00014 if mode=='스윙' else .000016,vol,len(idx))
    close=70_000*np.exp(np.cumsum(ret))
    op=np.r_[close[0],close[:-1]]*(1+rng.normal(0,vol*.12,len(idx)))
    high=np.maximum(op,close)*(1+np.abs(rng.normal(0,vol*.28,len(idx))))
    low=np.minimum(op,close)*(1-np.abs(rng.normal(0,vol*.28,len(idx))))
    volume=rng.integers(600,6000,len(idx)).astype(float)
    df=pd.DataFrame({'Open':op,'High':high,'Low':low,'Close':close,'Volume':volume},index=idx)
    if mode=='5분': df=aggregate_5m(df)
    # All entries are hypothetical and must not be interpreted as live.
    return MarketData(df,'DEMO 가상 시계열','DEMO',mode,float(df['Close'].iloc[-1]),'가상 시점','가상 데이터',
                      '가상 데이터 · 실제 시세/수익률/적중률이 아닙니다','연습용으로만 사용', 'KRW',True)


def aggregate_5m(bars:pd.DataFrame)->pd.DataFrame:
    # Group by exchange-local date to avoid aggregation across an overnight gap.
    pieces=[]
    for _,chunk in bars.groupby(bars.index.date):
        r=chunk.resample('5min',label='left',closed='left').agg({'Open':'first','High':'max','Low':'min','Close':'last','Volume':'sum'})
        pieces.append(r.dropna(subset=['Open','Close']))
    return pd.concat(pieces).sort_index() if pieces else bars.iloc[:0]


def yahoo_data(ticker:str,mode:str)->MarketData:
    try:import yfinance as yf
    except ImportError as e:raise RuntimeError('yfinance 설치가 필요합니다. pip install -r requirements.txt') from e
    ticker=ticker_format(ticker)
    interval={'1분':'1m','5분':'5m','스윙':'1d'}[mode]
    period={'1분':'7d','5분':'30d','스윙':'2y'}[mode]
    # Disable automatic attempts to scrape additional page resources.
    try:
        hist=yf.Ticker(ticker).history(period=period,interval=interval,auto_adjust=True,prepost=False,raise_errors=True,timeout=12)
    except Exception as exc:
        raise RuntimeError(f'Yahoo 시세 호출 실패: {type(exc).__name__} (종목/네트워크/서비스 상태 확인)') from exc
    if hist is None or hist.empty: raise RuntimeError('Yahoo에서 해당 종목의 시세가 반환되지 않았습니다')
    d=clean_bars(hist)
    now=datetime.now(timezone.utc)
    d=discard_unfinished(d,mode,ticker,now)
    if len(d)<65:raise ValueError(f'{ticker}: 완료된 봉이 {len(d)}개뿐입니다 (필요 65개). 다른 주기/종목을 선택하세요.')
    last=d.index[-1]
    return MarketData(d,'Yahoo Finance (지연·이용조건 미검증)',ticker,interval,float(d['Close'].iloc[-1]),str(last),
                      now.isoformat(timespec='seconds'),
                      '지연 미확인 · 실시간 보장 없음',
                      'Yahoo 데이터는 거래소 공식 실시간 시세가 아닐 수 있습니다. 마지막 완료봉 종가 기준 판단입니다.',
                      'KRW' if ticker.endswith(('.KS','.KQ')) else 'USD')


class KIS:
    BASE='https://openapi.koreainvestment.com:9443'
    def __init__(self,key:str,secret:str):
        if not key.strip() or not secret.strip():raise ValueError('KIS App Key와 App Secret을 모두 입력하세요')
        self.key,self.secret=key.strip(),secret.strip()
        self.session=requests.Session()
        self.token=self._token()

    def _token(self)->str:
        import hashlib
        cache_id=hashlib.sha256((self.key+'|'+self.secret).encode()).hexdigest()
        with TOKEN_LOCK:
            saved=TOKENS.get(cache_id)
            if saved and saved[1]>time.time()+300:return saved[0]
        try:
            r=self.session.post(self.BASE+'/oauth2/tokenP',json={'grant_type':'client_credentials','appkey':self.key,'appsecret':self.secret},timeout=12)
            r.raise_for_status()
            data=r.json()
            token=data.get('access_token')
            if not token:raise ValueError('토큰이 응답에 없습니다')
            duration=int(data.get('expires_in',3600))
        except (requests.RequestException,ValueError,KeyError) as exc:
            raise RuntimeError('KIS 접근토큰 발급 실패. 키/활성화/네트워크/호출제한을 확인하세요.') from exc
        with TOKEN_LOCK:TOKENS[cache_id]=(token,time.time()+min(duration,24*3600))
        return token

    def get(self,path:str,tr_id:str,params:dict)->dict:
        headers={'authorization':f'Bearer {self.token}', 'appkey':self.key,
                 'appsecret':self.secret,'tr_id':tr_id,'custtype':'P','content-type':'application/json; charset=utf-8'}
        try:
            response=self.session.get(self.BASE+path,headers=headers,params=params,timeout=12)
            response.raise_for_status()
            data=response.json()
        except (requests.RequestException,ValueError) as exc:
            raise RuntimeError(f'KIS 시세 API 통신 실패({tr_id}), 인터넷/API 상태 확인') from exc
        if data.get('rt_cd')!='0':
            # Never display credentials, tokens, or the raw response.
            raise RuntimeError(f"KIS 시세 오류 {data.get('msg_cd','unknown')}: {str(data.get('msg1',''))[:120]}")
        time.sleep(.10)  # modest pacing to respect rate limits
        return data

    def quote(self,code:str)->tuple[float,str]:
        r=self.get('/uapi/domestic-stock/v1/quotations/inquire-price','FHKST01010100',
                   {'FID_COND_MRKT_DIV_CODE':'J','FID_INPUT_ISCD':code})
        out=r.get('output') or {}
        price=float(out.get('stck_prpr') or 0)
        if price<=0:raise RuntimeError('KIS 현재가 값이 유효하지 않습니다')
        return price,str(out.get('stck_cntg_hour') or '조회 시점 스냅샷(원체결시각 미제공)')

    def daily(self,code:str,now:datetime)->pd.DataFrame:
        start=(now-timedelta(days=600)).strftime('%Y%m%d')
        end=now.strftime('%Y%m%d')
        rows=[];seen=set()
        for _ in range(8):
            r=self.get('/uapi/domestic-stock/v1/quotations/inquire-daily-itemchartprice','FHKST03010100',
                {'FID_COND_MRKT_DIV_CODE':'J','FID_INPUT_ISCD':code,'FID_INPUT_DATE_1':start,
                 'FID_INPUT_DATE_2':end,'FID_PERIOD_DIV_CODE':'D','FID_ORG_ADJ_PRC':'0'})
            records=r.get('output2') or []
            if not records:break
            rows.extend(records)
            dates=[x.get('stck_bsop_date','') for x in records if x.get('stck_bsop_date')]
            if not dates:break
            earliest=min(dates)
            if earliest<=start or earliest in seen or len(records)<100:break
            seen.add(earliest)
            end=(datetime.strptime(earliest,'%Y%m%d')-timedelta(days=1)).strftime('%Y%m%d')
        return kis_ohlc(rows,'스윙')

    def minutes(self,code:str,now:datetime,sessions:int=3)->pd.DataFrame:
        # Last 3 weekday sessions, including today if a weekday. Holidays may return no records.
        days=pd.bdate_range(end=now.date(),periods=sessions)
        all_rows=[]
        for day in days:
            date=day.strftime('%Y%m%d');cursor='153000';seen=set()
            for _ in range(5):
                r=self.get('/uapi/domestic-stock/v1/quotations/inquire-time-dailychartprice','FHKST03010230',
                           {'FID_COND_MRKT_DIV_CODE':'J','FID_INPUT_ISCD':code,'FID_INPUT_HOUR_1':cursor,
                            'FID_INPUT_DATE_1':date,'FID_PW_DATA_INCU_YN':'Y','FID_FAKE_TICK_INCU_YN':''})
                rows=r.get('output2') or []
                if not rows:break
                all_rows.extend(rows)
                times=[x.get('stck_cntg_hour','') for x in rows if x.get('stck_cntg_hour')]
                if not times:break
                earliest=min(times)
                if earliest<='090000' or earliest in seen or len(rows)<120:break
                seen.add(earliest)
                # KIS API is inclusive: de-duplicate returned boundary candle.
                cursor=earliest
        return kis_ohlc(all_rows,'1분')


def kis_ohlc(rows:list[dict],mode:str)->pd.DataFrame:
    out=[]
    for v in rows:
        try:
            stamp=v['stck_bsop_date']+(v.get('stck_cntg_hour','') if mode!='스윙' else '')
            fmt='%Y%m%d%H%M%S' if mode!='스윙' else '%Y%m%d'
            when=pd.Timestamp(datetime.strptime(stamp,fmt),tz=KST) if mode!='스윙' else pd.Timestamp(datetime.strptime(stamp,fmt))
            out.append({'Date':when,'Open':float(v['stck_oprc']),'High':float(v['stck_hgpr']),
                        'Low':float(v['stck_lwpr']),
                        'Close':float(v['stck_prpr'] if mode!='스윙' else v['stck_clpr']),
                        'Volume':float(v.get('cntg_vol',0) if mode!='스윙' else v.get('acml_vol',0))})
        except (KeyError,ValueError,TypeError): continue
    if not out: return pd.DataFrame(columns=['Open','High','Low','Close','Volume'])
    d=pd.DataFrame(out).set_index('Date')
    return clean_bars(d)


def kis_data(ticker:str, mode:str, key:str,secret:str)->MarketData:
    normalized=ticker_format(ticker)
    if not re.fullmatch(r'\d{6}\.(KS|KQ)',normalized):
        raise ValueError('KIS 국내주식은 6자리 종목코드를 입력하세요. 예: 005930')
    code=normalized[:6]
    api=KIS(key,secret)
    now=datetime.now(KST)
    quote,quote_stamp=api.quote(code)
    if mode=='스윙': bars=api.daily(code,now)
    else:
        bars=api.minutes(code,now,sessions=3)
        if mode=='5분':bars=aggregate_5m(bars)
    if bars.empty:raise RuntimeError('KIS에서 캔들 데이터가 없습니다. 거래일/종목/계좌 API 권한 확인')
    bars=discard_unfinished(bars,mode,normalized,datetime.now(timezone.utc))
    if len(bars)<65:raise RuntimeError(f'KIS 완료봉 {len(bars)}개로 65개 미만입니다. 추가 세션 확보 또는 스윙 모드를 이용하세요.')
    return MarketData(bars,'KIS 한국투자증권 REST 시세(주기 조회)',normalized,mode,
                      quote,f'KIS 응답 체결시각: {quote_stamp} (날짜 확인 제한)',
                      now.isoformat(timespec='seconds'),
                      'REST 조회 시점 스냅샷 · 지속 스트리밍 아님',
                      'KIS 시세/분봉. 분봉은 완료된 봉만 사용. 시장 휴장·응답 시각을 확인하세요.', 'KRW')
