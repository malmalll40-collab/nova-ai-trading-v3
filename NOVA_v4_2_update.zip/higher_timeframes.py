"""NOVA v4.1: read-only long-period chart data.

Aggregate *complete daily candles* into calendar week/month/year in the exchange's
local timezone. The unfinished current calendar period is explicitly tagged and
is never used to create trading signals or historical success-rate claims.
"""
from __future__ import annotations

from datetime import datetime, date, timedelta, timezone
from zoneinfo import ZoneInfo
import pandas as pd
import numpy as np

from data_sources import (KST, market_zone, ticker_format, clean_bars,
                          discard_unfinished, kis_data, demo_data)

PERIODS = {'1d':'일봉', '1w':'주봉', '1mo':'월봉', '1y':'연봉'}
FIELDS = {'Open':'first','High':'max','Low':'min','Close':'last','Volume':'sum'}


def bucket(day:date, timeframe:str)->date:
    if timeframe=='1d': return day
    if timeframe=='1w': return day-timedelta(days=day.weekday())
    if timeframe=='1mo': return date(day.year, day.month, 1)
    if timeframe=='1y': return date(day.year, 1, 1)
    raise ValueError('지원되지 않는 차트 주기입니다.')


def grouped_ohlcv(daily:pd.DataFrame, timeframe:str, symbol:str, now:datetime|None=None)->pd.DataFrame:
    """Local calendar OHLCV with no future data, no forward-fill, no partial daily bars.

    Index is exchange-local when intraday timestamps are timezone-aware. Weekly
    buckets start Monday; monthly and yearly buckets start on calendar 1st.
    """
    if timeframe not in PERIODS: raise ValueError('지원되지 않는 차트 주기입니다.')
    if daily.empty: return daily.copy()
    src=clean_bars(daily)
    if src.empty:return src
    zone=market_zone(symbol)
    local_index=src.index.tz_convert(zone) if src.index.tz is not None else src.index
    days=[pd.Timestamp(x).date() for x in local_index]
    keys=[bucket(day,timeframe) for day in days]
    src=src.copy()
    src['_period']=keys
    frame=src.groupby('_period',sort=True).agg(FIELDS)
    # Derived period index is a calendar label, not an observed market price day.
    frame.index=pd.DatetimeIndex(frame.index, name='Period')
    if not frame.index.is_unique or not frame.index.is_monotonic_increasing:
        raise ValueError('봉 날짜 집계 순서가 올바르지 않습니다.')
    return frame


def _float(v):
    try:
        n=float(v)
        return round(n,6) if np.isfinite(n) else None
    except (TypeError,ValueError):return None


def chart_data(daily:pd.DataFrame, timeframe:str, symbol:str, source:str, *,
               synthetic:bool=False, now:datetime|None=None)->dict:
    if timeframe not in PERIODS:raise ValueError('지원하지 않는 차트 주기입니다.')
    normalized='DEMO' if synthetic else ticker_format(symbol)
    zone=KST if synthetic else market_zone(normalized)
    now=now or datetime.now(timezone.utc)
    frame=grouped_ohlcv(daily,timeframe,normalized,now)
    if len(frame)<2:
        raise ValueError(f'{PERIODS[timeframe]} 자료가 {len(frame)}개뿐입니다. 장기 조회가 가능한 Yahoo 공급원을 선택하거나 다른 주기를 이용하세요.')
    # EMA uses previous historical observations even when only the last bars are shown.
    frame['ema20']=frame['Close'].ewm(span=20,adjust=False,min_periods=20).mean()
    frame['ema50']=frame['Close'].ewm(span=50,adjust=False,min_periods=50).mean()
    shown=frame.tail(240)
    today=now.astimezone(zone).date()
    is_partial=[timeframe!='1d' and bucket(today,timeframe)==x.date() for x in shown.index]
    chart={'dates':[x.strftime('%Y-%m-%d') for x in shown.index],
           'partial':is_partial}
    for field,alias in [('Open','open'),('High','high'),('Low','low'),('Close','close'),('Volume','volume'),('ema20','ema20'),('ema50','ema50')]:
        chart[alias]=[_float(x) for x in shown[field]]
    last=pd.Timestamp(daily.index[-1])
    if last.tz is not None:last=last.tz_convert(zone)
    else:last=last.tz_localize(zone)
    return {'symbol':normalized,'source':source,'timeframe':timeframe,'timeframe_label':PERIODS[timeframe],
            'count':len(frame),'chart':chart,'synthetic':synthetic,
            'last_completed_daily':last.isoformat(),
            'partial_last':bool(is_partial[-1]),'ema50_available':bool(pd.notna(shown['ema50'].iloc[-1])),
            'note':('가상 데이터 · 실제 주가가 아닙니다.' if synthetic else
                    ('현재 회계연도/월/주가 아직 끝나지 않았다면 마지막 봉은 미완성으로 표시됩니다. '
                     '시세는 공급원에 따라 지연될 수 있습니다. 이 봉은 매매 신호나 적중률 계산에 사용되지 않습니다.'))}


def fetch_long_daily(symbol:str,source:str)->pd.DataFrame:
    """Load daily-only history; isolated from the existing trading decision engine."""
    if source=='demo':
        rng=np.random.default_rng(411)
        idx=pd.bdate_range(end=pd.Timestamp.now(tz=KST).date(),periods=25*252)
        c=60000*np.exp(np.cumsum(rng.normal(.00010,.011,len(idx))))
        o=np.r_[c[0],c[:-1]]*(1+rng.normal(0,.001,len(idx)))
        frame=pd.DataFrame({'Open':o,'High':np.maximum(c,o)*1.006,
                             'Low':np.minimum(c,o)*.994,'Close':c,
                             'Volume':rng.integers(150000,3000000,len(idx))},index=idx)
        # Match the demo swing data exactly in the recent overlap. Otherwise
        # switching '분석 주기' to '주봉/연봉' would show different prices for the
        # same fictitious DEMO symbol, an avoidable and confusing UI defect.
        recent=demo_data('스윙').bars
        before=frame.index.difference(recent.index)
        if len(before) and len(recent):
            factor=float(recent['Open'].iloc[0])/float(frame.loc[before[-1],'Close'])
            frame.loc[before,['Open','High','Low','Close']]*=factor
        frame.loc[recent.index,['Open','High','Low','Close','Volume']]=recent[['Open','High','Low','Close','Volume']].values
        return frame
    symbol=ticker_format(symbol)
    if source=='yahoo':
        try:
            import yfinance as yf
            bars=yf.Ticker(symbol).history(period='max',interval='1d',auto_adjust=True,
                                           prepost=False,raise_errors=True,timeout=15)
        except Exception as exc:
            raise RuntimeError(f'장기 Yahoo 일봉 조회 실패({type(exc).__name__}). 일시 제한 또는 공급원 연결을 확인하세요.') from exc
        if bars is None or bars.empty:raise ValueError('장기 일봉 자료가 없습니다. 해당 종목의 상장 이력을 확인하세요.')
        d=clean_bars(bars)
        d=discard_unfinished(d,'스윙',symbol,datetime.now(timezone.utc))
        return d
    if source=='kis':
        import os
        key,secret=os.environ.get('KIS_APP_KEY',''),os.environ.get('KIS_APP_SECRET','')
        if not (key and secret):raise ValueError('KIS 시세 사용에는 서버의 API 키 설정이 필요합니다.')
        return kis_data(symbol,'스윙',key,secret).bars
    raise ValueError('지원하지 않는 시세 공급원입니다.')
